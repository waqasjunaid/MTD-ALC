~CreateFileResult()
        {
        }