#!/usr/bin/env python3
"""
patch_vulrepair_tensorboard.py

Wraps SummaryWriter(writer_path) in a try/except with a no-op fallback,
so a broken tensorflow/numpy environment (used only for TensorBoard
logging, not training itself) doesn't crash the run. The fallback
object silently absorbs any writer.add_scalar(...)/etc. call via
__getattr__, so no other code needs to change.

Usage:
    python patch_vulrepair_tensorboard.py vulrepair_main.py
"""
import sys


def check(lines, line_no, expected_substr):
    actual = lines[line_no - 1]
    if expected_substr not in actual:
        print(f"ABORTED: line {line_no} does not contain expected text.")
        print(f"  expected substring: {expected_substr!r}")
        print(f"  actual line {line_no}: {actual!r}")
        sys.exit(1)


def main():
    path = sys.argv[1]
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()

    check(lines, 133, 'writer_path = "tb/codet5_training_loss"')
    check(lines, 134, "writer = SummaryWriter(writer_path)")

    print("Anchor lines verified. Applying edit...")

    with open(path + ".bak2", "w", encoding="utf-8") as f:
        f.writelines(lines)

    new_block = [
        '    writer_path = "tb/codet5_training_loss"\n',
        '    class _NoOpWriter:\n',
        '        def __getattr__(self, name):\n',
        '            return lambda *a, **kw: None\n',
        '    try:\n',
        '        writer = SummaryWriter(writer_path)\n',
        '    except Exception as _e:\n',
        '        logger.warning(f"SummaryWriter unavailable ({_e}); "\n',
        '                       f"continuing without TensorBoard logging.")\n',
        '        writer = _NoOpWriter()\n',
    ]
    lines[132:134] = new_block  # replaces old lines 133-134 (indices 132-133)

    with open(path, "w", encoding="utf-8") as f:
        f.writelines(lines)

    print(f"Patched {path} successfully (backup at {path}.bak2)")


if __name__ == "__main__":
    main()