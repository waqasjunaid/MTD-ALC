#!/usr/bin/env python3
"""
score_repair_static.py

Measure vulnerability-repair improvement by running static analyzers
(Cppcheck and/or Semgrep) on ORIGINAL vs. REPAIRED C/C++ functions.

This mirrors the before/after methodology you already use with Flawfinder,
but with higher-coverage analyzers so that far more of the 548 samples are
"measurable" (the analyzer flags the original), fixing the small-n weakness
of the Flawfinder-only result (58/548).

For each sample it:
  1. writes the original and repaired function to temp files,
  2. runs each analyzer on BOTH,
  3. counts security-relevant findings (parse / missing-include / unknown-macro
     noise is filtered out so "improvement" cannot be a parseability artifact),
  4. classifies the sample as improved / unchanged / worse on the MEASURABLE
     subset (analyzer flags the original), exactly like the Flawfinder analysis,
  5. aggregates with a Wilcoxon signed-rank test on paired risk deltas and a
     Wilson CI on the fully-clean rate.

Two input modes
---------------
A) One CSV holding both original and repaired code (your framework):
     --pairs_csv joined.csv --id_col id \
       --original_col func_before --repaired_col patched_code

B) Two row-aligned CSVs (VulRepair: originals in test.csv, patches in raw_preds):
     --original_csv data_ours/test.csv     --original_col func_before \
     --repaired_csv raw_predictions/VulRepair_raw_preds.csv --repaired_col raw_predictions

Cross-method comparison (ours vs VulRepair) on the shared subset:
  run the script twice (once per method) writing --out ours.json and vr.json,
  then pass --compare_json vr.json on the second run (or a third bare run) to
  get a McNemar exact test on which method cleans which sample.

Honest-use notes are printed at the end of every run.
"""

import argparse
import csv
import json
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

csv.field_size_limit(min(sys.maxsize, 2**31 - 1))

# ----------------------------------------------------------------------------
# Severity weighting. A "risk score" per file is the weighted sum of kept
# findings; binary "flagged" = score > 0. Weights are deliberately simple and
# identical in spirit across tools so the two analyzers tell a comparable story.
# ----------------------------------------------------------------------------
CPPCHECK_SEV_WEIGHT = {"error": 3, "warning": 2, "portability": 1, "performance": 1, "style": 1}
SEMGREP_SEV_WEIGHT = {"ERROR": 3, "WARNING": 2, "INFO": 1}

# Findings that are analysis artifacts of isolated, build-context-free functions,
# NOT vulnerabilities. Excluded from the risk score. syntaxError/internalError
# additionally mark the file as a parse failure (unreliable), so a sample is not
# scored as "improved" merely because the patched version happened to parse.
CPPCHECK_IGNORE_IDS = {
    "missingInclude", "missingIncludeSystem", "unknownMacro", "unmatchedSuppression",
    "toomanyconfigs", "purgedConfiguration", "noValidConfiguration", "checkersReport",
    "normalCheckLevelMaxBranches", "ConfigurationNotChecked",
}
CPPCHECK_PARSE_IDS = {"syntaxError", "internalError"}


# ----------------------------------------------------------------------------
# Analyzer runners. Each returns a dict: {score, count, ids, parse_error}
# or None if the analyzer's own output could not be parsed at all.
# ----------------------------------------------------------------------------
def run_cppcheck(path):
    cmd = [
        "cppcheck", "--enable=warning,performance,portability", "--inconclusive",
        "--xml", "--xml-version=2", "--language=c++",
        "--suppress=missingInclude", "--suppress=unknownMacro", str(path),
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        return None
    # Cppcheck writes its XML report to stderr.
    try:
        root = ET.fromstring(proc.stderr) if proc.stderr.strip() else None
    except ET.ParseError:
        return None
    score, count, ids, parse_error = 0, 0, [], False
    if root is not None:
        for err in root.iter("error"):
            eid = err.get("id", "")
            sev = err.get("severity", "")
            if eid in CPPCHECK_PARSE_IDS:
                parse_error = True
                continue
            if eid in CPPCHECK_IGNORE_IDS or sev == "information":
                continue
            score += CPPCHECK_SEV_WEIGHT.get(sev, 1)
            count += 1
            ids.append(eid)
    return {"score": score, "count": count, "ids": ids, "parse_error": parse_error}


def run_semgrep(path, configs):
    cmd = ["semgrep", "scan", "--quiet", "--json", "--timeout", "60", "--no-git-ignore"]
    for c in configs:
        cmd += ["--config", c]
    cmd.append(str(path))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    except subprocess.TimeoutExpired:
        return None
    try:
        data = json.loads(proc.stdout)
    except (json.JSONDecodeError, ValueError):
        return None
    parse_error = False
    for e in data.get("errors", []):
        etype = (e.get("type") or "") + (e.get("level") or "")
        if "Syntax" in etype or "syntax" in etype or "parse" in etype.lower():
            parse_error = True
    score, count, ids = 0, 0, []
    for r in data.get("results", []):
        sev = r.get("extra", {}).get("severity", "INFO")
        score += SEMGREP_SEV_WEIGHT.get(sev, 1)
        count += 1
        ids.append(r.get("check_id", ""))
    return {"score": score, "count": count, "ids": ids, "parse_error": parse_error}


ANALYZERS = {"cppcheck": run_cppcheck, "semgrep": run_semgrep}


# ----------------------------------------------------------------------------
# Statistics helpers (scipy is used on your machine; falls back gracefully).
# ----------------------------------------------------------------------------
def wilson_ci(k, n, z=1.96):
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    half = (z * ((p * (1 - p) / n + z * z / (4 * n * n)) ** 0.5)) / denom
    return (max(0.0, center - half), min(1.0, center + half))


def wilcoxon_delta(deltas):
    """Signed-rank test on paired (repaired - original) risk deltas.
    Negative deltas = risk went down = improvement."""
    nonzero = [d for d in deltas if d != 0]
    if len(nonzero) < 6:
        return {"n_nonzero": len(nonzero), "p_value": None,
                "note": "too few non-zero deltas for a reliable test"}
    try:
        from scipy.stats import wilcoxon
        stat, p = wilcoxon(nonzero, alternative="less")  # H1: deltas < 0 (risk drops)
        return {"n_nonzero": len(nonzero), "statistic": float(stat),
                "p_value": float(p), "alternative": "risk decreases after repair"}
    except Exception as ex:
        return {"n_nonzero": len(nonzero), "p_value": None, "note": f"scipy unavailable: {ex}"}


def mcnemar_exact(b, c):
    """Exact McNemar via binomial test on discordant pairs (b, c)."""
    n = b + c
    if n == 0:
        return {"discordant": 0, "p_value": None, "note": "no discordant pairs"}
    try:
        from scipy.stats import binomtest
        p = binomtest(min(b, c), n, 0.5, alternative="two-sided").pvalue
    except Exception:
        # exact two-sided binomial by hand
        from math import comb
        k = min(b, c)
        tail = sum(comb(n, i) for i in range(0, k + 1)) / (2 ** n)
        p = min(1.0, 2 * tail)
    return {"discordant_b": b, "discordant_c": c, "p_value": float(p)}


# ----------------------------------------------------------------------------
# Input loading
# ----------------------------------------------------------------------------
def clean_code(text, strip_fences=True):
    if text is None:
        return ""
    s = str(text)
    if strip_fences and "```" in s:
        parts = s.split("```")
        # take the longest fenced block if present, else the whole thing
        blocks = parts[1::2]
        if blocks:
            s = max(blocks, key=len)
            # drop a leading language tag line (e.g. "c\n", "cpp\n")
            first_nl = s.find("\n")
            if 0 <= first_nl <= 6:
                s = s[first_nl + 1:]
    return s.strip()


def load_samples(args):
    """Yield dicts: {id, original, repaired}."""
    for label, p in [("--jsonl", args.jsonl), ("--pairs_csv", args.pairs_csv),
                     ("--original_csv", args.original_csv), ("--repaired_csv", args.repaired_csv)]:
        if p and not Path(p).exists():
            sys.exit(f"ERROR: {label} path does not exist: {p}\n"
                     f"       (check for typos — nothing was analyzed)")
    samples = []
    if args.jsonl:
        with open(args.jsonl, encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                row = json.loads(line)
                sid = row.get(args.id_col) or f"S{i}"
                samples.append({
                    "id": str(sid),
                    "original": clean_code(row.get(args.original_col), args.strip_fences),
                    "repaired": clean_code(row.get(args.repaired_col), args.strip_fences),
                })
    elif args.pairs_csv:
        with open(args.pairs_csv, newline="", encoding="utf-8", errors="replace") as f:
            for i, row in enumerate(csv.DictReader(f)):
                sid = row.get(args.id_col) or f"S{i}"
                samples.append({
                    "id": str(sid),
                    "original": clean_code(row.get(args.original_col), args.strip_fences),
                    "repaired": clean_code(row.get(args.repaired_col), args.strip_fences),
                })
    else:
        with open(args.original_csv, newline="", encoding="utf-8", errors="replace") as f:
            originals = list(csv.DictReader(f))
        with open(args.repaired_csv, newline="", encoding="utf-8", errors="replace") as f:
            repaired = list(csv.DictReader(f))
        n = min(len(originals), len(repaired))
        if len(originals) != len(repaired):
            print(f"WARNING: original ({len(originals)}) and repaired ({len(repaired)}) "
                  f"row counts differ; aligning first {n} by row order.")
        for i in range(n):
            sid = originals[i].get(args.id_col) or f"S{i}"
            samples.append({
                "id": str(sid),
                "original": clean_code(originals[i].get(args.original_col), args.strip_fences),
                "repaired": clean_code(repaired[i].get(args.repaired_col), args.strip_fences),
            })
    if args.max_samples:
        samples = samples[: args.max_samples]
    if not samples:
        sys.exit("ERROR: 0 samples loaded — the input file is empty or unreadable.")
    non_empty = sum(1 for s in samples if s["original"])
    if non_empty == 0:
        sys.exit(f"ERROR: all {len(samples)} originals are empty — --original_col "
                 f"'{args.original_col}' is probably the wrong key/column. "
                 f"Nothing was analyzed.")
    if non_empty < len(samples):
        print(f"note: {len(samples) - non_empty}/{len(samples)} samples have an empty "
              f"original and will be skipped.")
    return samples


# ----------------------------------------------------------------------------
# Core scoring
# ----------------------------------------------------------------------------
def score_all(samples, analyzers, configs, file_ext, tmpdir):
    per_analyzer = {a: [] for a in analyzers}
    orig_file = Path(tmpdir) / f"orig{file_ext}"
    rep_file = Path(tmpdir) / f"rep{file_ext}"

    for idx, s in enumerate(samples, 1):
        if not s["original"] or not s["repaired"]:
            for a in analyzers:
                per_analyzer[a].append({"id": s["id"], "skipped": "empty original or repaired"})
            continue
        orig_file.write_text(s["original"], encoding="utf-8", errors="replace")
        rep_file.write_text(s["repaired"], encoding="utf-8", errors="replace")

        for a in analyzers:
            runner = ANALYZERS[a]
            ro = runner(orig_file, configs) if a == "semgrep" else runner(orig_file)
            rr = runner(rep_file, configs) if a == "semgrep" else runner(rep_file)
            rec = {"id": s["id"]}
            if ro is None or rr is None:
                rec["unreliable"] = "analyzer output unparseable"
            else:
                unreliable = ro["parse_error"] or rr["parse_error"]
                rec.update({
                    "orig_score": ro["score"], "rep_score": rr["score"],
                    "orig_count": ro["count"], "rep_count": rr["count"],
                    "orig_flagged": ro["score"] > 0, "rep_flagged": rr["score"] > 0,
                    "rep_clean": rr["score"] == 0,
                    "unreliable": bool(unreliable),
                    "orig_ids": ro["ids"], "rep_ids": rr["ids"],
                })
            per_analyzer[a].append(rec)

        if idx % 25 == 0 or idx == len(samples):
            print(f"  processed {idx}/{len(samples)} samples", flush=True)
    return per_analyzer


def summarize(records):
    """Build the before/after summary on the measurable subset for one analyzer."""
    measurable = [r for r in records
                  if r.get("orig_flagged") and not r.get("unreliable")
                  and "skipped" not in r and "orig_score" in r]
    improved = [r for r in measurable if r["rep_score"] < r["orig_score"]]
    unchanged = [r for r in measurable if r["rep_score"] == r["orig_score"]]
    worse = [r for r in measurable if r["rep_score"] > r["orig_score"]]
    fully_clean = [r for r in measurable if r["rep_score"] == 0]
    deltas = [r["rep_score"] - r["orig_score"] for r in measurable]

    n = len(measurable)
    unreliable_n = sum(1 for r in records if r.get("unreliable"))
    skipped_n = sum(1 for r in records if "skipped" in r)
    fc_lo, fc_hi = wilson_ci(len(fully_clean), n) if n else (0.0, 0.0)

    return {
        "total_records": len(records),
        "skipped_empty": skipped_n,
        "unreliable_parse": unreliable_n,
        "measurable_n": n,
        "improved": len(improved), "improved_pct": (100 * len(improved) / n) if n else 0.0,
        "unchanged": len(unchanged), "unchanged_pct": (100 * len(unchanged) / n) if n else 0.0,
        "worse": len(worse), "worse_pct": (100 * len(worse) / n) if n else 0.0,
        "fully_clean": len(fully_clean), "fully_clean_pct": (100 * len(fully_clean) / n) if n else 0.0,
        "fully_clean_wilson_ci": [round(fc_lo, 4), round(fc_hi, 4)],
        "improved_to_worse_ratio": (len(improved) / len(worse)) if worse else None,
        "wilcoxon": wilcoxon_delta(deltas),
        "worse_ids": [r["id"] for r in worse],
    }


def print_summary(analyzer, s):
    print(f"\n=== {analyzer.upper()} : before/after on measurable subset ===")
    print(f"  measurable (analyzer flagged original): n = {s['measurable_n']}")
    print(f"    improved   : {s['improved']:4d} ({s['improved_pct']:.1f}%)")
    print(f"    unchanged  : {s['unchanged']:4d} ({s['unchanged_pct']:.1f}%)")
    print(f"    worse      : {s['worse']:4d} ({s['worse_pct']:.1f}%)")
    print(f"    fully clean: {s['fully_clean']:4d} ({s['fully_clean_pct']:.1f}%)  "
          f"Wilson95 {s['fully_clean_wilson_ci']}")
    if s["improved_to_worse_ratio"] is not None:
        print(f"    improved:worse ratio = {s['improved_to_worse_ratio']:.1f} : 1")
    w = s["wilcoxon"]
    if w.get("p_value") is not None:
        print(f"    Wilcoxon signed-rank (H1: risk decreases): p = {w['p_value']:.4g} "
              f"(n_nonzero = {w['n_nonzero']})")
    else:
        print(f"    Wilcoxon: {w.get('note', 'n/a')}")
    print(f"  excluded: {s['skipped_empty']} empty, {s['unreliable_parse']} unreliable-parse")


def compare_methods(this_records, other_json, analyzers):
    """McNemar: for each analyzer, compare which method cleaned which shared sample."""
    other = json.loads(Path(other_json).read_text())
    print("\n=== CROSS-METHOD COMPARISON (McNemar exact) ===")
    for a in analyzers:
        if a not in other.get("per_analyzer_records", {}):
            print(f"  {a}: not present in {other_json}, skipping")
            continue
        this_map = {r["id"]: r for r in this_records[a] if "rep_clean" in r and not r.get("unreliable")}
        other_map = {r["id"]: r for r in other["per_analyzer_records"][a]
                     if "rep_clean" in r and not r.get("unreliable")}
        shared = [i for i in this_map if i in other_map
                  and (this_map[i]["orig_flagged"] or other_map[i]["orig_flagged"])]
        b = sum(1 for i in shared if this_map[i]["rep_clean"] and not other_map[i]["rep_clean"])
        c = sum(1 for i in shared if other_map[i]["rep_clean"] and not this_map[i]["rep_clean"])
        res = mcnemar_exact(b, c)
        both = sum(1 for i in shared if this_map[i]["rep_clean"] and other_map[i]["rep_clean"])
        print(f"  {a}: shared measurable = {len(shared)} | "
              f"this-only cleaned = {b}, other-only cleaned = {c}, both cleaned = {both} | "
              f"p = {res.get('p_value')}")


def main():
    ap = argparse.ArgumentParser(description="Before/after repair scoring with Cppcheck/Semgrep.")
    ap.add_argument("--jsonl", help="JSONL with one record per line (e.g. the CodeBLEU results file). "
                    "Reads --original_col/--repaired_col as JSON keys "
                    "(defaults: vulnerable_func / generated_patch).")
    ap.add_argument("--pairs_csv")
    ap.add_argument("--original_csv")
    ap.add_argument("--repaired_csv")
    ap.add_argument("--id_col", default="id")
    ap.add_argument("--original_col", default="func_before")
    ap.add_argument("--repaired_col", default="patched_code")
    ap.add_argument("--analyzers", default="cppcheck,semgrep",
                    help="comma-separated subset of: cppcheck,semgrep")
    ap.add_argument("--semgrep_configs", default="p/c,p/cwe-top-25",
                    help="comma-separated Semgrep configs (e.g. p/c,p/cwe-top-25,p/security-audit)")
    ap.add_argument("--file_ext", default=".c",
                    help=".c (default) or .cpp — .cpp reduces C++ parse noise but changes rule targeting")
    ap.add_argument("--strip_fences", action="store_true", default=True)
    ap.add_argument("--no_strip_fences", dest="strip_fences", action="store_false")
    ap.add_argument("--max_samples", type=int, default=0)
    ap.add_argument("--compare_json", help="a previous run's --out JSON, for a McNemar cross-method test")
    ap.add_argument("--out", default="repair_static_scores.json")
    args = ap.parse_args()

    if not args.jsonl and not args.pairs_csv and not (args.original_csv and args.repaired_csv):
        ap.error("provide --jsonl, OR --pairs_csv, OR both --original_csv and --repaired_csv")

    analyzers = [a.strip() for a in args.analyzers.split(",") if a.strip()]
    for a in analyzers:
        if a not in ANALYZERS:
            ap.error(f"unknown analyzer: {a}")
        if shutil.which(a) is None:
            ap.error(f"'{a}' not found on PATH. Install it (cppcheck: apt/brew; "
                     f"semgrep: pip install semgrep) or drop it from --analyzers.")
    configs = [c.strip() for c in args.semgrep_configs.split(",") if c.strip()]

    samples = load_samples(args)
    print(f"Loaded {len(samples)} samples. Analyzers: {analyzers}. "
          f"ext={args.file_ext} semgrep_configs={configs if 'semgrep' in analyzers else 'n/a'}")

    with tempfile.TemporaryDirectory() as tmp:
        per_analyzer = score_all(samples, analyzers, configs, args.file_ext, tmp)

    summaries = {a: summarize(per_analyzer[a]) for a in analyzers}
    for a in analyzers:
        print_summary(a, summaries[a])

    out = {
        "config": {"analyzers": analyzers, "semgrep_configs": configs,
                   "file_ext": args.file_ext, "n_samples": len(samples)},
        "summaries": summaries,
        "per_analyzer_records": per_analyzer,
    }
    Path(args.out).write_text(json.dumps(out, indent=2))
    print(f"\nSaved detailed results to {args.out}")

    if args.compare_json:
        compare_methods(per_analyzer, args.compare_json, analyzers)

    print("\n--- honest-use notes ---")
    print("* 'measurable' = analyzer flagged the ORIGINAL; matches your Flawfinder logic,")
    print("  so improved/unchanged/worse are directly comparable across analyzers.")
    print("* parse/include/macro findings are filtered out and syntaxError marks a sample")
    print("  'unreliable' (excluded), so improvement cannot be a parseability artifact.")
    print("* report improved AND worse together; do not switch analyzers to chase a nicer")
    print("  number — pick one, pre-commit, and report it in full.")


if __name__ == "__main__":
    main()