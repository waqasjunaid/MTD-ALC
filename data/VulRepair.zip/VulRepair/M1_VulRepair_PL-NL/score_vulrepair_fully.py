#!/usr/bin/env python3
"""
score_vulrepair_fully.py

Computes CodeBLEU and Flawfinder-verified improvement for VulRepair's
actual generated patches (raw_predictions/VulRepair_raw_preds.csv),
joined against test.csv (source=vulnerable_func, target=reference_fix)
by row order -- both files were produced by iterating the same
test_dataset in the same sequential order, so row i in one corresponds
to row i in the other. This fills in the metrics missing from the
exact-match-only comparison, since exact-match alone unfairly favors
VulRepair (trained explicitly to reproduce reference text) over a
non-reproduction-trained repair approach.

Usage:
    python score_vulrepair_fully.py \
        --test_csv data_ours/test.csv \
        --raw_preds raw_predictions/VulRepair_raw_preds.csv \
        --out vulrepair_full_scores.json
"""
import argparse
import csv
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


# ---- CodeBLEU (same normalize/fallback approach as repair_ablation_metrics.py) ----
def normalize_code(code: str) -> str:
    if code is None:
        return ""
    code = re.sub(r"//.*?$", "", code, flags=re.MULTILINE)
    code = re.sub(r"/\*.*?\*/", "", code, flags=re.DOTALL)
    code = re.sub(r"\s+", " ", code)
    return code.strip()


def compute_codebleu(patch: str, reference: str) -> float:
    try:
        from codebleu import calc_codebleu
        result = calc_codebleu([reference], [patch], lang="c",
                                weights=(0.25, 0.25, 0.25, 0.25))
        return float(result["codebleu"])
    except Exception:
        return _fallback_bleu4(patch, reference)


def _fallback_bleu4(hyp: str, ref: str) -> float:
    import math
    from collections import defaultdict
    hyp_t = normalize_code(hyp).split()
    ref_t = normalize_code(ref).split()
    if not hyp_t or not ref_t:
        return 0.0

    def ngrams(tokens, n):
        return [tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]

    precisions = []
    for n in range(1, 5):
        h = ngrams(hyp_t, n)
        r = ngrams(ref_t, n)
        if not h:
            precisions.append(0.0)
            continue
        r_counts = defaultdict(int)
        for g in r:
            r_counts[g] += 1
        overlap = 0
        h_counts = defaultdict(int)
        for g in h:
            h_counts[g] += 1
        for g, c in h_counts.items():
            overlap += min(c, r_counts.get(g, 0))
        precisions.append(overlap / len(h) if h else 0.0)
    if min(precisions) == 0:
        precisions = [max(p, 1e-9) for p in precisions]
    geo = math.exp(sum(math.log(p) for p in precisions) / 4)
    bp = 1.0 if len(hyp_t) > len(ref_t) else math.exp(1 - len(ref_t) / len(hyp_t))
    return bp * geo


# ---- Flawfinder ----
def check_flawfinder_available():
    if shutil.which("flawfinder") is None:
        print("ERROR: 'flawfinder' not found on PATH.")
        sys.exit(1)


def run_flawfinder(code: str, tmpdir: Path, name: str) -> int:
    path = tmpdir / f"{name}.c"
    path.write_text(code, encoding="utf-8", errors="replace")
    proc = subprocess.run(
        ["flawfinder", "--csv", "--minlevel=0", str(path)],
        capture_output=True, text=True, timeout=15,
    )
    if not proc.stdout.strip():
        return 0
    reader = csv.DictReader(proc.stdout.splitlines())
    total = 0
    for row in reader:
        try:
            total += int(row.get("Level", 0))
        except (ValueError, TypeError):
            continue
    return total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test_csv", required=True)
    ap.add_argument("--raw_preds", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    test_rows = list(csv.DictReader(open(args.test_csv, encoding="utf-8")))
    pred_rows = list(csv.DictReader(open(args.raw_preds, encoding="utf-8")))

    if len(test_rows) != len(pred_rows):
        print(f"WARNING: row count mismatch (test.csv={len(test_rows)}, "
              f"raw_preds={len(pred_rows)}) -- alignment may be wrong.")

    check_flawfinder_available()

    codebleu_scores = []
    flawfinder_before = []
    flawfinder_after = []
    n = min(len(test_rows), len(pred_rows))

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        for i in range(n):
            source = test_rows[i]["source"]
            reference = test_rows[i]["target"]
            patch = pred_rows[i]["raw_predictions"]

            cb = compute_codebleu(patch, reference)
            codebleu_scores.append(cb)

            fb = run_flawfinder(source, tmpdir, f"before_{i}")
            fa = run_flawfinder(patch, tmpdir, f"after_{i}")
            flawfinder_before.append(fb)
            flawfinder_after.append(fa)

    mean_codebleu = sum(codebleu_scores) / len(codebleu_scores)

    had_risk = [i for i in range(n) if flawfinder_before[i] > 0]
    improved = sum(1 for i in had_risk if flawfinder_after[i] < flawfinder_before[i])
    worse = sum(1 for i in had_risk if flawfinder_after[i] > flawfinder_before[i])
    unchanged = len(had_risk) - improved - worse

    print(f"n = {n}")
    print(f"Mean CodeBLEU: {mean_codebleu:.4f}")
    print(f"Flawfinder: {len(had_risk)}/{n} samples had a detectable issue in source")
    if had_risk:
        print(f"  improved: {improved}/{len(had_risk)} ({100*improved/len(had_risk):.1f}%)")
        print(f"  worse:    {worse}/{len(had_risk)} ({100*worse/len(had_risk):.1f}%)")
        print(f"  unchanged:{unchanged}/{len(had_risk)} ({100*unchanged/len(had_risk):.1f}%)")

    with open(args.out, "w") as f:
        json.dump({
            "n": n,
            "mean_codebleu": mean_codebleu,
            "flawfinder_had_risk": len(had_risk),
            "flawfinder_improved": improved,
            "flawfinder_worse": worse,
            "flawfinder_unchanged": unchanged,
        }, f, indent=2)
    print(f"\nSaved to {args.out}")


if __name__ == "__main__":
    main()
