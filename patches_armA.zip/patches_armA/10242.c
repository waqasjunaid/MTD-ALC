/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       10242  |  Dataset: bigvul
   Function:     unknown_10242
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for print_preview_data_service() to prevent potential null pointer dereference.
 */

void PrintPreviewUI::ClearAllPreviewData() {
  if (print_preview_data_service() != nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
    print_preview_data_service()->RemoveEntry(preview_ui_addr_str_);
  }
}