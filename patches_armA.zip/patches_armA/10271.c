/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       10271  |  Dataset: bigvul
   Function:     unknown_10271
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6012
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds check around pointer operation in __bpf_map_get()
 */

struct bpf_map *bpf_map_get_with_uref(u32 ufd)
{
	struct fd f = fdget(ufd);
	struct bpf_map *map;

	map = __bpf_map_get(f);
	if (IS_ERR(map))
		return map;
 
	if (!map) { /* FIX [CWE-690]: added bounds check to prevent NULL pointer dereference */
		fdput(f); /* FIX [CWE-404]: close file descriptor on error path */
		return ERR_PTR(-EINVAL);
	}
 
	bpf_map_inc(map, true); /* FIX [CWE-404]: ensure map is not NULL before incrementing refcount */
 	fdput(f);
 
 	return map;
}