/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       10421  |  Dataset: bigvul
   Function:     unknown_10421
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added NULL check for cJSON_New_Item() return value to prevent potential NULL pointer dereference.
 */

cJSON *cJSON_CreateObject( void )
{
	cJSON *item = cJSON_New_Item(); /* FIX [CWE-690]: checked for NULL return value */
	if ( item != NULL ) /* FIX [CWE-690]: explicit NULL check */
		item->type = cJSON_Object;
	return item;
}