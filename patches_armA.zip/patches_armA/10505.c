/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       10505  |  Dataset: bigvul
   Function:     __ip_select_ident
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6895
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for pointer 'iph' to prevent null pointer dereference.
 */

void __ip_select_ident(struct iphdr *iph, int segs)
{
	static u32 ip_idents_hashrnd __read_mostly;
	u32 hash, id;

	if (!iph) { /* FIX [CWE-476]: Prevent null pointer dereference */
		return;
	}

	net_get_random_once(&ip_idents_hashrnd, sizeof(ip_idents_hashrnd));

	hash = jhash_3words((__force u32)iph->daddr,
			    (__force u32)iph->saddr,
			    iph->protocol,
			    ip_idents_hashrnd);
	id = ip_idents_reserve(hash, segs);
	iph->id = htons(id);
}