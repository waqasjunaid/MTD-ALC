/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1051  |  Dataset: bigvul
   Function:     unknown_1051
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6103
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds checking for point.m_state to prevent unexpected behavior
 */

bool WebPagePrivate::dispatchTouchPointAsMouseEventToFullScreenPlugin(PluginView* pluginView, const Platform::TouchPoint& point)
{
    NPEvent npEvent;
    NPMouseEvent mouse;

    if (point.m_state < Platform::TouchPoint::TouchPressed || 
        point.m_state > Platform::TouchPoint::TouchStationary) {
        // Invalid touch state, do not process the event
        return false;
    }

    switch (point.m_state) {
    case Platform::TouchPoint::TouchPressed:
        mouse.type = MOUSE_BUTTON_DOWN;
        break;
    case Platform::TouchPoint::TouchReleased:
        mouse.type = MOUSE_BUTTON_UP;
        break;
    case Platform::TouchPoint::TouchMoved:
        mouse.type = MOUSE_MOTION;
        break;
    case Platform::TouchPoint::TouchStationary:
        return true; /* FIX [CWE-20]: Avoid processing invalid touch state */
    }

    // Validate screen position coordinates
    if (point.m_screenPos.x() < 0 || point.m_screenPos.y() < 0) {
        // Invalid screen position, do not process the event
        return false;
    }

    mouse.x = point.m_screenPos.x(); /* FIX [CWE-20]: Validate screen position */
    mouse.y = point.m_screenPos.y(); /* FIX [CWE-20]: Validate screen position */
    mouse.button = mouse.type != MOUSE_BUTTON_UP; /* FIX [CWE-20]: Ensure valid button state */
    mouse.flags = 0;
    npEvent.type = NP_MouseEvent;
    npEvent.data = &mouse;

    pluginView->dispatchFullScreenNPEvent(npEvent);
    return true;
}