/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       10573  |  Dataset: bigvul
   Function:     array_cleanup
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6912
   ============================================================ */

/*
 * CHANGES MADE:
 * - Added bounds check to prevent out-of-bounds access in the array.
 */

static void array_cleanup(char* arr[], int arr_size) {
    int i = 0;
    if (arr == NULL || arr_size <= 0) { /* FIX [CWE-119]: validate input */ 
        return;
    }
    for (i = 0; i < arr_size; i++) {
        if (i * 2 >= arr_size) { /* FIX [CWE-129]: bounds check */ 
            break;
        }
        if (arr[i * 2]) {
            efree(arr[i * 2]);
        }
    }
    efree(arr);
}