/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       10610  |  Dataset: bigvul
   Function:     unknown_10610
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5971
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for the 'window' parameter to prevent potential crashes.
 */

void PartialMagnificationController::OnWindowDestroying(aura::Window* window) {
   if (window == nullptr) { /* FIX [CWE-476]: Potential null pointer dereference */ 
     return;
   }
 
   CloseMagnifierWindow();
 
   aura::Window* new_root_window = GetCurrentRootWindow();
   if (new_root_window != window)
    SwitchTargetRootWindow(new_root_window);
 }