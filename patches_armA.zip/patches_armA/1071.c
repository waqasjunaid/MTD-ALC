/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1071  |  Dataset: bigvul
   Function:     unknown_1071
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6707
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds check around pointer operation on ohci->name.
 */

static int ohci_bus_start(OHCIState *ohci)
{
    ohci->eof_timer = timer_new_ns(QEMU_CLOCK_VIRTUAL,
                    ohci_frame_boundary,
                    ohci);
    if (ohci->eof_timer == NULL) {
        if (ohci->name != NULL) { /* FIX [CWE-124]: prevent null pointer dereference */
            trace_usb_ohci_bus_eof_timer_failed(ohci->name);
        }
        ohci_die(ohci);
        return 0;
    }

    if (ohci->name != NULL) { /* FIX [CWE-124]: prevent null pointer dereference */
        trace_usb_ohci_start(ohci->name);
    }

    /* Delay the first SOF event by one frame time as

    if (ohci->eof_timer == NULL) {
        if (ohci->name != NULL) { /* FIX [CWE-124]: prevent null pointer dereference */
            trace_usb_ohci_bus_eof_timer_failed(ohci->name);
        }
        ohci_die(ohci);
        return 0;
    }

    if (ohci->name != NULL) { /* FIX [CWE-124]: prevent null pointer dereference */
        trace_usb_ohci_start(ohci->name);
    }

    /* Delay the first SOF event by one frame time as
}

static void ohci_bus_stop(OHCIState *ohci)
{
    if (ohci->name != NULL) { /* FIX [CWE-124]: prevent null pointer dereference */
        trace_usb_ohci_stop(ohci->name);
    }
    if (ohci->eof_timer) {
        timer_del(ohci->eof_timer);
        timer_free(ohci->eof_timer);
    }
    ohci->eof_timer = NULL;
}