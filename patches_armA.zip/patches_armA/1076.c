/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1076  |  Dataset: bigvul
   Function:     LongOrNullAttributeAttributeSetter
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6787
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds check around pointer operation in line 13
 */

static void LongOrNullAttributeAttributeSetter(
    v8::Local<v8::Value> v8_value, const v8::FunctionCallbackInfo<v8::Value>& info) {
  v8::Isolate* isolate = info.GetIsolate();
  ALLOW_UNUSED_LOCAL(isolate);

  v8::Local<v8::Object> holder = info.Holder();
  ALLOW_UNUSED_LOCAL(holder);

  TestObject* impl = V8TestObject::ToImpl(holder);
 
   ExceptionState exception_state(isolate, ExceptionState::kSetterContext, "TestObject", "longOrNullAttribute");
 
  int32_t cpp_value;
  if (v8_value->IsInt32()) { /* FIX [CWE-119]: bounds check */
    cpp_value = NativeValueTraits<IDLLong>::NativeValue(info.GetIsolate(), v8_value, exception_state);
  } else {
    // handle non-int32 value
    return;
  }
   if (exception_state.HadException())
     return;
 
  bool is_null = IsUndefinedOrNull(v8_value);
   impl->setLongOrNullAttribute(cpp_value, is_null);
 }