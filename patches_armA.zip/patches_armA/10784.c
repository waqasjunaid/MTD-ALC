/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       10784  |  Dataset: bigvul
   Function:     unknown_10784
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5819
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for pointer operations on 'script_state' and 'options'
 */

ImageBitmapFactories::ImageBitmapLoader::ImageBitmapLoader(
     ImageBitmapFactories& factory,
     base::Optional<IntRect> crop_rect,
     ScriptState* script_state, /* FIX [CWE-119]: Validate input pointers */
     const ImageBitmapOptions* options) /* FIX [CWE-119]: Validate input pointers */
    : loader_(
           FileReaderLoader::Create(FileReaderLoader::kReadAsArrayBuffer, this)),
       factory_(&factory),
       resolver_(script_state ? ScriptPromiseResolver::Create(script_state) : nullptr), /* FIX [CWE-119]: Check for null pointer before use */
       crop_rect_(crop_rect),
       options_(options ? options : &ImageBitmapOptions()) { /* FIX [CWE-119]: Provide default value if input is null */ }