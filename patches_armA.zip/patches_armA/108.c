/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       108  |  Dataset: bigvul
   Function:     unknown_108
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/*
 * CHANGES:
 * - Added null check for current_utterance_->profile() to prevent potential null pointer dereference.
 */

void ExtensionTtsController::Stop() {
  if (current_utterance_ && !current_utterance_->extension_id().empty()) {
    if (current_utterance_->profile()) { /* FIX [CWE-476]: Prevent null pointer dereference */
      current_utterance_->profile()->GetExtensionEventRouter()->
          DispatchEventToExtension(
              current_utterance_->extension_id(),
              events::kOnStop,
              "[]",
              current_utterance_->profile(),
              GURL());
    }
  } else {
    GetPlatformImpl()->clear_error();
    GetPlatformImpl()->StopSpeaking();
   }
 
  if (current_utterance_)
    current_utterance_->set_error(kSpeechInterruptedError);
  FinishCurrentUtterance();
  ClearUtteranceQueue();
}