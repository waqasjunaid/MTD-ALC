/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       10839  |  Dataset: bigvul
   Function:     unknown_10839
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * CHANGES:
 * - Added explicit null checks for pairing_delegate_ and agent_ before using them.
 */

void BluetoothDeviceChromeOS::UnregisterAgent() {
  if (!agent_.get())
    return;
  DCHECK(pairing_delegate_);
  DCHECK(pincode_callback_.is_null());
  DCHECK(passkey_callback_.is_null());
  DCHECK(confirmation_callback_.is_null());
  if (pairing_delegate_) { /* FIX [CWE-476]: potential null pointer dereference */
    pairing_delegate_->DismissDisplayOrConfirm();
  }
  pairing_delegate_ = NULL;
  if (agent_) { /* FIX [CWE-476]: potential null pointer dereference */
    agent_.reset();
  }
  VLOG(1) << object_path_.value() << ": Unregistering pairing agent";
  DBusThreadManager* dbus_thread_manager = DBusThreadManager::Get(); /* FIX [CWE-476]: potential null pointer dereference */
  if (dbus_thread_manager) {
    dbus_thread_manager->GetBluetoothAgentManagerClient()->
        UnregisterAgent(
            dbus::ObjectPath(kAgentPath),
            base::Bind(&base::DoNothing),
            base::Bind(&BluetoothDeviceChromeOS::OnUnregisterAgentError,
                       weak_ptr_factory_.GetWeakPtr()));
  }
}