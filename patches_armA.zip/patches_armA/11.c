/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11  |  Dataset: bigvul
   Function:     CloudPrintInfoCallback
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * Changes made:
 * - Added input validation for the 'email' and 'proxy_id' parameters
 */

static void CloudPrintInfoCallback(bool enabled,
                                     const std::string& email, /* FIX [CWE-20]: Validate all inputs */
                                     const std::string& proxy_id) { /* FIX [CWE-20]: Validate all inputs */
    if (!email.empty() && !proxy_id.empty()) { /* FIX [CWE-20]: Check for empty strings */
        QuitMessageLoop();
    }
}