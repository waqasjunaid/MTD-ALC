/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11001  |  Dataset: bigvul
   Function:     unknown_11001
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added a null pointer check for the 'library' parameter.
 */

void CrosLibrary::TestApi::SetBrightnessLibrary(
    BrightnessLibrary* library, bool own) {
  if (library != nullptr) { /* FIX [CWE-690]: Validate input to prevent NULL pointer dereference */
    library_->brightness_lib_.SetImpl(library, own);
  }
}