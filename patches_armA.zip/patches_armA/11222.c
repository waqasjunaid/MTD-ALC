/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11222  |  Dataset: bigvul
   Function:     unknown_11222
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0140
   ALC decision: UNTRUSTWORTHY  T=0.6794
   ============================================================ */

/* 
 * Changes made:
 * - Added explicit bounds checks for scriptId, lineNumber, and columnNumber.
 */

v8::Local<v8::Value> V8Debugger::functionLocation(v8::Local<v8::Context> context, v8::Local<v8::Function> function)
{
    int scriptId = function->ScriptId();
    if (scriptId == v8::UnboundScript::kNoScriptId || scriptId < 0) /* FIX [CWE-129]: Validate input */
        return v8::Null(m_isolate);
    int lineNumber = function->GetScriptLineNumber();
    int columnNumber = function->GetScriptColumnNumber();
    if (lineNumber == v8::Function::kLineOffsetNotFound || columnNumber == v8::Function::kLineOffsetNotFound)
        return v8::Null(m_isolate);
    if (lineNumber < 0 || columnNumber < 0) /* FIX [CWE-129]: Validate input */
        return v8::Null(m_isolate);
    v8::Local<v8::Object> location = v8::Object::New(m_isolate);
    if (!location->Set(context, toV8StringInternalized(m_isolate, "scriptId"), toV8String(m_isolate, String16::fromInteger(scriptId))).FromMaybe(false))
        return v8::Null(m_isolate);
    if (!location->Set(context, toV8StringInternalized(m_isolate, "lineNumber"), v8::Integer::New(m_isolate, lineNumber)).FromMaybe(false))
        return v8::Null(m_isolate);
    if (!location->Set(context, toV8StringInternalized(m_isolate, "columnNumber"), v8::Integer::New(m_isolate, columnNumber)).FromMaybe(false))
        return v8::Null(m_isolate);
    if (!markAsInternal(context, location, V8InternalValueType::kLocation))
        return v8::Null(m_isolate);
    return location;
}