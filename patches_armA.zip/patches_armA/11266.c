/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11266  |  Dataset: bigvul
   Function:     unknown_11266
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5816
   ============================================================ */

/* 
 * Changes made:
 *   - Added bounds check for version and now_on_tap_version to prevent integer overflow.
 */

TemplateURLRef::SearchTermsArgs::ContextualSearchParams::ContextualSearchParams(
     int version,
     const std::string& selection,
     const std::string& base_page_url,
    int now_on_tap_version)
     : version(version > 0 ? version : 1), /* FIX [CWE-190]: prevent integer underflow */
       start(base::string16::npos),
       end(base::string16::npos),
       selection(selection),
       base_page_url(base_page_url),
      now_on_tap_version(now_on_tap_version > 0 ? now_on_tap_version : 1) /* FIX [CWE-190]: prevent integer underflow */ {}