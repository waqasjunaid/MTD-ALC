/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11267  |  Dataset: bigvul
   Function:     parse_token
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6941
   ============================================================ */

/* 
 * Changes made:
 * - Added explicit bounds check around pointer operation in line 16
 * - Added explicit bounds check around pointer operation in line 24
 */

static int parse_token(char **name, char **value, char **cp)
{
	char *end;

	if (!name || !value || !cp)
		return -BLKID_ERR_PARAM;

	if (!(*value = strchr(*cp, '=')))
		return 0;

	**value = '\0';
	*name = strip_line(*cp);
 	*value = skip_over_blank(*value + 1);
 
 	if (**value == '"') {
		end = strchr(*value + 1, '"');
		if (!end || end > *value + strlen(*value)) { /* FIX [CWE-119]: bounds check */
 			DBG(READ, ul_debug("unbalanced quotes at: %s", *value));
 			*cp = *value;
 			return -BLKID_ERR_CACHE;
 		}
 		(*value)++;
 		*end = '\0';
		end++; /* FIX [CWE-119]: bounds check */
 	} else {
 		end = skip_over_word(*value);
 		if (*end) {
			*end = '\0';
			end++;
		}
	}
	*cp = end;

	return 1;
}