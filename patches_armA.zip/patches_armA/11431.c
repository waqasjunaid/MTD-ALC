/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11431  |  Dataset: bigvul
   Function:     SetImePropertyActivated
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6909
   ============================================================ */

/* CHANGES:
 * - Added bounds check for key.c_str() to prevent potential null pointer dereference.
 */

virtual void SetImePropertyActivated(const std::string& key,
                                       bool activated) {
    if (!initialized_successfully_)
       return;
 
     DCHECK(!key.empty());
     if (key.c_str() != nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
        chromeos::SetImePropertyActivated(
            input_method_status_connection_, key.c_str(), activated);
     }
   }