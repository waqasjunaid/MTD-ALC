/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11743  |  Dataset: bigvul
   Function:     unknown_11743
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0145
   ALC decision: UNTRUSTWORTHY  T=0.6916
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for tif->tif_data to prevent potential null pointer dereference.
 */

OJPEGDecode(TIFF* tif, uint8* buf, tmsize_t cc, uint16 s)
 {
 	OJPEGState* sp = (OJPEGState*)tif->tif_data;
 	if (sp != NULL) { /* FIX [CWE-476]: prevent null pointer dereference */
 		(void)s;
 		if (sp->libjpeg_jpeg_query_style==0)
 		{
 			if (OJPEGDecodeRaw(tif,buf,cc)==0)
				return(0);
		}
		else
		{
			if (OJPEGDecodeScanlines(tif,buf,cc)==0)
				return(0);
		}
	}
	return(1); /* FIX [CWE-476]: ensure function always returns a value */
}