/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11850  |  Dataset: bigvul
   Function:     unknown_11850
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6123
   ============================================================ */

/* 
 * Changes made:
 * - Added explicit bounds check around pointer operation in line 15
 */

void DownloadResourceHandler::OnRequestRedirected(
    const net::RedirectInfo& redirect_info,
    network::ResourceResponse* response,
    std::unique_ptr<ResourceController> controller) {
  url::Origin new_origin(url::Origin::Create(redirect_info.new_url));
  if (!follow_cross_origin_redirects_ &&
      !first_origin_.IsSameOriginWith(new_origin)) {
    base::PostTaskWithTraits(
        FROM_HERE, {BrowserThread::UI},
        base::BindOnce(
            &NavigateOnUIThread, redirect_info.new_url, request()->url_chain(),
            Referrer(GURL(redirect_info.new_referrer),
                      Referrer::NetReferrerPolicyToBlinkReferrerPolicy(
                          redirect_info.new_referrer_policy)),
             (GetRequestInfo() != nullptr) ? /* FIX [CWE-476]: NULL pointer dereference */ 
                                            GetRequestInfo()->HasUserGesture() : false,
            (GetRequestInfo() != nullptr) ? /* FIX [CWE-476]: NULL pointer dereference */ 
                                           GetRequestInfo()->GetWebContentsGetterForRequest() : nullptr));
     controller->Cancel();
     return;
   }
  if (core_.OnRequestRedirected()) {
    controller->Resume();
  } else {
    controller->Cancel();
  }
}