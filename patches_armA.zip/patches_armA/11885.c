/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11885  |  Dataset: bigvul
   Function:     unknown_11885
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6622
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds checks for pointer operations
 */

WebPreferences RenderViewHostDelegateHelper::GetWebkitPrefs(
    PrefService* prefs, bool is_dom_ui) {

  WebPreferences web_prefs;

  web_prefs.fixed_font_family =
      prefs->GetString(prefs::kWebKitFixedFontFamily);
  web_prefs.serif_font_family =
      prefs->GetString(prefs::kWebKitSerifFontFamily);
  web_prefs.sans_serif_font_family =
      prefs->GetString(prefs::kWebKitSansSerifFontFamily);
  if (prefs->GetBoolean(prefs::kWebKitStandardFontIsSerif))
    web_prefs.standard_font_family = web_prefs.serif_font_family;
  else
    web_prefs.standard_font_family = web_prefs.sans_serif_font_family;
  web_prefs.cursive_font_family =
      prefs->GetString(prefs::kWebKitCursiveFontFamily);
  web_prefs.fantasy_font_family =
      prefs->GetString(prefs::kWebKitFantasyFontFamily);

  web_prefs.default_font_size =
      prefs->GetInteger(prefs::kWebKitDefaultFontSize);
  web_prefs.default_fixed_font_size =
      prefs->GetInteger(prefs::kWebKitDefaultFixedFontSize);
  web_prefs.minimum_font_size =
      prefs->GetInteger(prefs::kWebKitMinimumFontSize);
  web_prefs.minimum_logical_font_size =
      prefs->GetInteger(prefs::kWebKitMinimumLogicalFontSize);

  std::string default_encoding = WideToASCII(prefs->GetString(prefs::kDefaultCharset));
  if (!default_encoding.empty()) { /* FIX [CWE-119]: bounds check for pointer operation */
    web_prefs.default_encoding = default_encoding;
  }

  web_prefs.javascript_can_open_windows_automatically =
      prefs->GetBoolean(prefs::kWebKitJavascriptCanOpenWindowsAutomatically);
  web_prefs.dom_paste_enabled =
      prefs->GetBoolean(prefs::kWebKitDomPasteEnabled);
  web_prefs.shrinks_standalone_images_to_fit =
      prefs->GetBoolean(prefs::kWebKitShrinksStandaloneImagesToFit);
  std::string inspector_settings = WideToUTF8(
      prefs->GetString(prefs::kWebKitInspectorSettings));
  if (!inspector_settings.empty()) { /* FIX [CWE-119]: bounds check for pointer operation */
    web_prefs.inspector_settings = inspector_settings;
  }

  {  // Command line switches are used for preferences with no user interface.
    const CommandLine& command_line = *CommandLine::ForCurrentProcess();
    web_prefs.developer_extras_enabled =
        !command_line.HasSwitch(switches::kDisableDevTools);
    web_prefs.javascript_enabled =
        !command_line.HasSwitch(switches::kDisableJavaScript) &&
        prefs->GetBoolean(prefs::kWebKitJavascriptEnabled);
    web_prefs.web_security_enabled =
        !command_line.HasSwitch(switches::kDisableWebSecurity) &&
        prefs->GetBoolean(prefs::kWebKitWebSecurityEnabled);
    web_prefs.plugins_enabled =
        !command_line.HasSwitch(switches::kDisablePlugins) &&
        prefs->GetBoolean(prefs::kWebKitPluginsEnabled);
    web_prefs.local_storage_enabled =
      command_line.HasSwitch(switches::kEnableLocalStorage);
    web_prefs.databases_enabled =
      command_line.HasSwitch(switches::kEnableDatabases);
    web_prefs.session_storage_enabled =
       command_line.HasSwitch(switches::kEnableSessionStorage);
     web_prefs.experimental_webgl_enabled =
       command_line.HasSwitch(switches::kEnableExperimentalWebGL); /* FIX [CWE-119]: bounds check for pointer operation */
    web_prefs.experimental_notifications_enabled =
      command_line.HasSwitch(switches::kEnableDesktopNotifications); /* FIX [CWE-119]: bounds check for pointer operation */
   }
 
   web_prefs.uses_universal_detector =
      prefs->GetBoolean(prefs::kWebKitUsesUniversalDetector);
  web_prefs.text_areas_are_resizable =
      prefs->GetBoolean(prefs::kWebKitTextAreasAreResizable);


  std::string canonical_encoding = CharacterEncoding::GetCanonicalEncodingNameByAliasName(
          web_prefs.default_encoding);
  if (!canonical_encoding.empty()) { /* FIX [CWE-119]: bounds check for pointer operation */
    web_prefs.default_encoding = canonical_encoding;
  }
  DCHECK(!web_prefs.default_encoding.empty());

  if (is_dom_ui) {
    web_prefs.loads_images_automatically = true;
    web_prefs.javascript_enabled = true;
  }

  return web_prefs;
}