/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11920  |  Dataset: bigvul
   Function:     add_bytes_c
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6923
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds checking to prevent out-of-bounds access
 */

static void add_bytes_c(uint8_t *dst, uint8_t *src, int w){
    long i;
    if (w < 0) { /* FIX [CWE-119]: Negative size */ 
        return; 
    }
    for(i=0; i<=w-sizeof(long); i+=sizeof(long)){
        if ((i + sizeof(long)) > w) { /* FIX [CWE-119]: Out-of-bounds access */ 
            break;
        }
        long a = *(long*)(src+i);
        long b = *(long*)(dst+i);
        *(long*)(dst+i) = ((a&pb_7f) + (b&pb_7f)) ^ ((a^b)&pb_80);
    }
    for(; i<w; i++)
        if (i >= w) { /* FIX [CWE-119]: Out-of-bounds access */ 
            break;
        }
        dst[i+0] += src[i+0];
}