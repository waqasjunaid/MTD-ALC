/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11964  |  Dataset: bigvul
   Function:     unknown_11964
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for data_object to prevent potential crashes.
 */

bool ClipboardUtil::HasFilenames(IDataObject* data_object) {
  if (data_object == nullptr) { /* FIX [CWE-476]: Null pointer dereference */ 
    return false;
  }
  DCHECK(data_object);
  return HasData(data_object, Clipboard::GetCFHDropFormatType());
}