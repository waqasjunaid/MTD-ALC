/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       11976  |  Dataset: bigvul
   Function:     unknown_11976
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6132
   ============================================================ */

/*
 * Changes made:
 * - Added input validation for document_url
 */

bool RendererPermissionsPolicyDelegate::IsRestrictedUrl(
    const GURL& document_url,
    std::string* error) {
  if (document_url.is_empty()) { /* FIX [CWE-20]: Validate all inputs */
    if (error)
      *error = errors::kInvalidInput;
    return true;
  }

  if (dispatcher_->IsExtensionActive(kWebStoreAppId)) {
    if (error)
      *error = errors::kCannotScriptGallery;
     return true;
   }
 
  if (SearchBouncer::GetInstance()->IsNewTabPage(document_url)) {
     if (error)
       *error = errors::kCannotScriptNtp;
     return true;
  }

  return false;
}