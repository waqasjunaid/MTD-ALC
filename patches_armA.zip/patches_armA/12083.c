/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       12083  |  Dataset: bigvul
   Function:     SetUp
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5997
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for video_ pointer before calling Init() and Begin()
 * - Added bounds check for decoder_ pointer after allocation
 */

virtual void SetUp() {
    video_ = new libvpx_test::WebMVideoSource(kVP9TestFile);
    ASSERT_TRUE(video_ != NULL);

    if (video_) { /* FIX [CWE-476]: Bounds check for video_ */
        video_->Init();
        video_->Begin();
    }

    vpx_codec_dec_cfg_t cfg = {0};
    decoder_ = new libvpx_test::VP9Decoder(cfg, 0);
    if (decoder_) { /* FIX [CWE-476]: Bounds check for decoder_ */
        // No action needed, just ensuring it's not NULL
    }
}