/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       12218  |  Dataset: bigvul
   Function:     unknown_12218
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6715
   ============================================================ */

/* CHANGES MADE:
 * - Added explicit bounds checks around pointer operations.
 */

Document* LocalDOMWindow::InstallNewDocument(const String& mime_type,
                                             const DocumentInit& init,
                                             bool force_xhtml) {
  DCHECK_EQ(init.GetFrame(), GetFrame());

  ClearDocument();

  document_ = CreateDocument(mime_type, init, force_xhtml);
  event_queue_ = DOMWindowEventQueue::Create(document_.Get());
  document_->Initialize();

  if (!GetFrame())
    return document_;

  GetFrame()->GetScriptController().UpdateDocument();
  document_->UpdateViewportDescription();

  if (GetFrame() && GetFrame()->GetPage() && GetFrame()->View()) { /* FIX [CWE-119]: Added bounds check for GetFrame() */
    if (GetFrame()->GetPage()->GetChromeClient()) { /* FIX [CWE-119]: Added bounds check for GetChromeClient() */
      GetFrame()->GetPage()->GetChromeClient().InstallSupplements(*GetFrame());

      ScrollingCoordinator* scrolling_coordinator =
          GetFrame()->GetPage()->GetScrollingCoordinator();
      if (scrolling_coordinator) { /* FIX [CWE-119]: Added bounds check for GetScrollingCoordinator() */
        scrolling_coordinator->ScrollableAreaScrollbarLayerDidChange(
            GetFrame()->View(), kHorizontalScrollbar);
        scrolling_coordinator->ScrollableAreaScrollbarLayerDidChange(
            GetFrame()->View(), kVerticalScrollbar);
        scrolling_coordinator->ScrollableAreaScrollLayerDidChange(
            GetFrame()->View());
      }
    }
  }

  if (GetFrame()) { /* FIX [CWE-119]: Added bounds check for GetFrame() */
    GetFrame()->Selection().UpdateSecureKeyboardEntryIfActive();
    if (GetFrame()->IsCrossOriginSubframe())
      document_->RecordDeferredLoadReason(WouldLoadReason::kCreated);
  }

  return document_;
}