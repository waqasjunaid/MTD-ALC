/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       12339  |  Dataset: bigvul
   Function:     RemoveClientSession
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * CHANGES MADE:
 * - Added a null check for context_.network_message_loop() to prevent potential crashes.
 */

void RemoveClientSession() {
    if (context_.network_message_loop()) { /* FIX [CWE-476]: Prevent NULL pointer dereference */
        context_.network_message_loop()->PostTask(
            FROM_HERE, base::Bind(
                &ClientSession::OnConnectionClosed, client_, connection_));
    }
}