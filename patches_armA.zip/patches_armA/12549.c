/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       12549  |  Dataset: bigvul
   Function:     unknown_12549
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds check for pointer/array operations
 */

parse_field(netdissect_options *ndo, const char **pptr, int *len)
 {
     const char *s;

    if (*len <= 0 || !pptr || !*pptr) /* FIX [CWE-119]: Validate input */
	return NULL;
    if (*pptr > (const char *) ndo->ndo_snapend) /* FIX [CWE-119]: Bounds check for pointer operation */
	return NULL;
     s = *pptr;
    while (*pptr <= (const char *) ndo->ndo_snapend && *len >= 0 && **pptr) {
 	(*pptr)++;
 	if ((*pptr - (const char *) ndo->ndo_snapstart) > ndo->ndo_snaplen) { /* FIX [CWE-119]: Bounds check for pointer operation */
 		return NULL;
 	}
 	(*len)--;
     }
     if (*pptr <= (const char *) ndo->ndo_snapend && *len >= 0) { /* FIX [CWE-119]: Validate input before incrementing */
     	(*pptr)++;
     	(*len)--;
     } else {
     	return NULL;
     }
    if (*len < 0 || *pptr > (const char *) ndo->ndo_snapend)
	return NULL;
     return s;
 }