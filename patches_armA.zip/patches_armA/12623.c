/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       12623  |  Dataset: bigvul
   Function:     unknown_12623
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5979
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for `bound_vertex_array_object_` to prevent potential null pointer dereference.
 */

void WebGL2RenderingContextBase::deleteVertexArray(
     WebGLVertexArrayObject* vertex_array) {
  if (isContextLost() || !vertex_array)
     return;
 
   if (!vertex_array->IsDefaultObject() &&
      vertex_array == bound_vertex_array_object_)
    SetBoundVertexArrayObject(nullptr); /* FIX [CWE-476]: Prevent null pointer dereference */

  if (vertex_array != nullptr) { /* FIX [CWE-476]: Validate input */
    vertex_array->DeleteObject(ContextGL());
  }
}