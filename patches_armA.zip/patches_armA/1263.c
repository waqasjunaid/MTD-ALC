/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1263  |  Dataset: bigvul
   Function:     unknown_1263
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6123
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for pointer operations around overlayPage() and overlayView
 */

void InspectorOverlay::update()
{
    if (isEmpty()) {
        m_client->hideHighlight();
        return;
    }

    FrameView* view = m_page->mainFrame()->view();
    if (!view)
        return;
    IntRect viewRect = view->visibleContentRect();
    FrameView* overlayView = overlayPage() ? overlayPage()->mainFrame()->view() : nullptr; /* FIX [CWE-690]: Check for null pointer */

    if (!overlayView) {
        // Handle the case where overlayView is null
        return;
    }

    IntSize frameViewFullSize = view->visibleContentRect(ScrollableArea::IncludeScrollbars).size();
    IntSize size = m_size.isEmpty() ? frameViewFullSize : m_size;
    size.scale(m_page->pageScaleFactor());
    overlayView->resize(size);

    reset(size, m_size.isEmpty() ? IntSize() : frameViewFullSize, viewRect.x(), viewRect.y());

    drawGutter();
    drawNodeHighlight();
    drawQuadHighlight();
     if (!m_inspectModeEnabled)
         drawPausedInDebuggerMessage();
     drawViewSize();
    drawOverridesMessage();

    if (overlayPage()) { /* FIX [CWE-690]: Check for null pointer */
        overlayPage()->mainFrame()->document()->recalcStyle(Force);
    }
    if (overlayView->needsLayout())
        overlayView->layout();

    m_client->highlight();
}