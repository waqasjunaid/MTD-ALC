/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       12735  |  Dataset: bigvul
   Function:     unknown_12735
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6170
   ============================================================ */

/*
 * Changes made:
 * - Added input validation for form_was_autofilled and available_field_types
 */

bool AutofillDownloadManager::StartUploadRequest(
    const FormStructure& form,
    bool form_was_autofilled,
    const FieldTypeSet& available_field_types) {
  if (next_upload_request_ > base::Time::Now()) {
    VLOG(1) << "AutofillDownloadManager: Upload request is throttled.";
    return false;
  }

  double upload_rate = form_was_autofilled ? GetPositiveUploadRate() :
                                              GetNegativeUploadRate();
  
  // FIX [CWE-20]: Validate input to prevent unexpected behavior
  if (upload_rate < 0.0 || upload_rate > 1.0) {
    VLOG(1) << "AutofillDownloadManager: Invalid upload rate.";
    return false;
  }

  if (base::RandDouble() > upload_rate) {
     VLOG(1) << "AutofillDownloadManager: Upload request is ignored.";
     return false;
  }

  std::string form_xml;
  
  // FIX [CWE-20]: Validate input to prevent unexpected behavior
  if (!form.IsValid()) {
    VLOG(1) << "AutofillDownloadManager: Invalid form structure.";
    return false;
  }
  
  if (!form.EncodeUploadRequest(available_field_types, form_was_autofilled,
                                &form_xml))
    return false;

  FormRequestData request_data;
  request_data.form_signatures.push_back(form.FormSignature());
  request_data.request_type = AutofillDownloadManager::REQUEST_UPLOAD;

  return StartRequest(form_xml, request_data);
}