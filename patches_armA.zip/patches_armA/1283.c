/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1283  |  Dataset: bigvul
   Function:     StoreAccumulatedContentLength
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds checks for input parameters to prevent potential integer overflows.
 */

void StoreAccumulatedContentLength(int received_content_length,
                                   int original_content_length,
                                   bool data_reduction_proxy_was_used) {
  if (received_content_length < 0 || original_content_length < 0) { /* FIX [CWE-190]: Prevent negative values */ 
    return;
  }
  BrowserThread::PostTask(BrowserThread::UI, FROM_HERE,
      base::Bind(&UpdateContentLengthPrefs,
                 received_content_length, original_content_length,
                data_reduction_proxy_was_used));
}