/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       12837  |  Dataset: bigvul
   Function:     readU32
   Dominant CWE: CWE-190
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6577
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds checking to prevent integer overflow
 */

static uint32_t readU32(const uint8_t* data, size_t offset) {
    if (offset > SIZE_MAX - 4) { /* FIX [CWE-190]: Prevent integer overflow */ 
        // handle_overflow(); /* TODO: implement error handling */
        return 0; /* temporary fix, replace with proper error handling */
    }
    uint32_t result = data[offset] << 24 | data[offset + 1] << 16 | data[offset + 2] << 8 | data[offset + 3];
    if (result < 0) { /* FIX [CWE-190]: Check for overflow */ 
        // handle_overflow(); /* TODO: implement error handling */
        return 0; /* temporary fix, replace with proper error handling */
    }
    return result;
}