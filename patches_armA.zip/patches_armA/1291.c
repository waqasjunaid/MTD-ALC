/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1291  |  Dataset: bigvul
   Function:     unknown_1291
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6695
   ============================================================ */

/* CHANGES MADE:
 * - Added explicit bounds check for pointer pReader.
 * - Added explicit bounds check for array access in ParseElementHeader and ParseEdition.
 */

long Chapters::Parse()
{
    IMkvReader* const pReader = m_pSegment->m_pReader;
    if (pReader == nullptr) { /* FIX [CWE-476]: null pointer dereference */ return -1; }
    long long pos = m_start;  // payload start
    const long long stop = pos + m_size;  // payload stop
    while (pos < stop)
    {
        long long id, size;
        if ((pos + sizeof(long long) * 2) > stop) { /* FIX [CWE-119]: buffer overflow */ break; }
        long status = ParseElementHeader(
                        pReader,
                        pos,
                        stop,
                        id,
                        size);
        if (status < 0)  // error
            return status;
        if (size == 0)  // weird
            continue;
        if ((pos + size) > stop) { /* FIX [CWE-119]: buffer overflow */ break; }
        if (id == 0x05B9)  // EditionEntry ID
        {
            status = ParseEdition(pos, size);
            if (status < 0)  // error
                return status;
        }
        pos += size;
        assert(pos <= stop);
     }
 
    assert(pos == stop);
    return 0;
 }