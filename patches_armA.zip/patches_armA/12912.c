/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       12912  |  Dataset: bigvul
   Function:     unknown_12912
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6098
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for response_code to prevent potential out-of-bounds access.
 */

void HostPortAllocatorSession::OnSessionRequestDone(
    UrlFetcher* url_fetcher,
    const net::URLRequestStatus& status,
    int response_code,
    const std::string& response) {
  url_fetchers_.erase(url_fetcher);
  delete url_fetcher;
 
  if (response_code < net::HTTP_MIN_STATUS_CODE || response_code > net::HTTP_MAX_STATUS_CODE) { /* FIX [CWE-129]: Validate response_code bounds */
     LOG(ERROR) << "Invalid response code: " << response_code;
     return;
   }
 
   if (response_code != net::HTTP_OK) {
     LOG(WARNING) << "Received error when allocating relay session: "
                 << response_code;
     TryCreateRelaySession();
     return;
   }
 
   ReceiveSessionResponse(response);
 }