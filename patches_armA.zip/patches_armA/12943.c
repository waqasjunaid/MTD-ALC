/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       12943  |  Dataset: bigvul
   Function:     unknown_12943
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6098
   ============================================================ */

/*
 * CHANGES:
 * - Added explicit bounds check for pointer operation on 'response'
 */

void ServiceWorkerPaymentInstrument::OnPaymentAppInvoked(
     mojom::PaymentHandlerResponsePtr response) {
  DCHECK(delegate_);
  if (delegate_ != nullptr && response != nullptr) { /* FIX [CWE-476]: Validate input pointer */
    delegate_->OnInstrumentDetailsReady(response->method_name,
                                         response->stringified_details);
    delegate_ = nullptr;
  }
}