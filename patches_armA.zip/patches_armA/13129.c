/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13129  |  Dataset: bigvul
   Function:     TestPlaybackRate
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6900
   ============================================================ */

/*
 * CHANGES:
 * - Added input validation for playback_rate
 */

void TestPlaybackRate(double playback_rate) {
    if (playback_rate <= 0.0) { /* FIX [CWE-189]: Validate all inputs */
        // Handle invalid playback rate, e.g., return an error or set to a default value
        return;
    }

    static const int kDefaultBufferSize = kSamplesPerSecond / 10;
    static const int kDefaultFramesRequested = 5 * kSamplesPerSecond;

    TestPlaybackRate(playback_rate, kDefaultBufferSize,
                     kDefaultFramesRequested);
}