/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13167  |  Dataset: bigvul
   Function:     unknown_13167
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES MADE:
 *   - Added bounds checks for contentsSize and viewportSize to prevent potential integer overflows.
 */

Platform::IntPoint InRegionScrollableArea::calculateMaximumScrollPosition(const Platform::IntSize& viewportSize, const Platform::IntSize& contentsSize, float overscrollLimitFactor) const
{
    ASSERT(!allowsOverscroll());
    int maxWidth = std::max(contentsSize.width() - viewportSize.width(), 0); /* FIX [CWE-190]: Prevent integer overflow */
    if (maxWidth > INT_MAX - static_cast<int>(overscrollLimitFactor)) { /* FIX [CWE-190]: Check for potential overflow */
        maxWidth = INT_MAX;
    }
    int maxHeight = std::max(contentsSize.height() - viewportSize.height(), 0); /* FIX [CWE-190]: Prevent integer overflow */
    if (maxHeight > INT_MAX - static_cast<int>(overscrollLimitFactor)) { /* FIX [CWE-190]: Check for potential overflow */
        maxHeight = INT_MAX;
    }
    return Platform::IntPoint(maxWidth + overscrollLimitFactor, maxHeight + overscrollLimitFactor);
}