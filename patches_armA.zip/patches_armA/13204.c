/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13204  |  Dataset: bigvul
   Function:     big_key_crypto_init
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6110
   ============================================================ */

/* CHANGES MADE:
 *   - Added explicit bounds checks around pointer operations
 */

static int __init big_key_crypto_init(void)
{
	int ret = -EINVAL;
 
	/* init RNG */
	big_key_rng = crypto_alloc_rng(big_key_rng_name, 0, 0);
	if (IS_ERR(big_key_rng)) {
		big_key_rng = NULL; /* FIX [CWE-690]: Ensure pointer is set to NULL after error */
		return -EFAULT;
 	}
 
 	/* seed RNG */
	ret = crypto_rng_reset(big_key_rng, NULL, crypto_rng_seedsize(big_key_rng));
	if (ret) {
		/* FIX [CWE-252]: Check return value and handle potential errors */
		pr_err("Failed to reset RNG: %d\n", ret);
		goto error;
	}
 
 	/* init block cipher */
	big_key_skcipher = crypto_alloc_skcipher(big_key_alg_name,
						 0, CRYPTO_ALG_ASYNC);
	if (IS_ERR(big_key_skcipher)) {
		big_key_skcipher = NULL; /* FIX [CWE-690]: Ensure pointer is set to NULL after error */
		ret = -EFAULT;
		goto error;
 	}
 
 	return 0;
 
error:
 	crypto_free_rng(big_key_rng);
	big_key_rng = NULL;
 	return ret;
 }