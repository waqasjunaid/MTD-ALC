/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13214  |  Dataset: bigvul
   Function:     nbd_negotiate_continue
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * Changes made:
 * - Added input validation for ioc and opaque pointers
 */

static gboolean nbd_negotiate_continue(QIOChannel *ioc,
                                       GIOCondition condition,
                                       void *opaque)
{
    if (!ioc || !opaque) { /* FIX [CWE-690]: Validate all inputs */
        return FALSE;
    }
    qemu_coroutine_enter(opaque);
    return TRUE;
}