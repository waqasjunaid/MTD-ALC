/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13230  |  Dataset: bigvul
   Function:     unknown_13230
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds check for m_page pointer
 */

void WebPagePrivate::didComposite()
{
    if (!m_page || !m_page->settings()) /* FIX [CWE-476]: potential null pointer dereference */
        return;
    if (!m_page->settings()->developerExtrasEnabled())
        return;
    InspectorInstrumentation::didComposite(m_page);
}