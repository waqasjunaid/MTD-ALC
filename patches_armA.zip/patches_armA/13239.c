/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13239  |  Dataset: bigvul
   Function:     unknown_13239
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * Changes made:
 * - Added a null check for m_info.language to prevent potential null pointer dereference.
 */

const char* Track::GetLanguage() const
{
    /* FIX [CWE-476]: Prevent null pointer dereference by checking if m_info.language is not null */
    return (m_info.language != nullptr) ? m_info.language : "";
}