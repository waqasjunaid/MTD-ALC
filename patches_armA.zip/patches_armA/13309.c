/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13309  |  Dataset: bigvul
   Function:     unknown_13309
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added explicit bounds checks for input values 'x' and 'y'
 */

bool InputWindowInfo::frameContainsPoint(int32_t x, int32_t y) const {
    /* FIX [CWE-129]: Validate all inputs */
    if (x < INT32_MIN || x > INT32_MAX || y < INT32_MIN || y > INT32_MAX) {
        return false; /* Invalid input values */
    }
    return x >= frameLeft && x <= frameRight
            && y >= frameTop && y <= frameBottom;
}