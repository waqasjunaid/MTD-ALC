/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13358  |  Dataset: bigvul
   Function:     unknown_13358
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for size to prevent potential buffer overflow
 */

void GpuVideoDecodeAccelerator::OnDecode(
    base::SharedMemoryHandle handle, int32 id, int32 size) {
   DCHECK(video_decode_accelerator_.get());
   if (size > 0 && size <= std::numeric_limits<int32>::max()) { /* FIX [CWE-119]: bounds check for size */
     video_decode_accelerator_->Decode(media::BitstreamBuffer(id, handle, size));
   } else {
     // Handle invalid size error
   }
}