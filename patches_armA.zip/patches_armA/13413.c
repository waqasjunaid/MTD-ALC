/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13413  |  Dataset: bigvul
   Function:     ghash_final
   Dominant CWE: CWE-120
   Error source: AMBIGUOUS
   MTD verdict:  NON_VULNERABLE  V=0.0172
   ALC decision: UNTRUSTWORTHY  T=0.6733
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds checking to memcpy operation
 */

static int ghash_final(struct shash_desc *desc, u8 *dst)
{
	struct ghash_desc_ctx *dctx = shash_desc_ctx(desc);
 	struct ghash_ctx *ctx = crypto_shash_ctx(desc->tfm);
 	u8 *buf = dctx->buffer;
 
 	ghash_flush(ctx, dctx);
 	size_t len = GHASH_BLOCK_SIZE; /* FIX [CWE-120]: define explicit length */
 	memcpy(dst, buf, (len < sizeof(buf)) ? len : sizeof(buf)); /* FIX [CWE-120]: add bounds checking */
 
	return 0;
}