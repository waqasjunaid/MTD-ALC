/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13449  |  Dataset: bigvul
   Function:     DoTest
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6199
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for enum values
 */

void DoTest(ExternalProtocolHandler::BlockState block_state,
               shell_integration::DefaultWebClientState os_state,
               Action expected_action) {
    GURL url("mailto:test@test.com");
     EXPECT_FALSE(delegate_.has_prompted());
     EXPECT_FALSE(delegate_.has_launched());
     EXPECT_FALSE(delegate_.has_blocked());

    // Validate enum values
    if (block_state < ExternalProtocolHandler::BLOCK_STATE_MIN ||
        block_state > ExternalProtocolHandler::BLOCK_STATE_MAX) {
      LOG(ERROR) << "Invalid BlockState value";
      return;
    }
    if (os_state < shell_integration::DEFAULT_WEB_CLIENT_STATE_MIN ||
        os_state > shell_integration::DEFAULT_WEB_CLIENT_STATE_MAX) {
      LOG(ERROR) << "Invalid DefaultWebClientState value";
      return;
    }

    delegate_.set_block_state(block_state);
    delegate_.set_os_state(os_state);
    ExternalProtocolHandler::LaunchUrlWithDelegate(
        url, 0, 0, ui::PAGE_TRANSITION_LINK, true, &delegate_);
    content::RunAllTasksUntilIdle();

    // Validate expected_action value
    if (expected_action < Action::MIN || expected_action > Action::MAX) {
      LOG(ERROR) << "Invalid Action value";
      return;
    }

    EXPECT_EQ(expected_action == Action::PROMPT, delegate_.has_prompted());
    EXPECT_EQ(expected_action == Action::LAUNCH, delegate_.has_launched());
    EXPECT_EQ(expected_action == Action::BLOCK, delegate_.has_blocked());
  }