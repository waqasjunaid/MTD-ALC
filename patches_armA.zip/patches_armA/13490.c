/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13490  |  Dataset: bigvul
   Function:     unknown_13490
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6007
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds checks for src and dsp pointers
 * - Added check for null-terminated strings
 */

dns_resolver_match(const struct key *key,
		   const struct key_match_data *match_data)
 {
 	int slen, dlen, ret = 0;
 	const char *src = key->description, *dsp = match_data->raw_data;

	/* FIX [CWE-170]: Validate input pointers */
	if (!src || !dsp || strlen(src) == 0 || strlen(dsp) == 0)
		goto no_match;

	kenter("%s,%s", src, dsp);

	if (strcasecmp(src, dsp) == 0)
		goto matched;

	slen = strlen(src);
	dlen = strlen(dsp);
	if (slen <= 0 || dlen <= 0)
		goto no_match;
	if (src[slen - 1] == '.')
		slen--;
	if (dsp[dlen - 1] == '.')
		dlen--;
	if (slen != dlen || strncasecmp(src, dsp, slen) != 0)
		goto no_match;

matched:
	ret = 1;
no_match:
	kleave(" = %d", ret);
 	return ret;
 }