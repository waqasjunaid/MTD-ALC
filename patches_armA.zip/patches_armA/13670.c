/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13670  |  Dataset: bigvul
   Function:     ath_tx_aggr_sleep
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6618
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index 'tidno' to prevent out-of-bounds access.
 */

void ath_tx_aggr_sleep(struct ieee80211_sta *sta, struct ath_softc *sc,
		       struct ath_node *an)
{
	struct ath_atx_tid *tid;
	struct ath_atx_ac *ac;
	struct ath_txq *txq;
	bool buffered;
	int tidno;

 	for (tidno = 0; tidno < IEEE80211_NUM_TIDS && tidno >= 0; tidno++) { /* FIX [CWE-129]: Validate array index within bounds */
 		tid = &an->tid[tidno]; /* FIX [CWE-129]: Ensure 'tid' is accessed within valid range */

		if (!tid->sched)
			continue;
 		ac = tid->ac;
 		txq = ac->txq;
 
 		ath_txq_lock(sc, txq);
 
 		buffered = ath_tid_has_buffered(tid);
 
 		tid->sched = false;
		list_del(&tid->list);

		if (ac->sched) {
			ac->sched = false;
			list_del(&ac->list);
		}

		ath_txq_unlock(sc, txq);

		ieee80211_sta_set_buffered(sta, tidno, buffered);
	}
}