/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13698  |  Dataset: bigvul
   Function:     FireInvalidateUnknownVersion
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * Changes made:
 * - Added input validation for type_name
 */

void FireInvalidateUnknownVersion(const char* type_name) {
    if (!type_name || !*type_name) { /* FIX [CWE-20]: Validate input to prevent null pointer dereference */
        return;
    }
    const invalidation::ObjectId object_id(
        ipc::invalidation::ObjectSource::CHROME_SYNC, type_name);
    invalidation::AckHandle ack_handle("fakedata");
    EXPECT_CALL(mock_invalidation_client_, Acknowledge(ack_handle));
    client_.InvalidateUnknownVersion(&mock_invalidation_client_, object_id,
                                      ack_handle);
}