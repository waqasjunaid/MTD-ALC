/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13707  |  Dataset: bigvul
   Function:     getStrrtokenPos
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0215
   ALC decision: UNTRUSTWORTHY  T=0.6384
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for pointer operation on line 5
 */

static int getStrrtokenPos(char* str, int savedPos)
 {
 	int result =-1;
 	int i;
 	if (str == NULL || savedPos < 0) { /* FIX [CWE-120]: null pointer dereference and out-of-bounds access */
 		return -1;
 	}
 	for(i=savedPos-1; i>=0 && i < strlen(str); i--) { /* FIX [CWE-120]: bounds check for pointer operation */
 		if(isIDSeparator(*(str+i)) ){
 			/* delimiter found; check for singleton */
			if(i>=2 && isIDSeparator(*(str+i-2)) ){
				/* a singleton; so send the position of token before the singleton */
				result = i-2;
			} else {
				result = i;
			}
			break;
		}
	}
	if(result < 1){
		/* Just in case invalid locale e.g. '-x-xyz' or '-sl_Latn' */
		result =-1;
	}
	return result;
}