/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13798  |  Dataset: bigvul
   Function:     atusb_get_and_show_revision
   Dominant CWE: struct-array
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6528
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array indices in buffer
 */

static int atusb_get_and_show_revision(struct atusb *atusb)
{
	struct usb_device *usb_dev = atusb->usb_dev;
	unsigned char buffer[3];
	int ret;

	/* Get a couple of the ATMega Firmware values */
	ret = atusb_control_msg(atusb, usb_rcvctrlpipe(usb_dev, 0),
				ATUSB_ID, ATUSB_REQ_FROM_DEV, 0, 0,
				buffer, 3, 1000);
	if (ret >= 0) {
		if ((size_t)0 < sizeof(buffer)) { /* FIX [CWE-129]: validate array index */
			atusb->fw_ver_maj = buffer[0];
		}
		if ((size_t)1 < sizeof(buffer)) { /* FIX [CWE-129]: validate array index */
			atusb->fw_ver_min = buffer[1];
		}
		if ((size_t)2 < sizeof(buffer)) { /* FIX [CWE-129]: validate array index */
			atusb->fw_hw_type = buffer[2];

			dev_info(&usb_dev->dev,
				 "Firmware: major: %u, minor: %u, hardware type: %u\n",
				 atusb->fw_ver_maj, atusb->fw_ver_min, atusb->fw_hw_type);
		}
	}
	if (atusb->fw_ver_maj == 0 && atusb->fw_ver_min < 2) {
		dev_info(&usb_dev->dev,
			 "Firmware version (%u.%u) predates our first public release.",
			 atusb->fw_ver_maj, atusb->fw_ver_min);
 		dev_info(&usb_dev->dev, "Please update to version 0.2 or newer");
 	}

	return ret;
}