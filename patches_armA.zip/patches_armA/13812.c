/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13812  |  Dataset: bigvul
   Function:     unknown_13812
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * CHANGES MADE:
 * - Added a null pointer check for the 'provider_info' parameter.
 */

void AutocompleteProvider::AddProviderInfo(
    ProvidersInfo* provider_info) const {
  if (provider_info != nullptr) { /* FIX [CWE-476]: Null pointer dereference prevention */
    // Rest of the function remains unchanged
  }
}