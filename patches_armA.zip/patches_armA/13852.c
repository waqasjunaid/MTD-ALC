/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13852  |  Dataset: bigvul
   Function:     tun_net_init
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0216
   ALC decision: UNTRUSTWORTHY  T=0.6976
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for tun->flags to prevent potential out-of-bounds access
 */

static void tun_net_init(struct net_device *dev)
{
	struct tun_struct *tun = netdev_priv(dev);

	if (tun == NULL) {
		return; /* FIX [CWE-690]: Prevent null pointer dereference */
	}

	switch (tun->flags & TUN_TYPE_MASK) {
	case TUN_TUN_DEV:
		dev->netdev_ops = &tun_netdev_ops;

		/* Point-to-Point TUN Device */
		dev->hard_header_len = 0;
		dev->addr_len = 0;
		dev->mtu = 1500;

		/* Zero header length */
		dev->type = ARPHRD_NONE;
		dev->flags = IFF_POINTOPOINT | IFF_NOARP | IFF_MULTICAST;
		dev->tx_queue_len = TUN_READQ_SIZE;  /* We prefer our own queue length */
		break;

	case TUN_TAP_DEV:
 		if (dev != NULL) { /* FIX [CWE-690]: Prevent null pointer dereference */
 			dev->netdev_ops = &tap_netdev_ops;
 		}
 		/* Ethernet TAP Device */
 		ether_setup(dev);
 
 		random_ether_addr(dev->dev_addr);
 
		dev->tx_queue_len = TUN_READQ_SIZE;  /* We prefer our own queue length */
		break;
	default:
		/* FIX [CWE-690]: Handle unknown tun->flags values */
		pr_err("Unknown TUN device type: %d\n", tun->flags & TUN_TYPE_MASK);
		return;
	}
}