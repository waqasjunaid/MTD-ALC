/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13936  |  Dataset: bigvul
   Function:     unknown_13936
   Dominant CWE: struct-cast
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5723
   ============================================================ */

/*
 * Changes made:
 * - Fixed struct-cast vulnerability by using a union to avoid casting between unrelated struct pointer types.
 */

static void *__alloc_from_pool(size_t size, struct page **ret_page, gfp_t flags)
{
	unsigned long val;
	union {
		void *ptr;
		unsigned long addr;
	} u;

	if (!atomic_pool) {
		WARN(1, "coherent pool not initialised!\n");
		return NULL;
	}

	val = gen_pool_alloc(atomic_pool, size);
	if (val) {
		phys_addr_t phys = gen_pool_virt_to_phys(atomic_pool, val);
 
 		*ret_page = phys_to_page(phys);
 		u.addr = val; /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */
 		void *ptr = u.ptr;
		if (flags & __GFP_ZERO)
			memset(ptr, 0, size);
 	}
 
 	return ptr;
}