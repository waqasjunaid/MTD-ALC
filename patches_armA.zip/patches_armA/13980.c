/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13980  |  Dataset: bigvul
   Function:     unknown_13980
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds checks for pointer operations
 */

hash_foreach_mangle_dict_of_strings (gpointer key, gpointer val, gpointer user_data)
{
  GHashTable *out = (GHashTable*) user_data;
  if (out == NULL) { /* FIX [CWE-690]: Prevent null pointer dereference */ 
    return; 
  }
  
  GHashTable *in_dict = (GHashTable *) val;
  if (in_dict == NULL) { /* FIX [CWE-690]: Prevent null pointer dereference */ 
    return; 
  }
  
  HashAndString *data = g_new0 (HashAndString, 1);
  if (data == NULL) { /* FIX [CWE-770]: Check for allocation failure */ 
    return; 
  }
  
  data->string = (gchar*) key;
  if (key == NULL) { /* FIX [CWE-690]: Prevent null pointer dereference */ 
    g_free(data); 
    return; 
  }
  
  data->hash = g_hash_table_new_full (g_str_hash, g_str_equal,
                                            g_free, g_free);
  if (data->hash == NULL) { /* FIX [CWE-770]: Check for allocation failure */ 
    g_free(data); 
    return; 
  }
  
  g_hash_table_foreach (in_dict, hash_foreach_prepend_string, data);
  g_hash_table_insert(out, g_strdup ((gchar*) key), data->hash);
}