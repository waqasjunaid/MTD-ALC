/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       13994  |  Dataset: bigvul
   Function:     unix_detach_fds
   Dominant CWE: struct-array
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6031
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index 'i' to prevent out-of-bounds access.
 */

static void unix_detach_fds(struct scm_cookie *scm, struct sk_buff *skb)
{
	int i;

	scm->fp = UNIXCB(skb).fp;
	UNIXCB(skb).fp = NULL;
 
	for (i = scm->fp->count-1; i >= 0; i--) {
		if ((size_t)i < scm->fp->count) { /* FIX [CWE-129]: Validate array index */
			unix_notinflight(scm->fp->fp[i]);
		}
	}
}