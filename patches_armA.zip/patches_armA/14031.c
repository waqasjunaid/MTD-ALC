/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14031  |  Dataset: bigvul
   Function:     unknown_14031
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for division by zero
 */

void MediaControlsProgressView::HandleSeeking(
    const gfx::Point& location_in_bar) {
  double progress_bar_width = progress_bar_->width();
  if (progress_bar_width == 0.0) { /* FIX [CWE-369]: prevent division by zero */
    return;
  }
  double seek_to_progress =
      static_cast<double>(location_in_bar.x()) / progress_bar_width; /* FIX [CWE-369]: added bounds check */
  seek_callback_.Run(seek_to_progress);
}