/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14057  |  Dataset: bigvul
   Function:     webkitWebViewBaseContainerAdd
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6783
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for widget pointer
 * - Added validation of WEBKIT_WEB_VIEW_BASE(widget) return value
 */

static void webkitWebViewBaseContainerAdd(GtkContainer* container, GtkWidget* widget)
{
    WebKitWebViewBase* webView = WEBKIT_WEB_VIEW_BASE(container);
    WebKitWebViewBasePrivate* priv = webView->priv;

    if (widget && /* FIX [CWE-119]: bounds check for pointer */ 
        WEBKIT_IS_WEB_VIEW_BASE(widget) &&
        WebInspectorProxy::isInspectorPage(WEBKIT_WEB_VIEW_BASE(widget)->priv->pageProxy.get())) {
         ASSERT(!priv->inspectorView);
         priv->inspectorView = widget;
        priv->inspectorViewHeight = gMinimumAttachedInspectorHeight;
     } else if (WEBKIT_IS_WEB_VIEW_BASE(widget) /* FIX [CWE-119]: validate return value */) {
         GtkAllocation childAllocation;
         gtk_widget_get_allocation(widget, &childAllocation);
        priv->children.set(widget, childAllocation);
    }

    gtk_widget_set_parent(widget, GTK_WIDGET(container));
}