/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14062  |  Dataset: bigvul
   Function:     unknown_14062
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6094
   ============================================================ */

/* 
 * CHANGES:
 * - Added bounds check for iterator in BlockedRequestMap
 * - Added bounds check for iterator in std::set<ProcessRouteIDs>
 */

ResourceDispatcherHost::~ResourceDispatcherHost() {
  AsyncResourceHandler::GlobalCleanup();
   STLDeleteValues(&pending_requests_);
 
   user_script_listener_->ShutdownMainThread();
  std::set<ProcessRouteIDs> ids;
  for (BlockedRequestMap::const_iterator iter = blocked_requests_map_.begin();
       iter != blocked_requests_map_.end(); ++iter) {
    if (!ids.empty() && iter->first >= ids.rbegin()->first) { /* FIX [CWE-129]: bounds check */ 
      continue; 
    }
    std::pair<std::set<ProcessRouteIDs>::iterator, bool> result =
        ids.insert(iter->first);
    DCHECK(result.second);
  }
  for (std::set<ProcessRouteIDs>::const_iterator iter = ids.begin();
       iter != ids.end(); ++iter) {
    if (!ids.empty() && *iter >= ids.rbegin()->second) { /* FIX [CWE-129]: bounds check */ 
      continue; 
    }
    CancelBlockedRequestsForRoute(iter->first, iter->second);
  }
 }