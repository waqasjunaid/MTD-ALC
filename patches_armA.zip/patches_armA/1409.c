/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1409  |  Dataset: bigvul
   Function:     unknown_1409
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6163
   ============================================================ */

/* 
 * Changes made:
 * 1. Added bounds check for pointer operations on dp and ip6.
 */

frag6_print(netdissect_options *ndo, register const u_char *bp, register const u_char *bp2)
{
	register const struct ip6_frag *dp;
	register const struct ip6_hdr *ip6;

	/* FIX [CWE-119]: Validate input pointer bp */
	if (bp == NULL || bp2 == NULL) {
		return -1;
	}

	dp = (const struct ip6_frag *)bp;
	ip6 = (const struct ip6_hdr *)bp2;

	/* FIX [CWE-119]: Check bounds for dp->ip6f_offlg access */
	if ((uintptr_t)dp < (uintptr_t)bp || (uintptr_t)dp > (uintptr_t)(bp + sizeof(struct ip6_frag))) {
		return -1;
	}

	ND_TCHECK(dp->ip6f_offlg);

	if (ndo->ndo_vflag) {
		/* FIX [CWE-119]: Check bounds for dp->ip6f_ident access */
		if ((uintptr_t)&dp->ip6f_ident < (uintptr_t)bp || (uintptr_t)&dp->ip6f_ident > (uintptr_t)(bp + sizeof(struct ip6_frag))) {
			return -1;
		}
		ND_PRINT((ndo, "frag (0x%08x:%d|%ld)",
		       EXTRACT_32BITS(&dp->ip6f_ident),
		       EXTRACT_16BITS(&dp->ip6f_offlg) & IP6F_OFF_MASK,
		       sizeof(struct ip6_hdr) + EXTRACT_16BITS(&ip6->ip6_plen) -
			       (long)(bp - bp2) - sizeof(struct ip6_frag)));
	} else {
		ND_PRINT((ndo, "frag (%d|%ld)",
		       EXTRACT_16BITS(&dp->ip6f_offlg) & IP6F_OFF_MASK,
		       sizeof(struct ip6_hdr) + EXTRACT_16BITS(&ip6->ip6_plen) -
			       (long)(bp - bp2) - sizeof(struct ip6_frag)));
	}

	/* it is meaningless to decode non-first fragment */
	if ((EXTRACT_16BITS(&dp->ip6f_offlg) & IP6F_OFF_MASK) != 0)
		return -1;
	else
	{
		ND_PRINT((ndo, " "));
		return sizeof(struct ip6_frag);
	}
trunc:
	ND_PRINT((ndo, "[|frag]"));
	return -1;
}