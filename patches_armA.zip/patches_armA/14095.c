/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14095  |  Dataset: bigvul
   Function:     AddObserver
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0183
   ALC decision: UNTRUSTWORTHY  T=0.6557
   ============================================================ */

/* 
 * Changes made:
 * - Added null check for observer pointer
 */

virtual void AddObserver(Observer* observer) {
  if (observer != nullptr) { /* FIX [CWE-476]: prevent null pointer dereference */
    if (!observers_.size()) {
      observer->FirstObserverIsAdded(this);
    }
    observers_.AddObserver(observer);
  } else {
    // handle error or log warning, e.g., "null observer passed to AddObserver"
  }
}