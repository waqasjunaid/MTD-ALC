/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14116  |  Dataset: bigvul
   Function:     unknown_14116
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6540
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds checking for array index access
 */

std::string SanitizeRevision(const std::string& revision) {
  if (revision.empty()) { /* FIX [CWE-129]: prevent out-of-bounds access */ return std::string(); }
  for (size_t i = 0; i < revision.length(); i++) {
    if (!(i >= 0 && i < revision.length() && revision[i] == '@' && i == 0) /* FIX [CWE-129]: validate array index */
        && !(i >= 0 && i < revision.length() && revision[i] >= '0' && revision[i] <= '9') /* FIX [CWE-129]: validate array index */
        && !(i >= 0 && i < revision.length() && revision[i] >= 'a' && revision[i] <= 'z') /* FIX [CWE-129]: validate array index */
        && !(i >= 0 && i < revision.length() && revision[i] >= 'A' && revision[i] <= 'Z')) { /* FIX [CWE-129]: validate array index */
      return std::string();
    }
  }
  return revision;
}