/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14212  |  Dataset: bigvul
   Function:     bt_for_each
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6578
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index 'i' in the outer loop.
 * - Added bounds checking for array index 'bit' in the inner loop.
 */

static void bt_for_each(struct blk_mq_hw_ctx *hctx,
		struct blk_mq_bitmap_tags *bt, unsigned int off,
		busy_iter_fn *fn, void *data, bool reserved)
{
	struct request *rq;
	int bit, i;

	for (i = 0; i < bt->map_nr; i++) {
		if ((size_t)i >= sizeof(bt->map) / sizeof(bt->map[0])) { /* FIX [CWE-129]: bounds check for array index 'i' */
			break;
		}
		struct blk_align_bitmap *bm = &bt->map[i];

 		for (bit = find_first_bit(&bm->word, bm->depth);
 		     bit < bm->depth && (size_t)bit < sizeof(bm->word) / sizeof(bm->word[0]); /* FIX [CWE-129]: bounds check for array index 'bit' */
 		     bit = find_next_bit(&bm->word, bm->depth, bit + 1)) {
		     	if ((off + bit) >= (1 << hctx->tags->bitmap_tags)) { /* FIX [CWE-129]: bounds check for array index 'off + bit' */
				break;
			}
 			rq = blk_mq_tag_to_rq(hctx->tags, off + bit);
 			if (rq->q == hctx->queue)
 				fn(hctx, rq, data, reserved);
 		}

		off += (1 << bt->bits_per_word);
	}
}