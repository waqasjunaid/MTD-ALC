/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14219  |  Dataset: bigvul
   Function:     ComputeInlineBoxPositionTemplate
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6947
   ============================================================ */

/* 
 * Changes made:
 * - Added explicit bounds checks around pointer operations.
 */

InlineBoxPosition ComputeInlineBoxPositionTemplate(
    const PositionTemplate<Strategy>& position,
    TextAffinity affinity,
    TextDirection primary_direction) {
  int caret_offset = position.ComputeEditingOffset();
  Node* const anchor_node = position.AnchorNode();
  LayoutObject* layout_object =
      anchor_node->IsShadowRoot()
          ? ToShadowRoot(anchor_node)->host().GetLayoutObject()
          : anchor_node->GetLayoutObject();

  DCHECK(layout_object) << position;

  if (layout_object->IsText()) {
    return ComputeInlineBoxPositionForTextNode(layout_object, caret_offset,
                                                affinity, primary_direction);
   }
 
  if (layout_object->IsLayoutBlockFlow()) {
    if (CanHaveChildrenForEditing(anchor_node) &&
        HasRenderedNonAnonymousDescendantsWithHeight(layout_object)) {
      const PositionTemplate<Strategy>& downstream_equivalent =
          DownstreamIgnoringEditingBoundaries(position);
      if (downstream_equivalent != position) {
        return ComputeInlineBoxPosition(
            downstream_equivalent, TextAffinity::kUpstream, primary_direction);
      }
      const PositionTemplate<Strategy>& upstream_equivalent =
          UpstreamIgnoringEditingBoundaries(position);
      if (upstream_equivalent == position ||
          DownstreamIgnoringEditingBoundaries(upstream_equivalent) == position)
        return InlineBoxPosition();
      return ComputeInlineBoxPosition(
          upstream_equivalent, TextAffinity::kUpstream, primary_direction);
    }
   }
 
  if (!layout_object->IsAtomicInlineLevel())
     return InlineBoxPosition();
  if (!layout_object->IsBox())
     return InlineBoxPosition();
  InlineBox* const inline_box = ToLayoutBox(layout_object)->InlineBoxWrapper();
  if (!inline_box) /* FIX [CWE-476]: null pointer dereference */
     return InlineBoxPosition();
  if (inline_box && (caret_offset > inline_box->CaretMinOffset() &&
                     caret_offset < inline_box->CaretMaxOffset())) /* FIX [CWE-119]: bounds check */
    return InlineBoxPosition(inline_box, caret_offset);
  LayoutStyle* style = layout_object->Style(); /* FIX [CWE-476]: null pointer dereference */
  if (style)
    return AdjustInlineBoxPositionForTextDirection(
        inline_box, caret_offset, style->GetUnicodeBidi(),
        primary_direction);
  return InlineBoxPosition();
 }