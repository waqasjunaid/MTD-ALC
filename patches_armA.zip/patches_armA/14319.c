/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14319  |  Dataset: bigvul
   Function:     unknown_14319
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added a null check for render_frame_ to prevent potential crashes.
 */

void DistillerNativeJavaScript::EnsureServiceConnected() {
  if (!distiller_js_service_) {
    if (render_frame_ && render_frame_->GetServiceRegistry()) { /* FIX [CWE-476]: Prevent null pointer dereference */
      render_frame_->GetServiceRegistry()->ConnectToRemoteService(
          mojo::GetProxy(&distiller_js_service_));
    }
  }
}