/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14362  |  Dataset: bigvul
   Function:     unknown_14362
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6205
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for format string to prevent potential buffer overflow
 */

report_error (const char *format, ...)
#else
report_error (format, va_alist)
     const char *format;
     va_dcl
#endif
{
  va_list args;

  error_prolog (1);

  SH_VA_START (args, format);

  if (format != NULL && strlen(format) < 1024) { /* FIX [CWE-120]: prevent buffer overflow */
    vfprintf (stderr, format, args);
    fprintf (stderr, "\n");
  } else {
    fprintf(stderr, "Error: invalid format string\n"); /* FIX [CWE-120]: handle error case */
  }
 
   va_end (args);
   if (exit_immediately_on_error)
    exit_shell (1);
 }