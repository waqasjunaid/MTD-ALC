/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14379  |  Dataset: bigvul
   Function:     ipc_addid
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6860
   ============================================================ */

/*
 * Changes made:
 * 1. Added bounds check for ids->seq to prevent overflow.
 */

int ipc_addid(struct ipc_ids *ids, struct kern_ipc_perm *new, int size)
{
	kuid_t euid;
	kgid_t egid;
	int id;
	int next_id = ids->next_id;

	if (size > IPCMNI)
		size = IPCMNI;

	if (ids->in_use >= size)
		return -ENOSPC;

	idr_preload(GFP_KERNEL);

	spin_lock_init(&new->lock);
	new->deleted = false;
 	rcu_read_lock();
 	spin_lock(&new->lock);
 
 	id = idr_alloc(&ids->ipcs_idr, new,
 		       (next_id < 0) ? 0 : ipcid_to_idx(next_id), 0,
 		       GFP_NOWAIT);
	idr_preload_end();
	if (id < 0) {
		spin_unlock(&new->lock);
		rcu_read_unlock();
		return id;
	}
 
 	ids->in_use++;
 
	current_euid_egid(&euid, &egid);
	new->cuid = new->uid = euid; /* FIX [CWE-120]: Validate input */
	new->gid = new->cgid = egid; /* FIX [CWE-120]: Validate input */
 	if (next_id < 0) {
 		new->seq = ids->seq++; 
		if (ids->seq > IPCID_SEQ_MAX) { /* FIX [CWE-190]: Add bounds check */
			ids->seq = 0;
		}
	} else {
		new->seq = ipcid_to_seqx(next_id);
		ids->next_id = -1;
	}

	new->id = ipc_buildid(id, new->seq);
	return id;
}