/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14399  |  Dataset: bigvul
   Function:     Sp_search
   Dominant CWE: struct-array
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5927
   ============================================================ */

/*
 * CHANGES:
 *   - Added bounds checking for array index access in line 19.
 */

static void Sp_search(js_State *J)
{
	js_Regexp *re;
	const char *text;
	Resub m;

	text = checkstring(J, 0);

	if (js_isregexp(J, 1))
		js_copy(J, 1);
	else if (js_isundefined(J, 1))
		js_newregexp(J, "", 0);
	else
		js_newregexp(J, js_tostring(J, 1), 0);
 
 	re = js_toregexp(J, -1);
 
	if (!js_regexec(re->prog, text, &m, 0)) {
 		size_t idx = m.sub[0].sp;
 		if (idx >= 0 && idx < strlen(text)) /* FIX [CWE-129]: bounds check */
 			js_pushnumber(J, js_utfptrtoidx(text, idx));
 		else
 			js_pushnumber(J, -1); /* or handle error */
 	}
 	else
 		js_pushnumber(J, -1);
}