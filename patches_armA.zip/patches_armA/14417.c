/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14417  |  Dataset: bigvul
   Function:     unknown_14417
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5975
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for index before using it to retrieve an entry from the header table.
 */

bool HpackDecoder::DecodeNextIndexedHeader(HpackInputStream* input_stream) {
  uint32 index = 0;
  if (!input_stream->DecodeNextUint32(&index))
    return false;

  /* FIX [CWE-129]: Added bounds check for index to prevent out-of-bounds access. */
  if (index >= header_table_.size())
    return false;

  HpackEntry* entry = header_table_.GetByIndex(index);
  if (entry == NULL)
    return false;
 
  HandleHeaderRepresentation(entry->name(), entry->value());
  return true;
}