/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14424  |  Dataset: bigvul
   Function:     tab_closed_
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6409
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for pointer operations
 */

PrintPreviewUI::PrintPreviewUI(content::WebUI* web_ui)
     : ConstrainedWebDialogUI(web_ui),
       initial_preview_start_time_(base::TimeTicks::Now()),
       handler_(NULL),
       source_is_modifiable_(true),
       tab_closed_(false) {
  Profile* profile = Profile::FromWebUI(web_ui);
  if (profile != NULL) { /* FIX [CWE-119]: prevent null pointer dereference */
    ChromeURLDataManager::AddDataSource(profile, new PrintPreviewDataSource());
  }

   handler_ = new PrintPreviewHandler();
   if (handler_ != NULL && web_ui != NULL) { /* FIX [CWE-119]: prevent null pointer dereference */
     web_ui->AddMessageHandler(handler_);
   }
 
  preview_ui_addr_str_ = GetPrintPreviewUIAddress();
  if (!preview_ui_addr_str_.empty() && g_print_preview_request_id_map.Get().IsValid()) { /* FIX [CWE-119]: prevent null pointer dereference and empty string */
    g_print_preview_request_id_map.Get().Set(preview_ui_addr_str_, -1);
  }
 }