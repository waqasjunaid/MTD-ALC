/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14491  |  Dataset: bigvul
   Function:     ipc_alloc
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6899
   ============================================================ */

/*
 * Changes made:
 * - Added input validation for 'size' parameter to prevent potential integer overflow.
 */

void* ipc_alloc(int size)
{
	void* out;
	if (size <= 0) { /* FIX [CWE-190]: validate input size */ 
		return NULL; /* FIX [CWE-190]: handle invalid input */
	}
	if(size > PAGE_SIZE)
 		out = vmalloc(size);
 	else
		out = kmalloc(size, GFP_KERNEL);
	return out;
}