/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14646  |  Dataset: bigvul
   Function:     copyStereo8
   Dominant CWE: CWE-190
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6540
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking to prevent overflow
 */

static void copyStereo8(
         short *dst,
        const int *const *src,
         unsigned nSamples,
         unsigned /* nChannels */) {
    if (nSamples > SIZE_MAX / 2) { /* FIX [CWE-190]: Prevent integer overflow */ 
        // handle_overflow(); /* TODO: implement error handling */
        return;
    }
     for (unsigned i = 0; i < nSamples; ++i) {
 *dst++ = src[0][i] << 8;
 *dst++ = src[1][i] << 8;

     }
 }