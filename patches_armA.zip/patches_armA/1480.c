/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1480  |  Dataset: bigvul
   Function:     unknown_1480
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6685
   ============================================================ */

/*
 * Changes made:
 * - Added a check to ensure the iterator is not equal to end() before dereferencing it
 */

void UserSelectionScreen::OnBeforeUserRemoved(const AccountId& account_id) {
  for (user_manager::UserList::iterator it = users_.begin(); it != users_.end();
       ++it) {
    if (it != users_.end() && (*it)->GetAccountId() == account_id) { /* FIX [CWE-476]: avoid potential null pointer dereference */
      users_.erase(it);
      break;
    }
  }
}