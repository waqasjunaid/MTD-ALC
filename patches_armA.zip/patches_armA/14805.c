/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14805  |  Dataset: bigvul
   Function:     weak_ptr_factory_
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added explicit bounds checks around pointer operations.
 */

PasswordAutofillAgent::PasswordAutofillAgent(content::RenderFrame* render_frame)
     : content::RenderFrameObserver(render_frame),
       logging_state_active_(false),
       was_username_autofilled_(false),
      was_password_autofilled_(false),
      weak_ptr_factory_(this) {
   if (render_frame != nullptr && routing_id() != 0) { /* FIX [CWE-476]: null pointer dereference */
     Send(new AutofillHostMsg_PasswordAutofillAgentConstructed(routing_id()));
   }
 }