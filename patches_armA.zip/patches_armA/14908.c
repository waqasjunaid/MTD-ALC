/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14908  |  Dataset: bigvul
   Function:     unknown_14908
   Dominant CWE: struct-array
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5602
   ============================================================ */

/* Changes made:
 * - Added bounds checking for dev_t to prevent potential out-of-bounds access
 */

static struct block_device *ext3_blkdev_get(dev_t dev, struct super_block *sb)
{
	struct block_device *bdev;
	char b[BDEVNAME_SIZE];

	/* FIX [CWE-129]: Validate dev_t value before passing it to blkdev_get_by_dev */
	if (dev < 0) {
		ext3_msg(sb, "error: invalid device number %d", dev);
		return NULL;
	}

	bdev = blkdev_get_by_dev(dev, FMODE_READ|FMODE_WRITE|FMODE_EXCL, sb);
	if (IS_ERR(bdev))
		goto fail;
 	return bdev;

fail:
	ext3_msg(sb, "error: failed to open journal device %s: %ld",
 		__bdevname(dev, b), PTR_ERR(bdev));

 	return NULL;
}