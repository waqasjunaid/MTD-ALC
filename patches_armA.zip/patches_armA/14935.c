/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14935  |  Dataset: bigvul
   Function:     unknown_14935
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added input validation for thread_checker_ (CWE-821)
 */

bool WebMediaPlayerMS::HasSingleSecurityOrigin() const {
  if (!thread_checker_) { /* FIX [CWE-821]: null pointer check */ 
    return false; /* FIX [CWE-821]: handle invalid state */
  }
  DCHECK(thread_checker_.CalledOnValidThread());
  return true;
}