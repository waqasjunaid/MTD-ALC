/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14937  |  Dataset: bigvul
   Function:     unknown_14937
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5814
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index access in instance_map_
 */

bool ResourceTracker::UnrefResource(PP_Resource res) {
  DLOG_IF(ERROR, !CheckIdType(res, PP_ID_TYPE_RESOURCE))
      << res << " is not a PP_Resource.";
  ResourceMap::iterator i = live_resources_.find(res);
  if (i != live_resources_.end()) {
    if (!--i->second.second) {
      Resource* to_release = i->second.first;
      PP_Instance instance = to_release->instance()->pp_instance();
      to_release->LastPluginRefWasDeleted(false);

      // FIX [CWE-129]: Validate array index is within bounds before access
      if (instance >= 0 && (size_t)instance < instance_map_.size()) {
        instance_map_[instance]->resources.erase(res);
      } else {
        DLOG(ERROR) << "Invalid instance index: " << instance;
      }

      live_resources_.erase(i);
    }
    return true;
  } else {
    return false;
  }
}