/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       14965  |  Dataset: bigvul
   Function:     RunMemCheck
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5994
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds checking for array indices in input_extreme_block and output_ref_block.
 */

void RunMemCheck() {
    ACMRandom rnd(ACMRandom::DeterministicSeed());
    const int count_test_block = 5000;
    DECLARE_ALIGNED_ARRAY(16, int16_t, input_block, kNumCoeffs);
    DECLARE_ALIGNED_ARRAY(16, int16_t, input_extreme_block, kNumCoeffs);
    DECLARE_ALIGNED_ARRAY(16, int16_t, output_ref_block, kNumCoeffs);
    DECLARE_ALIGNED_ARRAY(16, int16_t, output_block, kNumCoeffs);

    for (int i = 0; i < count_test_block; ++i) {
        for (int j = 0; j < kNumCoeffs; ++j) {
            input_block[j] = rnd.Rand8() - rnd.Rand8();
            if ((size_t)j < kNumCoeffs) { /* FIX [CWE-129]: bounds check */
                input_extreme_block[j] = rnd.Rand8() % 2 ? 255 : -255;
            }
        }
        if (i == 0)
            for (int j = 0; j < kNumCoeffs; ++j) {
                if ((size_t)j < kNumCoeffs) { /* FIX [CWE-129]: bounds check */
                    input_extreme_block[j] = 255;
                }
            }
        if (i == 1)
            for (int j = 0; j < kNumCoeffs; ++j) {
                if ((size_t)j < kNumCoeffs) { /* FIX [CWE-129]: bounds check */
                    input_extreme_block[j] = -255;
                }
            }

        fwd_txfm_ref(input_extreme_block, output_ref_block, pitch_, tx_type_);
        REGISTER_STATE_CHECK(RunFwdTxfm(input_extreme_block,
                                        output_block, pitch_));

        for (int j = 0; j < kNumCoeffs; ++j) {
            if ((size_t)j < kNumCoeffs) { /* FIX [CWE-129]: bounds check */
                EXPECT_EQ(output_block[j], output_ref_block[j]);
            }
            EXPECT_GE(4 * DCT_MAX_VALUE, abs(output_block[j]))
                << "Error: 16x16 FDCT has coefficient larger than 4*DCT_MAX_VALUE";
        }
    }
}