/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15196  |  Dataset: bigvul
   Function:     vapic_enter
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/* 
 * Changes made:
 *   Added explicit bounds check for apic->vapic_addr
 */

static int vapic_enter(struct kvm_vcpu *vcpu)
{
	struct kvm_lapic *apic = vcpu->arch.apic;
	struct page *page;
	if (!apic || !apic->vapic_addr) /* FIX [CWE-119]: Added bounds check for apic->vapic_addr */
		return 0;
	if (apic->vapic_addr >= MAX_PHYS_ADDR) { /* FIX [CWE-119]: Added explicit bounds check for vapic_addr */
		pr_err("Invalid vapic address: %llx\n", apic->vapic_addr);
		return -EINVAL;
	}
	page = gfn_to_page(vcpu->kvm, apic->vapic_addr >> PAGE_SHIFT);
	if (is_error_page(page))
		return -EFAULT;
	vcpu->arch.apic->vapic_page = page;
	return 0;
}