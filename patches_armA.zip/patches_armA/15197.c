/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15197  |  Dataset: bigvul
   Function:     unknown_15197
   Dominant CWE: struct-array
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5642
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index access in the `text` string.
 */

void TypingCommand::insertText(Document& document,
                               const String& text,
                               Options options,
                               TextCompositionType composition,
                               const bool isIncrementalInsertion) {
  LocalFrame* frame = document.frame();
  DCHECK(frame);

  if (!text.isEmpty()) {
    size_t idx = 0; /* FIX [CWE-129]: introduce index variable */
    if (idx >= 0 && (size_t)idx < text.length()) { /* FIX [CWE-129]: bounds check */
      document.frame()->spellChecker().updateMarkersForWordsAffectedByEditing(
          isSpaceOrNewline(text[idx])); /* FIX [CWE-129]: use index variable */
    }
  }

  insertText(document, text,
             frame->selection().computeVisibleSelectionInDOMTreeDeprecated(),
             options, composition, isIncrementalInsertion);
}