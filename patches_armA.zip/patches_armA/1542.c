/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1542  |  Dataset: bigvul
   Function:     unknown_1542
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5796
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds checking for array access in kHeadingIds
 */

string16 ExtensionInstallUI::Prompt::GetHeading(std::string extension_name)
    const {
   if (type_ == INLINE_INSTALL_PROMPT) {
     return UTF8ToUTF16(extension_name);
   } else {
    /* FIX [CWE-129]: Validate array index is within bounds before access */
    if ((size_t)type_ < ARRAY_LEN(kHeadingIds)) { 
      return l10n_util::GetStringFUTF16(
          kHeadingIds[type_], UTF8ToUTF16(extension_name));
    } else {
      /* Handle out-of-bounds error, e.g., return an empty string or throw an exception */
      return string16();
    }
  }
}