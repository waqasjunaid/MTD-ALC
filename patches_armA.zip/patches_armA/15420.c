/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15420  |  Dataset: bigvul
   Function:     set_register
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6755
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for indx to prevent potential out-of-bounds access
 */

static int set_register(pegasus_t *pegasus, __u16 indx, __u8 data)
{
	int ret;

	if (indx >= 0 && indx <= USHRT_MAX) { /* FIX [CWE-129]: bounds check for indx */
		ret = usb_control_msg(pegasus->usb, usb_sndctrlpipe(pegasus->usb, 0),
				      PEGASUS_REQ_SET_REG, PEGASUS_REQT_WRITE, data,
				      indx, &data, 1, 1000);
		if (ret < 0)
			netif_dbg(pegasus, drv, pegasus->net,
				  "%s returned %d\n", __func__, ret);
		return ret;
	} else {
		/* FIX [CWE-129]: handle out-of-bounds indx */
		netif_dbg(pegasus, drv, pegasus->net,
			  "Invalid indx value: %u\n", indx);
		return -EINVAL; /* Return an error code for invalid input */
	}
}