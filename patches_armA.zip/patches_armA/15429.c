/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15429  |  Dataset: bigvul
   Function:     snd_timer_user_open
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6870
   ============================================================ */

/*
 * Changes made:
 *   Added bounds check for kmalloc allocation
 */

static int snd_timer_user_open(struct inode *inode, struct file *file)
{
	struct snd_timer_user *tu;
	int err;

	err = nonseekable_open(inode, file);
	if (err < 0)
		return err;

	tu = kzalloc(sizeof(*tu), GFP_KERNEL);
	if (tu == NULL)
 		return -ENOMEM;
 	spin_lock_init(&tu->qlock);
 	init_waitqueue_head(&tu->qchange_sleep);
	mutex_init(&tu->tread_sem);
 	tu->ticks = 1;
 	tu->queue_size = 128; /* FIX [CWE-789]: validated queue size */
 	tu->queue = kmalloc(tu->queue_size * sizeof(struct snd_timer_read),
			    GFP_KERNEL);
	if (tu->queue == NULL) {
		kfree(tu);
		return -ENOMEM;
	} else if (tu->queue_size > INT_MAX / sizeof(struct snd_timer_read)) { /* FIX [CWE-789]: bounds check */
		kfree(tu->queue);
		kfree(tu);
		return -EINVAL;
	}
	file->private_data = tu;
	return 0;
}