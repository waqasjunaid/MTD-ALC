/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1550  |  Dataset: bigvul
   Function:     unknown_1550
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5781
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds checking for array index access in args.
 */

static v8::Handle<v8::Value> methodWithCallbackArgCallback(const v8::Arguments& args)
 {
     INC_STATS("DOM.TestObj.methodWithCallbackArg");
     if (args.Length() < 1) /* FIX [CWE-129]: validated array length */
        return V8Proxy::throwNotEnoughArgumentsError();
     TestObj* imp = V8TestObj::toNative(args.Holder());
     if (args.Length() > 0 && args[0]->IsFunction()) { /* FIX [CWE-129]: added bounds checking and flipped condition */
         RefPtr<TestCallback> callback = V8TestCallback::create(args[0], getScriptExecutionContext());
         imp->methodWithCallbackArg(callback);
         return v8::Handle<v8::Value>();
     }
    return throwError(TYPE_MISMATCH_ERR, args.GetIsolate()); /* FIX [CWE-129]: moved error handling outside of bounds check */
}