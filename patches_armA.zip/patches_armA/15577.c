/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15577  |  Dataset: bigvul
   Function:     build_l4proto_sctp
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6913
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for ct pointer
 * - Added return value check for nfct_attr_is_set function
 */

static void build_l4proto_sctp(const struct nf_conntrack *ct, struct nethdr *n)
{
    if (ct == NULL) { /* FIX [CWE-690]: null pointer dereference */ 
        return;
    }

	ct_build_group(ct, ATTR_GRP_ORIG_PORT, n, NTA_PORT,
		      sizeof(struct nfct_attr_grp_port));
 	if (!nfct_attr_is_set(ct, ATTR_SCTP_STATE)) {
 		int ret = nfct_attr_is_set(ct, ATTR_SCTP_STATE); /* FIX [CWE-253]: return value check */
 		if (ret < 0) { /* FIX [CWE-253]: handle error case */ 
 			return;
 		}
 		return;
 	}

 	ct_build_u8(ct, ATTR_SCTP_STATE, n, NTA_SCTP_STATE);
 	ct_build_u32(ct, ATTR_SCTP_VTAG_ORIG, n, NTA_SCTP_VTAG_ORIG);
 	ct_build_u32(ct, ATTR_SCTP_VTAG_REPL, n, NTA_SCTP_VTAG_REPL);
}