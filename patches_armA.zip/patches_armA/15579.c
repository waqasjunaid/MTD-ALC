/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15579  |  Dataset: bigvul
   Function:     dynamicGetbuf
   Dominant CWE: CWE-120
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6714
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Replaced memcpy with a safer alternative to prevent buffer overflow
 */

static int dynamicGetbuf(gdIOCtxPtr ctx, void *buf, int len)
{
	int rlen, remain;
	dpIOCtxPtr dctx;
	dynamicPtr *dp;

	dctx = (dpIOCtxPtr) ctx;
	dp = dctx->dp;

	remain = dp->logicalSize - dp->pos;
 	if(remain >= len) {
 		rlen = len;
 	} else {
		if(remain == 0) {
 			/* 2.0.34: EOF is incorrect. We use 0 for
 			 * errors and EOF, just like fileGetbuf,
 			 * which is a simple fread() wrapper.
			 * TBB. Original bug report: Daniel Cowgill. */
			return 0; /* NOT EOF */
		}

		rlen = remain;
	}

	/* FIX [CWE-120]: Prevent buffer overflow by using memmove with size check */
	memmove(buf, (void *) ((char *)dp->data + dp->pos), rlen < len ? rlen : len);
	dp->pos += rlen;

	return rlen;
}