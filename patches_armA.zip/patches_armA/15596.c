/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15596  |  Dataset: bigvul
   Function:     sem_getref_and_unlock
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/* 
 * Changes made:
 * - Added NULL check for sma to prevent potential null pointer dereference.
 */

static inline void sem_getref_and_unlock(struct sem_array *sma)
{
	if (sma != NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
		ipc_rcu_getref(sma);
		ipc_unlock(&(sma)->sem_perm); /* FIX [CWE-362]: Validate input to ipc_unlock */
	}
}