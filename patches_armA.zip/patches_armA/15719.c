/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15719  |  Dataset: bigvul
   Function:     unknown_15719
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6794
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added explicit bounds check around pointer operation in line 6
 */

void FragmentPaintPropertyTreeBuilder::UpdateFragmentClip() {
  DCHECK(properties_);

  if (NeedsPaintPropertyUpdate()) {
    if (context_.fragment_clip) {
      OnUpdateClip(properties_->UpdateFragmentClip(
         context_.current.clip,
          ClipPaintPropertyNode::State{context_.current.transform,
                                       ToClipRect(*context_.fragment_clip)}));
    } else {
     OnClearClip(properties_->ClearFragmentClip());
   }
  }

  if (properties_ && properties_->FragmentClip()) /* FIX [CWE-119]: Added bounds check for pointer operation */
    context_.current.clip = properties_->FragmentClip();
}