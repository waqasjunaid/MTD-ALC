/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15857  |  Dataset: bigvul
   Function:     _multi_string_alloc_and_expand
   Dominant CWE: CWE-476
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6614
   ============================================================ */

/* 
 * Changes made:
 * - Added NULL check for malloc return value to prevent CWE-476
 */

SQLWCHAR* _multi_string_alloc_and_expand( LPCSTR in )
{
    SQLWCHAR *chr = NULL; /* FIX [CWE-476]: Initialize chr to NULL */
    int len = 0;
 
     if ( !in )
     {
        return in;
     }
     
     while ( in[ len ] != 0 || in[ len + 1 ] != 0 )
    {
        len ++;
    }

    chr = malloc(sizeof( SQLWCHAR ) * ( len + 2 )); /* FIX [CWE-476]: Allocate memory */
    if (!chr) { /* FIX [CWE-476]: Check for NULL return value */
        return NULL; /* FIX [CWE-476]: Return NULL on allocation failure */
    }

    len = 0;
    while ( in[ len ] != 0 || in[ len + 1 ] != 0 )
    {
        chr[ len ] = in[ len ];
        len ++;
    }
    chr[ len ++ ] = 0;
    chr[ len ++ ] = 0;

    return chr;
}