/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       15996  |  Dataset: bigvul
   Function:     hash_recvmsg
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6915
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds check around pointer operation in memcpy_toiovec
 */

static int hash_recvmsg(struct kiocb *unused, struct socket *sock,
			struct msghdr *msg, size_t len, int flags)
{
	struct sock *sk = sock->sk;
	struct alg_sock *ask = alg_sk(sk);
	struct hash_ctx *ctx = ask->private;
	unsigned ds = crypto_ahash_digestsize(crypto_ahash_reqtfm(&ctx->req));
	int err;

	if (len > ds)
		len = ds;
 	else if (len < ds)
 		msg->msg_flags |= MSG_TRUNC;
 
	msg->msg_namelen = 0; /* FIX [CWE-119]: validated input */
 	lock_sock(sk);
 	if (ctx->more) {
 		ctx->more = 0;
		ahash_request_set_crypt(&ctx->req, NULL, ctx->result, 0);
		err = af_alg_wait_for_completion(crypto_ahash_final(&ctx->req),
						 &ctx->completion);
		if (err)
			goto unlock;
	}

	/* FIX [CWE-119]: explicit bounds check around pointer operation */
	if (msg->msg_iovlen > 0 && len <= msg->msg_iov[0].iov_len) {
		err = memcpy_toiovec(msg->msg_iov, ctx->result, len);
	} else {
		err = -EINVAL; /* invalid input */
	}

unlock:
	release_sock(sk);

	return err ?: len;
}