/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16015  |  Dataset: bigvul
   Function:     die
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6840
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds check for strlen(fmt) to prevent out-of-bounds access
 */

static void die(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    size_t len = strlen(fmt); /* FIX [CWE-119]: added bounds check */
    if (len > 0 && fmt[len - 1] != '\n') /* FIX [CWE-119]: checked for out-of-bounds access */
        printf("\n");
    exit(EXIT_FAILURE);
}