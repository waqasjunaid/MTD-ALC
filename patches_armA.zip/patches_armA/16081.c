/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16081  |  Dataset: bigvul
   Function:     br_multicast_del_pg
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6858
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds checks around pointer operations
 */

static void br_multicast_del_pg(struct net_bridge *br,
				struct net_bridge_port_group *pg)
{
	struct net_bridge_mdb_htable *mdb;
	struct net_bridge_mdb_entry *mp;
	struct net_bridge_port_group *p;
	struct net_bridge_port_group __rcu **pp;

	mdb = mlock_dereference(br->mdb, br);

	mp = br_mdb_ip_get(mdb, &pg->addr);
	if (WARN_ON(!mp))
		return;

	for (pp = &mp->ports;
	     (p = mlock_dereference(*pp, br)) != NULL;
	     pp = &p->next) {
		if (p != pg)
			continue;

		rcu_assign_pointer(*pp, p->next);
		hlist_del_init(&p->mglist);
 		del_timer(&p->timer); /* FIX [CWE-119]: Ensure timer is deleted before accessing */
 		call_rcu_bh(&p->rcu, br_multicast_free_pg);

		if (mp && !mp->ports && !mp->mglist &&
 		    netif_running(br->dev)) { /* FIX [CWE-690]: Validate mp pointer before use */
 			mod_timer(&mp->timer, jiffies);
 		}

		return;
	}

	WARN_ON(1);
}