/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16101  |  Dataset: bigvul
   Function:     TearDownTestCase
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added checks for NULL pointers before calling vpx_free to prevent potential crashes.
 */

static void TearDownTestCase() {
    if (source_data_ != NULL) { /* FIX [CWE-690]: Preventing NULL pointer dereference */
        vpx_free(source_data_);
        source_data_ = NULL;
    }
    if (reference_data_ != NULL) { /* FIX [CWE-690]: Preventing NULL pointer dereference */
        vpx_free(reference_data_);
        reference_data_ = NULL;
    }
}