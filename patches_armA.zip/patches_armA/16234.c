/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16234  |  Dataset: bigvul
   Function:     shm_destroy
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6885
   ============================================================ */

/* 
 * Changes made:
 * - Added a check for NULL pointer dereference in shp->shm_file
 */

static void shm_destroy(struct ipc_namespace *ns, struct shmid_kernel *shp)
 {
 	ns->shm_tot -= (shp->shm_segsz + PAGE_SIZE - 1) >> PAGE_SHIFT;
 	shm_rmid(ns, shp);
 	shm_unlock(shp);
	if (shp->shm_file && !is_file_hugepages(shp->shm_file)) /* FIX [CWE-690]: NULL pointer dereference */
		shmem_lock(shp->shm_file, 0, shp->mlock_user);
 	else if (shp->shm_file && shp->mlock_user) /* FIX [CWE-690]: NULL pointer dereference */
		user_shm_unlock(file_inode(shp->shm_file)->i_size,
						shp->mlock_user);
	if (shp->shm_file) /* FIX [CWE-690]: NULL pointer dereference */
		fput (shp->shm_file);
 	ipc_rcu_putref(shp, shm_rcu_free);
 }