/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16274  |  Dataset: bigvul
   Function:     nbd_negotiate_drop_sync
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6840
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds check for 'size' to prevent potential integer overflow
 */

static int nbd_negotiate_drop_sync(QIOChannel *ioc, size_t size)
{
    ssize_t ret;
    uint8_t *buffer = g_malloc(MIN(65536, size)); /* FIX [CWE-190]: added bounds check */
    if (size > SIZE_MAX - 65536) { /* FIX [CWE-190]: prevent integer overflow */
        g_free(buffer);
        return -EOVERFLOW;
    }
    while (size > 0) {
        size_t count = MIN(65536, size); /* FIX [CWE-190]: added bounds check */
        ret = nbd_negotiate_read(ioc, buffer, count);
        if (ret < 0) {
            g_free(buffer);
            return ret;
        }
        size -= count; /* FIX [CWE-190]: prevent integer underflow */
        if (size < 0) { /* FIX [CWE-190]: handle integer underflow */
            g_free(buffer);
            return -EOVERFLOW;
        }
    }
    g_free(buffer);
    return 0;
}