/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16298  |  Dataset: bigvul
   Function:     unknown_16298
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for file descriptor (fd)
 * - Added bounds check for offset and length
 */

int SoundPool::load(int fd, int64_t offset, int64_t length, int priority __unused)
{
    ALOGV("load: fd=%d, offset=%" PRId64 ", length=%" PRId64 ", priority=%d",
             fd, offset, length, priority);
    Mutex::Autolock lock(&mLock);

    // Check if file descriptor is valid
    if (fd < 0) {
        ALOGE("Invalid file descriptor: %d", fd); /* FIX [CWE-20]: Invalid file descriptor */
        return -1;
    }

    // Check for invalid offset and length values
    if (offset < 0 || length <= 0) {
        ALOGE("Invalid offset or length: offset=%" PRId64 ", length=%" PRId64, offset, length); /* FIX [CWE-119]: Invalid offset or length */
        return -1;
    }

    sp<Sample> sample = new Sample(++mNextSampleID, fd, offset, length);
    mSamples.add(sample->sampleID(), sample);
    doLoad(sample);
    return sample->sampleID();
}