/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16312  |  Dataset: bigvul
   Function:     secure_ipv6_id
   Dominant CWE: struct-array
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5997
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index access
 */

__u32 secure_ipv6_id(const __be32 daddr[4])
{
	const struct keydata *keyptr;
	__u32 hash[4];
	keyptr = get_keyptr();

	if (daddr != NULL && sizeof(daddr) / sizeof(daddr[0]) >= 4) { /* FIX [CWE-129]: validate array index bounds */
		hash[0] = (__force __u32)daddr[0]; /* FIX [CWE-129]: validated access */
		hash[1] = (__force __u32)daddr[1]; /* FIX [CWE-129]: validated access */
		hash[2] = (__force __u32)daddr[2]; /* FIX [CWE-129]: validated access */
		hash[3] = (__force __u32)daddr[3]; /* FIX [CWE-129]: validated access */
	}
	return half_md4_transform(hash, keyptr->secret);
}