/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16323  |  Dataset: bigvul
   Function:     unknown_16323
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6734
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for m_entries_size before allocating memory.
 * - Added null pointer checks for m_entries and entries.
 */

long Cluster::CreateBlock(
    long long id,
    long long pos,   //absolute pos of payload
    long long size,
    long long discard_padding)
{
    assert((id == 0x20) || (id == 0x23));  //BlockGroup or SimpleBlock
    if (m_entries_count < 0)  //haven't parsed anything yet
    {
        assert(m_entries == NULL);
        assert(m_entries_size == 0);
        m_entries_size = 1024;
        /* FIX [CWE-789]: Validate allocation size to prevent integer overflow */
        if (m_entries_size <= 0 || SIZE_MAX / sizeof(BlockEntry*) < m_entries_size) {
            // handle error: invalid allocation size
            return -1; // or some other error value
        }
        m_entries = new BlockEntry*[m_entries_size];
        /* FIX [CWE-690]: Check for null pointer after memory allocation */
        if (m_entries == NULL) {
            // handle error: out of memory
            return -1; // or some other error value
        }
        m_entries_count = 0;
    }
    else
    {
        assert(m_entries);
        assert(m_entries_size > 0);
        assert(m_entries_count <= m_entries_size);
        if (m_entries_count >= m_entries_size)
        {
            const long entries_size = 2 * m_entries_size;
            /* FIX [CWE-789]: Validate allocation size to prevent integer overflow */
            if (entries_size <= 0 || SIZE_MAX / sizeof(BlockEntry*) < entries_size) {
                // handle error: invalid allocation size
                return -1; // or some other error value
            }
            BlockEntry** const entries = new BlockEntry*[entries_size];
            /* FIX [CWE-690]: Check for null pointer after memory allocation */
            if (entries == NULL) {
                // handle error: out of memory
                return -1; // or some other error value
            }
            BlockEntry** src = m_entries;
            BlockEntry** const src_end = src + m_entries_count;
            BlockEntry** dst = entries;
            while (src != src_end)
                *dst++ = *src++;
            delete[] m_entries;
            m_entries = entries;
            m_entries_size = entries_size;
        }
     }
 
    if (id == 0x20)  //BlockGroup ID
        return CreateBlockGroup(pos, size, discard_padding);
    else  //SimpleBlock ID
        return CreateSimpleBlock(pos, size);
 }