/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16488  |  Dataset: bigvul
   Function:     unknown_16488
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6107
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds check for video->cxdata() and video->frame_size()
 * - Added return value check for decoder->DecodeFrame()
 */

void DecoderTest::RunLoop(CompressedVideoSource *video) {
  vpx_codec_dec_cfg_t dec_cfg = {0};
  Decoder* const decoder = codec_->CreateDecoder(dec_cfg, 0);
  ASSERT_TRUE(decoder != NULL);

  for (video->Begin(); video->cxdata() && video->frame_size() > 0; video->Next()) {
    PreDecodeFrameHook(*video, decoder);
    vpx_codec_err_t res_dec = decoder->DecodeFrame(video->cxdata(), 
                                                   /* FIX [CWE-119]: bounds check */ video->frame_size());
    if (res_dec != VPX_CODEC_OK) { /* FIX [CWE-252]: return value check */
      FAIL() << "Decode failed: " << decoder->DecodeError();
    }
    ASSERT_EQ(VPX_CODEC_OK, res_dec) << decoder->DecodeError();

    DxDataIterator dec_iter = decoder->GetDxData();
    const vpx_image_t *img = NULL;

    while ((img = dec_iter.Next()))
      DecompressedFrameHook(*img, video->frame_number());
  }
  delete decoder;
}