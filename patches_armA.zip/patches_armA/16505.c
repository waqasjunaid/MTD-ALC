/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16505  |  Dataset: bigvul
   Function:     makeCurrent
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added null checks for m_detachedContext and m_glContext to prevent potential crashes.
 */

void makeCurrent()
{
#if PLATFORM(QT)
    m_detachedContext = QOpenGLContext::currentContext();
    if (m_detachedContext) {
        /* FIX [CWE-690]: Validate pointer before dereference */
        if (m_detachedContext->isValid()) {
            m_detachedSurface = m_detachedContext->surface();
        }
    }
    if (m_surface && m_glContext) {
        /* FIX [CWE-690]: Validate pointer before call */
        if (m_glContext->isValid()) {
            m_glContext->makeCurrent(m_surface.get());
        }
    }
#elif PLATFORM(EFL)
    m_detachedContext = glXGetCurrentContext();
    m_detachedSurface = glXGetCurrentDrawable();
    if (m_surface && m_glContext) {
        /* FIX [CWE-690]: Validate pointer before call */
        if (m_display != nullptr) {
            glXMakeCurrent(m_display, m_surface, m_glContext);
        }
    }
#endif
}