/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1654  |  Dataset: bigvul
   Function:     socket_create
   Dominant CWE: struct-cast
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5923
   ============================================================ */

/* 
 * CHANGES:
 *   - Fixed struct cast vulnerability by using a union to hold the sockaddr structure.
 */

int socket_create(uint16_t port)
{
	int sfd = -1;
	int yes = 1;
#ifdef WIN32
	WSADATA wsa_data;
	if (!wsa_init) {
		if (WSAStartup(MAKEWORD(2,2), &wsa_data) != ERROR_SUCCESS) {
			fprintf(stderr, "WSAStartup failed!\n");
			ExitProcess(-1);
		}
		wsa_init = 1;
	}
#endif
	union {
		struct sockaddr sa;
		struct sockaddr_in saddr;
	} addr;

	if (0 > (sfd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP))) {
		perror("socket()");
		return -1;
	}

	if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, (void*)&yes, sizeof(int)) == -1) {
		perror("setsockopt()");
		socket_close(sfd);
		return -1;
	}
 
 	memset((void *) &addr, 0, sizeof(addr));
 	addr.saddr.sin_family = AF_INET; /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */
	saddr.sin_addr.s_addr = htonl(INADDR_ANY); /* FIX [CWE-704]: Use a union for type-safe polymorphism */
  addr.saddr.sin_port = htons(port); /* FIX [CWE-704]: Use a union for type-safe polymorphism */
 
 	if (0 > bind(sfd, &addr.sa, sizeof(addr))) { /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */
		perror("bind()");
		socket_close(sfd);
		return -1;
	}

	if (listen(sfd, 1) == -1) {
		perror("listen()");
		socket_close(sfd);
		return -1;
	}

	return sfd;
}