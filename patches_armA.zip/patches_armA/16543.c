/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16543  |  Dataset: bigvul
   Function:     kvm_unpin_pages
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for npages to prevent potential out-of-bounds access
 */

static void kvm_unpin_pages(struct kvm *kvm, pfn_t pfn, unsigned long npages)
{
	unsigned long i;
	if (npages > 0) { /* FIX [CWE-119]: added bounds check */
		for (i = 0; i < npages; ++i)
			kvm_release_pfn_clean(pfn + i);
	}
}