/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16604  |  Dataset: bigvul
   Function:     ff_mpv_idct_init
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0172
   ALC decision: UNTRUSTWORTHY  T=0.6941
   ============================================================ */

/*
 * CHANGES:
 * - Added explicit bounds checks around pointer operations.
 */

av_cold void ff_mpv_idct_init(MpegEncContext *s)
 {
     if (s && s->idsp && s->avctx) { /* FIX [CWE-124]: null pointer dereference */
         ff_idctdsp_init(&s->idsp, s->avctx);
 
         /* load & permutate scantables
         * note: only wmv uses different ones
         */
        if (s->alternate_scan) {
            if (s->inter_scantable && s->intra_scantable) { /* FIX [CWE-124]: null pointer dereference */
                ff_init_scantable(s->idsp.idct_permutation, &s->inter_scantable, ff_alternate_vertical_scan);
                ff_init_scantable(s->idsp.idct_permutation, &s->intra_scantable, ff_alternate_vertical_scan);
            }
        } else {
            if (s->inter_scantable && s->intra_scantable) { /* FIX [CWE-124]: null pointer dereference */
                ff_init_scantable(s->idsp.idct_permutation, &s->inter_scantable, ff_zigzag_direct);
                ff_init_scantable(s->idsp.idct_permutation, &s->intra_scantable, ff_zigzag_direct);
            }
        }
        if (s->intra_h_scantable && s->intra_v_scantable) { /* FIX [CWE-124]: null pointer dereference */
            ff_init_scantable(s->idsp.idct_permutation, &s->intra_h_scantable, ff_alternate_horizontal_scan);
            ff_init_scantable(s->idsp.idct_permutation, &s->intra_v_scantable, ff_alternate_vertical_scan);
        }
     }
}