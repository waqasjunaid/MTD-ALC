/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16653  |  Dataset: bigvul
   Function:     unknown_16653
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5985
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds check for pointer 'this' and '*that'
 */

image_transform_png_set_scale_16_add(image_transform *this,
    PNG_CONST image_transform **that, png_byte colour_type, png_byte bit_depth)
{
    UNUSED(colour_type)

    if (this != NULL && that != NULL) { /* FIX [CWE-690]: pointer bounds check */
        this->next = *that;
        *that = this; /* FIX [CWE-690]: ensure '*that' is not NULL before assignment */
    }

    return bit_depth > 8;
}