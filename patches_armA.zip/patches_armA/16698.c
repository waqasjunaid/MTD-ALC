/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16698  |  Dataset: bigvul
   Function:     unknown_16698
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6000
   ============================================================ */

/* 
 * Changes made:
 *   Added bounds check on 'that' pointer to prevent potential NULL pointer dereference.
 */

image_transform_png_set_expand_add(image_transform *this,
    PNG_CONST image_transform **that, png_byte colour_type, png_byte bit_depth)
 {
    UNUSED(bit_depth)

    if (that != NULL && *that != NULL) { /* FIX [CWE-690]: Prevent NULL pointer dereference */
        this->next = *that;
        *that = this;
    }

    /* 'expand' should do nothing for RGBA or GA input - no tRNS and the bit
       * depth is at least 8 already.
       */
    return (colour_type & PNG_COLOR_MASK_ALPHA) == 0;
}