/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16771  |  Dataset: bigvul
   Function:     jmp_rel
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for rel to prevent potential integer overflow
 */

static inline void jmp_rel(struct x86_emulate_ctxt *ctxt, int rel)
{
    /* FIX [CWE-190]: Validate input to prevent integer overflow */
    if (rel > INT_MAX - ctxt->_eip || rel < INT_MIN - ctxt->_eip) {
        /* Handle error: invalid relative jump offset */
        return;
    }
    assign_eip_near(ctxt, ctxt->_eip + rel);
}