/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       16988  |  Dataset: bigvul
   Function:     unknown_16988
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/* 
 * Changes made:
 * - Added null check for window before deleting or using it.
 */

~OffScreenRootWindow()
{
    if (!--refCount) {
#if PLATFORM(QT)
        if (window != 0) { /* FIX [CWE-690]: Avoid use of deleted pointer */
            delete window;
            window = 0;
        }
#elif PLATFORM(EFL)
        if (window != 0 && display != 0) { /* FIX [CWE-690]: Avoid use of deleted pointer and null display */
            XUnmapWindow(display, window);
            XDestroyWindow(display, window);
        }
#endif
    }
}