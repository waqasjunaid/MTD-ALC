/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17017  |  Dataset: bigvul
   Function:     unknown_17017
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6710
   ============================================================ */

/* CHANGES MADE:
 * - Added origin validation to prevent potential security issues.
 */

void ExtensionOptionsGuest::DidNavigateMainFrame(
    const content::LoadCommittedDetails& details,
    const content::FrameNavigateParams& params) {
  if (attached()) {
    auto guest_zoom_controller =
        ui_zoom::ZoomController::FromWebContents(web_contents());
    guest_zoom_controller->SetZoomMode(
         ui_zoom::ZoomController::ZOOM_MODE_ISOLATED);
     SetGuestZoomLevelToMatchEmbedder();
 
    GURL origin = params.url.GetOrigin(); /* FIX [CWE-20]: Validate input */
    if (!origin.is_valid()) { /* FIX [CWE-20]: Check return value */
      bad_message::ReceivedBadMessage(web_contents()->GetRenderProcessHost(),
                                       bad_message::EOG_BAD_ORIGIN);
    } else if (origin != options_page_.GetOrigin()) {
       bad_message::ReceivedBadMessage(web_contents()->GetRenderProcessHost(),
                                       bad_message::EOG_BAD_ORIGIN);
     }
  }
}