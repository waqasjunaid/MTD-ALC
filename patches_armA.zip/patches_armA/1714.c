/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1714  |  Dataset: bigvul
   Function:     unknown_1714
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * Changes made:
 * - Added a null check for GetMediaInterfaceFactory() to prevent potential null pointer dereference.
 */

void MediaInterfaceProxy::CreateCdm(
     media::mojom::ContentDecryptionModuleRequest request) {
   DCHECK(thread_checker_.CalledOnValidThread());
  if (GetMediaInterfaceFactory()) { /* FIX [CWE-476]: Prevent null pointer dereference */
    GetMediaInterfaceFactory()->CreateCdm(std::move(request));
  }
 }