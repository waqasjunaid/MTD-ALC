/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17290  |  Dataset: bigvul
   Function:     unknown_17290
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for cJSON_New_Item() return value
 * - Added null check for cJSON_strdup() return value
 */

cJSON *cJSON_CreateString( const char *string )
{
	cJSON *item = cJSON_New_Item();
	if ( item ) { /* FIX [CWE-690]: added explicit bounds check */
		item->type = cJSON_String;
		item->valuestring = cJSON_strdup( string );
		if (!item->valuestring) { /* FIX [CWE-690]: added null check for strdup return value */
			cJSON_Delete(item);
			return NULL;
		}
	}
	return item;
}