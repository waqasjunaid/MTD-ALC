/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17365  |  Dataset: bigvul
   Function:     InputMethodIsActivated
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6912
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds check for active_input_method_descriptors to prevent potential null pointer dereference.
 */

virtual bool InputMethodIsActivated(const std::string& input_method_id) {
    scoped_ptr<InputMethodDescriptors> active_input_method_descriptors(
        GetActiveInputMethods());
    if (!active_input_method_descriptors) { /* FIX [CWE-476]: Prevent null pointer dereference */
      return false;
    }
    for (size_t i = 0; i < active_input_method_descriptors->size(); ++i) {
      if (active_input_method_descriptors->at(i).id == input_method_id) {
        return true;
      }
    }
    return false;
  }