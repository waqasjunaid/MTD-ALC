/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17400  |  Dataset: bigvul
   Function:     unknown_17400
   Dominant CWE: struct-array
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5597
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index 'timer_id' in timers_ array
 */

uint32 PluginInstance::ScheduleTimer(uint32 interval,
                                     NPBool repeat,
                                     void (*func)(NPP id, uint32 timer_id)) {
  uint32 timer_id;
  timer_id = next_timer_id_;
  ++next_timer_id_;
  DCHECK(next_timer_id_ != 0);

  TimerInfo info;
  info.interval = interval;
  info.repeat = repeat;

  // FIX [CWE-129]: Validate array index is within bounds before access
  if (timer_id >= 0 && (size_t)timer_id < timers_.size()) {
    timers_[timer_id] = info; /* FIX [CWE-129]: Accessing array with validated index */
  }

  message_loop_->PostDelayedTask(FROM_HERE,
                                 NewRunnableMethod(this,
                                                   &PluginInstance::OnTimerCall,
                                                   func,
                                                   npp_,
                                                   timer_id),
                                 interval);
   return timer_id;
 }