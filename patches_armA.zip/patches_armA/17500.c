/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17500  |  Dataset: bigvul
   Function:     unknown_17500
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6046
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds checks for ConvertUnitDouble function calls to prevent integer overflows.
 */

void PrintWebViewHelper::UpdatePrintableSizeInPrintParameters(
    WebFrame* frame,
    WebNode* node,
    ViewMsg_Print_Params* params) {
  double content_width_in_points;
  double content_height_in_points;
  double margin_top_in_points;
  double margin_right_in_points;
  double margin_bottom_in_points;
  double margin_left_in_points;
  PrepareFrameAndViewForPrint prepare(*params, frame, node, frame->view());
  PrintWebViewHelper::GetPageSizeAndMarginsInPoints(frame, 0, *params,
      &content_width_in_points, &content_height_in_points,
      &margin_top_in_points, &margin_right_in_points,
      &margin_bottom_in_points, &margin_left_in_points);
#if defined(OS_MACOSX)
  int dpi = printing::kPointsPerInch;
#else
  int dpi = static_cast<int>(params->dpi);
#endif  // defined(OS_MACOSX)

  // FIX [CWE-190]: Prevent integer overflow by checking the result of ConvertUnitDouble.
  int width_in_pixels = static_cast<int>(ConvertUnitDouble(content_width_in_points,
      printing::kPointsPerInch, dpi));
  if (width_in_pixels < 0) {
    width_in_pixels = 0; /* FIX [CWE-190]: Clamp negative values to prevent underflow. */
  }

  // FIX [CWE-190]: Prevent integer overflow by checking the result of ConvertUnitDouble.
  int height_in_pixels = static_cast<int>(ConvertUnitDouble(content_height_in_points,
      printing::kPointsPerInch, dpi));
  if (height_in_pixels < 0) {
    height_in_pixels = 0; /* FIX [CWE-190]: Clamp negative values to prevent underflow. */
  }

  params->printable_size = gfx::Size(width_in_pixels, height_in_pixels);

  // FIX [CWE-190]: Prevent integer overflow by checking the result of ConvertUnitDouble.
  int page_width_in_pixels = static_cast<int>(ConvertUnitDouble(content_width_in_points +
      margin_left_in_points + margin_right_in_points,
      printing::kPointsPerInch, dpi));
  if (page_width_in_pixels < 0) {
    page_width_in_pixels = 0; /* FIX [CWE-190]: Clamp negative values to prevent underflow. */
  }

  // FIX [CWE-190]: Prevent integer overflow by checking the result of ConvertUnitDouble.
  int page_height_in_pixels = static_cast<int>(ConvertUnitDouble(content_height_in_points +
      margin_top_in_points + margin_bottom_in_points,
      printing::kPointsPerInch, dpi));
  if (page_height_in_pixels < 0) {
    page_height_in_pixels = 0; /* FIX [CWE-190]: Clamp negative values to prevent underflow. */
  }

  params->page_size = gfx::Size(page_width_in_pixels, page_height_in_pixels);

  // FIX [CWE-190]: Prevent integer overflow by checking the result of ConvertUnitDouble.
  int margin_top_in_pixels = static_cast<int>(ConvertUnitDouble(
      margin_top_in_points, printing::kPointsPerInch, dpi));
  if (margin_top_in_pixels < 0) {
    margin_top_in_pixels = 0; /* FIX [CWE-190]: Clamp negative values to prevent underflow. */
  }

  params->margin_top = margin_top_in_pixels;

  // FIX [CWE-190]: Prevent integer overflow by checking the result of ConvertUnitDouble.
  int margin_left_in_pixels = static_cast<int>(ConvertUnitDouble(
      margin_left_in_points, printing::kPointsPerInch, dpi));
  if (margin_left_in_pixels < 0) {
    margin_left_in_pixels = 0; /* FIX [CWE-190]: Clamp negative values to prevent underflow. */
  }

  params->margin_left = margin_left_in_pixels;
}