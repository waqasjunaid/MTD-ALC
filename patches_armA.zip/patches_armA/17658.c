/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17658  |  Dataset: bigvul
   Function:     msg_cache_check
   Dominant CWE: struct-array
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6539
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds checking for array index 'i' in the loop.
 */

static int msg_cache_check(const char *id, struct BodyCache *bcache, void *data)
{
  struct Context *ctx = (struct Context *) data;
  if (!ctx)
    return -1;
  struct PopData *pop_data = (struct PopData *) ctx->data;
  if (!pop_data)
    return -1;

#ifdef USE_HCACHE
  /* keep hcache file if hcache == bcache */
  if (strcmp(HC_FNAME "." HC_FEXT, id) == 0)
    return 0;
#endif

  for (int i = 0; i < ctx->msgcount && i >= 0 && (size_t)i < ARRAY_LEN(ctx->hdrs); i++) /* FIX [CWE-129]: bounds check */
  {
    /* if the id we get is known for a header: done (i.e. keep in cache) */
    if (ctx->hdrs[i] && ctx->hdrs[i]->data && (mutt_str_strcmp(ctx->hdrs[i]->data, id) == 0)) /* FIX [CWE-129]: null check */
      return 0;
  }

   /* message not found in context -> remove it from cache
    * return the result of bcache, so we stop upon its first error
    */
  return mutt_bcache_del(bcache, id);
 }