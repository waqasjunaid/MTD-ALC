/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17668  |  Dataset: bigvul
   Function:     unknown_17668
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * Changes made:
 * - Added a null check for web_contents before calling get() on it.
 */

FrameImpl::FrameImpl(std::unique_ptr<content::WebContents> web_contents,
                     chromium::web::FrameObserverPtr observer)
    : web_contents_(std::move(web_contents)), observer_(std::move(observer)) {
  if (web_contents_) { /* FIX [CWE-476]: Prevent null pointer dereference */
    Observe(web_contents.get());
  }
}