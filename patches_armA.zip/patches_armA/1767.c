/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1767  |  Dataset: bigvul
   Function:     unknown_1767
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5965
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for icon_ pointer to prevent potential null pointer dereference.
 */

void TranslateInfoBarBase::Layout() {
  InfoBar::Layout();
 
  if (icon_) { /* FIX [CWE-476]: Prevent null pointer dereference */
    gfx::Size icon_ps = icon_->GetPreferredSize();
    icon_->SetBounds(InfoBar::kHorizontalPadding, InfoBar::OffsetY(this, icon_ps),
        icon_ps.width(), icon_ps.height());
  }
}