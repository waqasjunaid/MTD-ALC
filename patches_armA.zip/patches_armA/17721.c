/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17721  |  Dataset: bigvul
   Function:     tailmatch
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6902
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for little and bigone pointers
 * - Added null check for little and bigone strings
 */

static bool tailmatch(const char *little, const char *bigone)
{
  /* FIX [CWE-170]: Validate input pointers */
  if(!little || !bigone)
    return FALSE;

  size_t littlelen = strlen(little);
  size_t biglen = strlen(bigone);

  /* FIX [CWE-119]: Check for potential buffer overflow */
  if(littlelen > biglen || biglen - littlelen < 0)
    return FALSE;

  return Curl_raw_equal(little, bigone+biglen-littlelen) ? TRUE : FALSE;
}