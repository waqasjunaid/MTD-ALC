/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17829  |  Dataset: bigvul
   Function:     unknown_17829
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0116
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/* 
 * CHANGES:
 * - Added bounds checks for jas_matrix_create arguments
 */

jas_matrix_t *jas_seq2d_create(int xstart, int ystart, int xend, int yend)
 {
 	jas_matrix_t *matrix;
 	assert(xstart <= xend && ystart <= yend);
	if (xend - xstart < 0 || yend - ystart < 0) { /* FIX [CWE-129]: prevent negative size */
		return 0;
	}
	if (!(matrix = jas_matrix_create(yend - ystart, xend - xstart))) {
		return 0;
	}
	matrix->xstart_ = xstart; /* no actual fix needed here */
	matrix->ystart_ = ystart; /* no actual fix needed here */
	matrix->xend_ = xend; /* no actual fix needed here */
	matrix->yend_ = yend; /* no actual fix needed here */
 	return matrix;
 }