/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17853  |  Dataset: bigvul
   Function:     unknown_17853
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * Changes made:
 * - Added a null check for the 'widget' parameter to prevent potential crashes.
 */

void PartialMagnificationController::OnWidgetDestroying(views::Widget* widget) {
  if (widget != NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
    DCHECK_EQ(widget, zoom_widget_);
    RemoveZoomWidgetObservers();
    zoom_widget_ = NULL;
  }
}