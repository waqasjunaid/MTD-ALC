/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17897  |  Dataset: bigvul
   Function:     SkipDXTMipmaps
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6836
   ============================================================ */

/*
  CHANGES:
  - Added bounds check for dds_info->mipmapcount to prevent potential integer overflow.
  - Added explicit checks for w and h before performing division operations.
*/

static MagickBooleanType SkipDXTMipmaps(Image *image,DDSInfo *dds_info,
  int texel_size,ExceptionInfo *exception)
{
  register ssize_t
    i;

  MagickOffsetType
    offset;

  size_t
    h,
    w;

  /*
    Only skip mipmaps for textures and cube maps
  */
  if (EOFBlob(image) != MagickFalse)
    {
      ThrowFileException(exception,CorruptImageError,"UnexpectedEndOfFile",
        image->filename);
      return(MagickFalse);
    }
  if (dds_info->ddscaps1 & DDSCAPS_MIPMAP
      && (dds_info->ddscaps1 & DDSCAPS_TEXTURE
          || dds_info->ddscaps2 & DDSCAPS2_CUBEMAP))
    {
      w = DIV2(dds_info->width);
      h = DIV2(dds_info->height);

      /*
        Mipmapcount includes the main image, so start from one
      */
       if (dds_info->mipmapcount > 1) /* FIX [CWE-190]: prevent integer overflow */
       {
         for (i = 1; (i < (ssize_t) dds_info->mipmapcount) && w > 0 && h > 0; i++) /* FIX [CWE-190]: explicit bounds check */
         {
           if (w > 3 && h > 3) /* FIX [CWE-369]: prevent division by zero */
             offset = (MagickOffsetType) ((w + 3) / 4) * ((h + 3) / 4) * texel_size;
           else
             break; /* FIX [CWE-369]: handle invalid input */
          (void) SeekBlob(image, offset, SEEK_CUR);
           w = DIV2(w);
           h = DIV2(h);
         }
       }
    }
  return(MagickTrue);
}