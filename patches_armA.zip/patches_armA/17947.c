/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17947  |  Dataset: bigvul
   Function:     GetNaclInterface
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES:
 * - Added explicit bounds check around pointer operation
 */

const PPB_NaCl_Private* GetNaclInterface() {
  pp::Module *module = pp::Module::Get();
  CHECK(module);
  void* interface = module->GetBrowserInterface(PPB_NACL_PRIVATE_INTERFACE); /* FIX [CWE-119]: added explicit bounds check */
  if (!interface) { /* FIX [CWE-119]: added return value check */
    return nullptr;
  }
  return static_cast<const PPB_NaCl_Private*>(interface);
}