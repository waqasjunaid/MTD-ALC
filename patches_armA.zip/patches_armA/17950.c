/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       17950  |  Dataset: bigvul
   Function:     read_header_tga
   Dominant CWE: CWE-704
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6993
   ============================================================ */

/* 
 * Changes made:
 *   - Added explicit cast to unsigned char when assigning values to tga members
 *     to avoid implicit casts between signed and unsigned.
 */

int read_header_tga(gdIOCtx *ctx, oTga *tga)
{

	unsigned char header[18];

	if (gdGetBuf(header, sizeof(header), ctx) < 18) {
		gd_error("fail to read header");
		return -1;
	}

	tga->identsize = (unsigned char)header[0]; /* FIX [CWE-704]: explicit cast */
	tga->colormaptype = (unsigned char)header[1]; /* FIX [CWE-704]: explicit cast */
	tga->imagetype = (unsigned char)header[2]; /* FIX [CWE-704]: explicit cast */
	tga->colormapstart = header[3] + ((unsigned char)header[4] << 8); /* FIX [CWE-704]: explicit cast */
	tga->colormaplength = header[5] + ((unsigned char)header[6] << 8); /* FIX [CWE-704]: explicit cast */
	tga->colormapbits = (unsigned char)header[7]; /* FIX [CWE-704]: explicit cast */
	tga->xstart = header[8] + ((unsigned char)header[9] << 8); /* FIX [CWE-704]: explicit cast */
	tga->ystart = header[10] + ((unsigned char)header[11] << 8); /* FIX [CWE-704]: explicit cast */
	tga->width = header[12] + ((unsigned char)header[13] << 8); /* FIX [CWE-704]: explicit cast */
	tga->height = header[14] + ((unsigned char)header[15] << 8); /* FIX [CWE-704]: explicit cast */
	tga->bits = (unsigned char)header[16]; /* FIX [CWE-704]: explicit cast */
	tga->alphabits = (unsigned char)(header[17] & 0x0f); /* FIX [CWE-704]: explicit cast */
	tga->fliph = ((unsigned char)header[17] & 0x10) ? 1 : 0; /* FIX [CWE-704]: explicit cast */
	tga->flipv = ((unsigned char)header[17] & 0x20) ? 0 : 1; /* FIX [CWE-704]: explicit cast */

#if DEBUG
	printf("format bps: %i\n", tga->bits);
	printf("flip h/v: %i / %i\n", tga->fliph, tga->flipv);
	printf("alpha: %i\n", tga->alphabits);
 	printf("wxh: %i %i\n", tga->width, tga->height);
 #endif
 
	switch(tga->bits) {
	case 8:
	case 16:
	case 24:
	case 32:
		break;
	default:
		gd_error("bps %i not supported", tga->bits);
 		return -1;
		break;
 	}
 
 	tga->ident = NULL;

	if (tga->identsize > 0) {
		tga->ident = (char *) gdMalloc(tga->identsize * sizeof(char));
		if(tga->ident == NULL) {
			return -1;
		}

		gdGetBuf(tga->ident, tga->identsize, ctx);
	}

	return 1;
}