/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       18022  |  Dataset: bigvul
   Function:     SplitString
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * CHANGES MADE:
 * - Added input validation for 'str' and 'r'
 */

void SplitString(const std::wstring& str,
                 wchar_t c,
                 std::vector<std::wstring>* r) {
  if (str.empty() || !r) { /* FIX [CWE-20]: Validate inputs */
    return; // or throw an exception, depending on the desired behavior
  }
  SplitStringT(str, c, true, r);
}