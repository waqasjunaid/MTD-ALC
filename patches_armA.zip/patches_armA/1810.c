/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1810  |  Dataset: bigvul
   Function:     unknown_1810
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/* 
 * Changes made:
 * - Added a null check for the 'url' parameter to prevent potential crashes or undefined behavior.
 */

void WebPluginImpl::didFinishLoadingFrameRequest(
     const WebURL& url, void* notify_data) {
   if (delegate_ && !url.isEmpty()) { /* FIX [CWE-20]: Validate input URL */
     delegate_->DidFinishLoadWithReason(
        url, NPRES_DONE, reinterpret_cast<intptr_t>(notify_data));
   }
 }