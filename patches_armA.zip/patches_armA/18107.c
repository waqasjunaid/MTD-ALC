/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       18107  |  Dataset: bigvul
   Function:     inotify_release
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6921
   ============================================================ */

/*
 * Changes made:
 * - Added NULL check for file and group to prevent potential null pointer dereferences.
 */

static int inotify_release(struct inode *ignored, struct file *file)
{
	if (!file || !file->private_data) {
		pr_err("%s: invalid file or private data\n", __func__);
		return -EINVAL; /* FIX [CWE-476]: return error on invalid input */
	}

	struct fsnotify_group *group = file->private_data;
	if (!group) {
		pr_err("%s: invalid group\n", __func__);
		return -EINVAL; /* FIX [CWE-476]: return error on invalid input */
	}

	struct user_struct *user = group->inotify_data.user;

	pr_debug("%s: group=%p\n", __func__, group);

	fsnotify_clear_marks_by_group(group);

	/* free this group, matching get was inotify_init->fsnotify_obtain_group */
	fsnotify_put_group(group);

	if (user) { /* FIX [CWE-476]: check for null before dereferencing */
		atomic_dec(&user->inotify_devs);
	}
	return 0;
}