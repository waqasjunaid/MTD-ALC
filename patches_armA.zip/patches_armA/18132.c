/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       18132  |  Dataset: bigvul
   Function:     unknown_18132
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * Changes made:
 * - Added explicit bounds check for multiplication overflow
 */

checked_xcalloc (size_t num, size_t size)
 {
    /* FIX [CWE-190]: Check for multiplication overflow */
    if (SIZE_MAX / num < size) {
        alloc_limit_assert ("checked_xcalloc", 0);
    } else {
        alloc_limit_assert ("checked_xcalloc", (num * size));
    }
     return xcalloc (num, size);
 }