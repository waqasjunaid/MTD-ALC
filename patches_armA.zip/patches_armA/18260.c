/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       18260  |  Dataset: bigvul
   Function:     unknown_18260
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6012
   ============================================================ */

/* CHANGES MADE:
 * - Added explicit bounds check for size parameter to prevent potential integer overflow.
 */

Blob::Blob(PassOwnPtr<BlobData> blobData, long long size)
    : m_type(blobData->contentType())
    , m_size(size) /* FIX [CWE-190]: Validate input size to prevent integer overflow */
{
    ASSERT(blobData);
    ScriptWrappable::init(this);

     if (size < 0) { /* FIX [CWE-190]: Check for negative size value */
        // Handle error or throw exception
    }

    m_internalURL = BlobURL::createInternalURL();
    ThreadableBlobRegistry::registerBlobURL(m_internalURL, blobData);
}