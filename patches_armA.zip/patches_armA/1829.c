/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1829  |  Dataset: bigvul
   Function:     unknown_1829
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6701
   ============================================================ */

Here is the patched function:

void V8LazyEventListener::prepareListenerObject(ExecutionContext* executionContext)
{
    if (!executionContext)
        return;

    v8::HandleScope handleScope(toIsolate(executionContext));
    v8::Local<v8::Context> v8Context = toV8Context(executionContext, world());
    if (v8Context.IsEmpty())
        return;
    ScriptState* scriptState = ScriptState::from(v8Context);
     if (!scriptState->contextIsValid())
         return;
 
    if (executionContext->isDocument() && !toDocument(executionContext)->allowInlineEventHandlers(m_node, this, m_sourceURL, m_position.m_line)) {
         clearListenerObject();
         return;
     }
 
     if (hasExistingListenerObject())
         return;
 
    ASSERT(executionContext->isDocument());
     ScriptState::Scope scope(scriptState);
     String listenerSource =  InspectorInstrumentation::preprocessEventListener(toDocument(executionContext)->frame(), m_code, m_sourceURL, m_functionName);
 
    String code = "(function() {"
        "with (this[2]) {" /* FIX [CWE-119]: Validate array index */
        "if (this.length > 2) {" // Added bounds check
            "with (this[1]) {" /* FIX [CWE-119]: Validate array index */
            "if (this.length > 1) {" // Added bounds check
                "with (this[0]) {" /* FIX [CWE-119]: Validate array index */
                "if (this.length > 0) {" // Added bounds check
                    "return function(" + m_eventParameterName + ") {" +
                        listenerSource + "\n" // Insert '\n' otherwise //-style comments could break the handler.
                    "};"
                "}" // End of added bounds check
            "}" // End of with block
        "}" // End of added bounds check
    "}" // End of with block
    "}" // End of with block
    "})";

    v8::Handle<v8::String> codeExternalString = v8String(isolate(), code);

    v8::Local<v8::Value> result = V8ScriptRunner::compileAndRunInternalScript(codeExternalString, isolate(), m_sourceURL, m_position);
    if (result.IsEmpty())
         return;
 
    ASSERT(result->IsFunction());
     v8::Local<v8::Function> intermediateFunction = result.As<v8::Function>();
 
     HTMLFormElement* formElement = 0;
    if (m_node && m_node->isHTMLElement())
        formElement = toHTMLElement(m_node)->formOwner();

    v8::Handle<v8::Object> nodeWrapper = toObjectWrapper<Node>(m_node, scriptState);
    v8::Handle<v8::Object> formWrapper = toObjectWrapper<HTMLFormElement>(formElement, scriptState);
    v8::Handle<v8::Object> documentWrapper = toObjectWrapper<Document>(m_node ? m_node->ownerDocument() : 0, scriptState);

    v8::Local<v8::Object> thisObject = v8::Object::New(isolate());
    if (thisObject.IsEmpty())
        return;
    if (!thisObject->ForceSet(v8::Integer::New(isolate(), 0), nodeWrapper))
        return;
    if (!thisObject->ForceSet(v8::Integer::New(isolate(), 1), formWrapper))
        return;
    if (!thisObject->ForceSet(v8::Integer::New(isolate(), 2), documentWrapper))
        return;

    v8::Local<v8::Value> innerValue = V8ScriptRunner::callInternalFunction(intermediateFunction, thisObject, 0, 0, isolate());
    if (innerValue.IsEmpty() || !innerValue->IsFunction())
        return;

    v8::Local<v8::Function> wrappedFunction = innerValue.As<v8::Function>();

    v8::Local<v8::Function> toStringFunction = v8::Function::New(isolate(), V8LazyEventListenerToString);
    ASSERT(!toStringFunction.IsEmpty());
    String toStringString = "function " + m_functionName + "(" + m_eventParameterName + ") {\n  " + m_code + "\n}";
    V8HiddenValue::setHiddenValue(isolate(), wrappedFunction, V8HiddenValue::toStringString(isolate()), v8String(isolate(), toStringString));
    wrappedFunction->Set(v8AtomicString(isolate(), "toString"), toStringFunction);
    wrappedFunction->SetName(v8String(isolate(), m_functionName));


    setListenerObject(wrappedFunction);
}

// Changes:
// - Added bounds checks for array indices in the generated code.