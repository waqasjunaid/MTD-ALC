/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1830  |  Dataset: bigvul
   Function:     driver_override_show
   Dominant CWE: CWE-120
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6346
   ============================================================ */

/*
 * Changes made:
 * - Replaced sprintf with snprintf to prevent buffer overflow (CWE-120)
 */

static ssize_t driver_override_show(struct device *dev,
 				    struct device_attribute *attr, char *buf)
 {
 	struct platform_device *pdev = to_platform_device(dev);
 
	return snprintf(buf, PAGE_SIZE, "%s\n", pdev->driver_override); /* FIX [CWE-120]: prevent buffer overflow */
 }