/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1855  |  Dataset: bigvul
   Function:     TIFFSeekCustomStream
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0220
   ALC decision: UNTRUSTWORTHY  T=0.6984
   ============================================================ */

/*
 * CHANGES:
 * - Added explicit bounds checks for offset and profile->length
 */

static MagickOffsetType TIFFSeekCustomStream(const MagickOffsetType offset,
  const int whence,void *user_data)
{
  PhotoshopProfile
    *profile;

  profile=(PhotoshopProfile *) user_data;
  switch (whence)
  {
    case SEEK_SET:
    default:
    {
      if (offset < 0) /* FIX [CWE-190]: validate input offset */
        return(-1);
      profile->offset=offset;
      break;
     }
     case SEEK_CUR:
     {
       if ((profile->offset+offset) < 0 || /* FIX [CWE-190]: check for overflow */
           (profile->offset+offset) > MagickOffsetMaximum)
         return(-1);
       profile->offset+=offset;
      break;
    }
    case SEEK_END:
    {
      if (((MagickOffsetType) profile->length+offset) < 0 || /* FIX [CWE-190]: check for overflow */
          ((MagickOffsetType) profile->length+offset) > MagickOffsetMaximum)
        return(-1);
      profile->offset=profile->length+offset;
      break;
    }
  }

  if (profile->offset < 0 || profile->offset > MagickOffsetMaximum) /* FIX [CWE-190]: validate output offset */
    return(-1);

  return(profile->offset);
}