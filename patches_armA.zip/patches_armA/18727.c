/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       18727  |  Dataset: bigvul
   Function:     unknown_18727
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for pointer operations
 */

void WebPluginDelegateImpl::SendJavaScriptStream(const GURL& url,
                                                  const std::string& result,
                                                  bool success,
                                                 bool notify_needed,
                                                 intptr_t notify_data) {
  if (instance() != nullptr) { /* FIX [CWE-476]: prevent null pointer dereference */
    instance()->SendJavaScriptStream(url, result, success, notify_needed,
                                   notify_data);
  }
 }