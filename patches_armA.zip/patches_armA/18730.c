/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       18730  |  Dataset: bigvul
   Function:     unknown_18730
   Dominant CWE: struct-array
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5595
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index access
 */

const CuePoint* Cues::GetLast() const {
  if (m_cue_points == NULL)
     return NULL;
 
  if (m_count <= 0)
    return NULL;

   const long index = m_count - 1;
 
   CuePoint* const* const pp = m_cue_points;
  assert(pp);
 
   /* FIX [CWE-129]: Validate array index is within bounds before access */
   if (index < 0 || (size_t)index >= m_count) {
     return NULL; // or handle error
   }
 
   CuePoint* const pCP = pp[index];
  assert(pCP);
  assert(pCP->GetTimeCode() >= 0);
 
   return pCP;
 }