/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       18733  |  Dataset: bigvul
   Function:     unknown_18733
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6117
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds check for pointer operations around e->name()
 */

string16 ExtensionGlobalError::GenerateMessageSection(
    const ExtensionIdSet* extensions,
    int template_message_id) {
  CHECK(extensions);
  CHECK(template_message_id);
  string16 message;

   for (ExtensionIdSet::const_iterator iter = extensions->begin();
        iter != extensions->end(); ++iter) {
     const Extension* e = extension_service_->GetExtensionById(*iter, true);
    if (!e || !e->name()) { /* FIX [CWE-476]: null pointer dereference */
      LOG(ERROR) << "Invalid extension or name";
      continue;
    }
    message += l10n_util::GetStringFUTF16(
        template_message_id,
        string16(ASCIIToUTF16(e->name())), /* FIX [CWE-120]: bounds check for e->name() */
        l10n_util::GetStringUTF16(IDS_SHORT_PRODUCT_NAME));
   }
   return message;
 }