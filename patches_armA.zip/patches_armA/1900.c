/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1900  |  Dataset: bigvul
   Function:     unknown_1900
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5980
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for frame_ pointer before using it.
 */

void FrameSelection::MoveRangeSelectionExtent(const IntPoint& contents_point) {
  if (ComputeVisibleSelectionInDOMTree().IsNone())
    return;

  if (!frame_) { /* FIX [CWE-476]: Null pointer dereference */ 
    // Handle null frame_ case, e.g., log an error or throw an exception
    return;
  }

  SetSelection(
      SelectionInDOMTree::Builder(
          GetGranularityStrategy()->UpdateExtent(contents_point, frame_))
         .SetIsHandleVisible(true)
         .Build(),
      SetSelectionData::Builder()
         .SetShouldCloseTyping(true)
         .SetShouldClearTypingStyle(true)
         .SetDoNotClearStrategy(true)
         .SetSetSelectionBy(SetSelectionBy::kUser)
         .Build());
}