/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       1962  |  Dataset: bigvul
   Function:     unknown_1962
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds check for remoteDescription.type() to prevent potential buffer overflow.
 */

void MockWebRTCPeerConnectionHandler::setRemoteDescription(const WebRTCVoidRequest& request, const WebRTCSessionDescriptionDescriptor& remoteDescription)
{
    if (!remoteDescription.isNull() && 
        remoteDescription.type().length() > 0 && /* FIX [CWE-120]: bounds check for type */
        remoteDescription.type()[0] == 'a' && /* FIX [CWE-120]: explicit comparison for "answer" */
        strcmp(remoteDescription.type(), "answer") == 0) {
        m_remoteDescription = remoteDescription;
        postTask(new RTCVoidRequestTask(this, request, true));
    } else
        postTask(new RTCVoidRequestTask(this, request, false));
}