/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       2089  |  Dataset: bigvul
   Function:     unknown_2089
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6498
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds checking for array indices to prevent potential out-of-bounds access.
 */

static __u8 *ch_report_fixup(struct hid_device *hdev, __u8 *rdesc,
 		unsigned int *rsize)
 {
	if (*rsize >= 18 && rdesc[11] == 0x3c && rdesc[12] == 0x02) { /* FIX [CWE-129]: added bounds check for array index */
 		hid_info(hdev, "fixing up Cherry Cymotion report descriptor\n");
 		if (*rsize > 16) { /* FIX [CWE-129]: added bounds check for array index */
 			rdesc[11] = rdesc[16] = 0xff;
 		}
 		if (*rsize > 17) { /* FIX [CWE-129]: added bounds check for array index */
 			rdesc[12] = rdesc[17] = 0x03;
 		}
	}
	return rdesc;
}