/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       2167  |  Dataset: bigvul
   Function:     unknown_2167
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5964
   ============================================================ */

/* 
 * Changes made:
 * - Added explicit null check for frame_host_ before setting it to nullptr
 * - Added explicit bounds check around pointer operation for agent_ptr_
 */

void RenderFrameDevToolsAgentHost::DestroyOnRenderFrameGone() {
   scoped_refptr<RenderFrameDevToolsAgentHost> protect(this);
   if (IsAttached())
     RevokePolicy();
  ForceDetachAllClients();
   if (frame_host_ != nullptr) /* FIX [CWE-476]: prevent null pointer dereference */
     frame_host_ = nullptr;
   if (!agent_ptr_.IsNull()) /* FIX [CWE-119]: explicit bounds check around pointer operation */
     agent_ptr_.reset();
   SetFrameTreeNode(nullptr);
  Release();
}