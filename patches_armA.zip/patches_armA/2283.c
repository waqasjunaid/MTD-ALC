/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       2283  |  Dataset: bigvul
   Function:     unknown_2283
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/* 
 * Changes made:
 * - Added a null check for the return value of GetSurfaceManager()
 */

void OffscreenCanvasFrameReceiverImpl::SubmitCompositorFrame(
    const cc::SurfaceId& surface_id,
    cc::CompositorFrame frame) {
  cc::SurfaceManager* surface_manager = GetSurfaceManager(); /* FIX [CWE-476]: Added null check for surface manager */
  if (surface_manager) { /* FIX [CWE-476]: Check for null before dereferencing */
    cc::Surface* surface = surface_manager->GetSurfaceForId(surface_id);
    if (surface) {
      surface->QueueFrame(std::move(frame), base::Closure());
    }
  }
}