/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       2370  |  Dataset: bigvul
   Function:     sum_update
   Dominant CWE: CWE-120
   Error source: MISSED_VULN
   MTD verdict:  NON_VULNERABLE  V=0.0084
   ALC decision: UNTRUSTWORTHY  T=0.6815
   ============================================================ */

/*
 * CHANGES MADE:
 * 1. Added bounds checking to prevent buffer overflow in memcpy calls.
 */

void sum_update(const char *p, int32 len)
{
	switch (cursum_type) {
	  case CSUM_MD5:
		md5_update(&md, (uchar *)p, len);
		break;
          case CSUM_MD4:
          case CSUM_MD4_OLD:
          case CSUM_MD4_BUSTED:
                if (len + sumresidue < CSUM_CHUNK) {
                        /* FIX [CWE-120]: Prevent buffer overflow by checking destination buffer size */
                        memcpy(md.buffer + sumresidue, p, (size_t)len < sizeof(md.buffer) - sumresidue ? len : sizeof(md.buffer) - sumresidue);
                        sumresidue += len;
		}

		if (sumresidue) {
			int32 i = CSUM_CHUNK - sumresidue;
			/* FIX [CWE-120]: Prevent buffer overflow by checking destination buffer size */
			memcpy(md.buffer + sumresidue, p, (size_t)i < sizeof(md.buffer) - sumresidue ? i : sizeof(md.buffer) - sumresidue);
			mdfour_update(&md, (uchar *)md.buffer, CSUM_CHUNK);
			len -= i;
			p += i;
		}

		while (len >= CSUM_CHUNK) {
			mdfour_update(&md, (uchar *)p, CSUM_CHUNK);
			len -= CSUM_CHUNK;
			p += CSUM_CHUNK;
		}

		sumresidue = len;
		if (sumresidue)
			/* FIX [CWE-120]: Prevent buffer overflow by checking destination buffer size */
			memcpy(md.buffer, p, (size_t)sumresidue < sizeof(md.buffer) ? sumresidue : sizeof(md.buffer));
		break;
	  case CSUM_NONE:
		break;
	}
}