/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       2587  |  Dataset: bigvul
   Function:     ReadUncompressedRGB
   Dominant CWE: CWE-190
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6061
   ============================================================ */

/* CHANGES MADE:
 * - Fixed integer truncation vulnerability in bit shift operations
 */

static MagickBooleanType ReadUncompressedRGB(Image *image, DDSInfo *dds_info,
  ExceptionInfo *exception)
{
  PixelPacket
    *q;

  ssize_t
    x, y;

  unsigned short
    color;

  if (dds_info->pixelformat.rgb_bitcount == 8)
    (void) SetImageType(image,GrayscaleType);
  else if (dds_info->pixelformat.rgb_bitcount == 16 && !IsBitMask(
    dds_info->pixelformat,0xf800,0x07e0,0x001f,0x0000))
    ThrowBinaryException(CorruptImageError,"ImageTypeNotSupported",
      image->filename);

  for (y = 0; y < (ssize_t) dds_info->height; y++)
  {
    q = QueueAuthenticPixels(image, 0, y, dds_info->width, 1,exception);

    if (q == (PixelPacket *) NULL)
      return MagickFalse;

    for (x = 0; x < (ssize_t) dds_info->width; x++)
    {
      if (dds_info->pixelformat.rgb_bitcount == 8)
        SetPixelGray(q,ScaleCharToQuantum(ReadBlobByte(image)));
      else if (dds_info->pixelformat.rgb_bitcount == 16)
        {
           color=ReadBlobShort(image);
           /* FIX [CWE-190]: Prevent integer truncation in bit shift operation */
           unsigned int shifted_color = (unsigned int)color;
           SetPixelRed(q,ScaleCharToQuantum((unsigned char)
             (((shifted_color >> 11)/31.0)*255)));
           SetPixelGreen(q,ScaleCharToQuantum((unsigned char)
             ((((unsigned int)(shifted_color << 5) >> 10)/63.0)*255)));
           SetPixelBlue(q,ScaleCharToQuantum((unsigned char)
             ((((unsigned int)(shifted_color << 11) >> 11)/31.0)*255)));
        }
      else
        {
          SetPixelBlue(q,ScaleCharToQuantum((unsigned char)
            ReadBlobByte(image)));
          SetPixelGreen(q,ScaleCharToQuantum((unsigned char)
            ReadBlobByte(image)));
          SetPixelRed(q,ScaleCharToQuantum((unsigned char)
            ReadBlobByte(image)));
          if (dds_info->pixelformat.rgb_bitcount == 32)
            (void) ReadBlobByte(image);
        }
      SetPixelAlpha(q,QuantumRange);
      q++;
    }
 
    if (SyncAuthenticPixels(image,exception) == MagickFalse)
       return MagickFalse;
   }
 
  SkipRGBMipmaps(image, dds_info, 3);
  return MagickTrue;
 }