/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       2762  |  Dataset: bigvul
   Function:     unknown_2762
   Dominant CWE: CWE-190
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5758
   ============================================================ */

/* 
 * Changes made:
 * - Added overflow check before shifting and casting to prevent integer overflow
 */

XGetModifierMapping(register Display *dpy)
{
    xGetModifierMappingReply rep;
    register xReq *req;
    unsigned long nbytes;
    XModifierKeymap *res;

    LockDisplay(dpy);
     GetEmptyReq(GetModifierMapping, req);
     (void) _XReply (dpy, (xReply *)&rep, 0, xFalse);
 
    if ((unsigned long)rep.length <= (SIZE_MAX >> 2)) { /* FIX [CWE-190]: prevent overflow */
 	nbytes = rep.length << 2; /* FIX [CWE-190]: use unsigned arithmetic */
 	res = Xmalloc(sizeof (XModifierKeymap));
 	if (res)
    } else
	res = NULL;
    if ((! res) || (! res->modifiermap)) {
	Xfree(res);
	res = (XModifierKeymap *) NULL;
	_XEatDataWords(dpy, rep.length);
    } else {
	_XReadPad(dpy, (char *) res->modifiermap, (long) nbytes); /* FIX [CWE-190]: cast to char* is still necessary */
	res->max_keypermod = rep.numKeyPerModifier;
    }

    UnlockDisplay(dpy);
    SyncHandle();
    return (res);
}