/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       278  |  Dataset: bigvul
   Function:     hns_xgmac_get_sset_count
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6900
   ============================================================ */

/*
 * CHANGES MADE:
 * - Added input validation for the 'stringset' parameter
 */

static int hns_xgmac_get_sset_count(int stringset)
{
	/* FIX [CWE-20]: Validate input to prevent invalid values */
	if (stringset < 0 || stringset >= ETH_SS_MAX) {
		return 0; /* or handle error, depending on the desired behavior */
	}

	if (stringset == ETH_SS_STATS)
 		/* FIX [CWE-119]: Ensure array index is within bounds */
 		return ARRAY_SIZE(g_xgmac_stats_string);
 
 	return 0;
}