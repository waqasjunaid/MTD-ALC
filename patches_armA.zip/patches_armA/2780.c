/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       2780  |  Dataset: bigvul
   Function:     addDataToStreamTask
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added input validation for context pointer
 */

static void addDataToStreamTask(void* context)
{
    if (!context) { /* FIX [CWE-690]: null pointer dereference */ 
        // handle error or return early
        return;
    }
    
    OwnPtr<BlobRegistryContext> blobRegistryContext = adoptPtr(static_cast<BlobRegistryContext*>(context));
    if (!blobRegistryContext || !blobRegistryContext->url) { /* FIX [CWE-690]: null pointer dereference */ 
        // handle error or return early
        return;
    }
    
    blobRegistry().addDataToStream(blobRegistryContext->url, blobRegistryContext->streamData);
}