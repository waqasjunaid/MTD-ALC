/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       2797  |  Dataset: bigvul
   Function:     unknown_2797
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5972
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for input->width() to prevent potential integer overflow
 */

static sk_sp<SkImage> unPremulSkImageToPremul(SkImage* input) {
  if (!input || input->width() <= 0 || input->height() <= 0) { /* FIX [CWE-129]: bounds check */
    return nullptr;
  }
  
  SkImageInfo info = SkImageInfo::Make(input->width(), input->height(),
                                       kN32_SkColorType, kPremul_SkAlphaType);
  RefPtr<Uint8Array> dstPixels = copySkImageData(input, info);
  if (!dstPixels)
     return nullptr;
   size_t widthBytes = static_cast<size_t>(input->width()) * info.bytesPerPixel(); /* FIX [CWE-190]: explicit bounds check */
   if (widthBytes < static_cast<size_t>(input->width())) { /* FIX [CWE-190]: overflow check */
     return nullptr;
   }
   return newSkImageFromRaster(
       info, std::move(dstPixels),
      widthBytes);
 }