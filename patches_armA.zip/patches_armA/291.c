/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       291  |  Dataset: bigvul
   Function:     GoBackCrossSite
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5967
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds check for NavigationEntry* entry
 */

void GoBackCrossSite() {
    NavigationEntry* entry = contents()->controller().GetEntryAtOffset(-1);
    if (entry) { /* FIX [CWE-119]: Ensure pointer is not null before use */
        ASSERT_TRUE(entry);
        contents()->controller().GoBack();
 
        contents()->TestDidNavigate(
            contents()->pending_rvh(), entry->page_id(), GURL(entry->url()),
            content::PAGE_TRANSITION_TYPED);
    }
}