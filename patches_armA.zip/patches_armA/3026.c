/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3026  |  Dataset: bigvul
   Function:     unknown_3026
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5997
   ============================================================ */

/* 
 * CHANGES:
 * - Added NULL checks for Profile::FromBrowserContext, TabSpecificContentSettings::FromWebContents, and InfoBarService::FromWebContents
 */

WebsiteSettingsPopupAndroid::WebsiteSettingsPopupAndroid(
    JNIEnv* env,
    jobject java_website_settings_pop,
    content::WebContents* web_contents) {
  content::NavigationEntry* nav_entry =
      web_contents->GetController().GetVisibleEntry();
  if (nav_entry == NULL)
    return;

  url_ = nav_entry->GetURL();

  popup_jobject_.Reset(env, java_website_settings_pop);

  Profile* profile = Profile::FromBrowserContext(web_contents->GetBrowserContext());
  TabSpecificContentSettings* tab_specific_content_settings =
      TabSpecificContentSettings::FromWebContents(web_contents);
  InfoBarService* info_bar_service = InfoBarService::FromWebContents(web_contents);

  if (profile && tab_specific_content_settings && info_bar_service) {
    presenter_.reset(new WebsiteSettings(
         this,
         profile, /* FIX [CWE-690]: Validate return value of Profile::FromBrowserContext */
         tab_specific_content_settings, /* FIX [CWE-690]: Validate return value of TabSpecificContentSettings::FromWebContents */
         info_bar_service, /* FIX [CWE-690]: Validate return value of InfoBarService::FromWebContents */
         nav_entry->GetURL(),
         nav_entry->GetSSL(),
         content::CertStore::GetInstance()));
  }
}