/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3137  |  Dataset: bigvul
   Function:     unknown_3137
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5966
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds checks around pointer/array operations.
 */

void Vp9Parser::ReadSegmentation() {
  segmentation_.update_map = false;
  segmentation_.update_data = false;

  if (reader_.IsValid()) { /* FIX [CWE-129]: Validate reader_ before use */
    segmentation_.enabled = reader_.ReadBool();
    if (!segmentation_.enabled)
      return;

    if (reader_.HasMoreData()) { /* FIX [CWE-129]: Check for more data before reading */
      segmentation_.update_map = reader_.ReadBool();
      if (segmentation_.update_map) {
        if (reader_.IsValidPointer()) { /* FIX [CWE-824]: Validate pointer before use */
          ReadSegmentationMap();
        }
      }

      segmentation_.update_data = reader_.ReadBool();
      if (segmentation_.update_data) {
        if (reader_.IsValidPointer()) { /* FIX [CWE-824]: Validate pointer before use */
          ReadSegmentationData();
        }
      }
    }
  }
}