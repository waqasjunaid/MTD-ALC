/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3138  |  Dataset: bigvul
   Function:     unknown_3138
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6482
   ============================================================ */

/* 
 * Changes made:
 *   Added bounds checks for haystack and needle lengths
 *   Added explicit type casts for integer conversions
 */

PHP_FUNCTION(grapheme_strpos)
{
	unsigned char *haystack, *needle;
        int haystack_len, needle_len;
        unsigned char *found;
        long loffset = 0;
       int32_t offset = 0;
        int ret_pos;

        if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss|l", (char **)&haystack, &haystack_len, (char **)&needle, &needle_len, &loffset) == FAILURE) {

		intl_error_set( NULL, U_ILLEGAL_ARGUMENT_ERROR,
			 "grapheme_strpos: unable to parse input param", 0 TSRMLS_CC );

		RETURN_FALSE;
	}

	if ( OUTSIDE_STRING(loffset, haystack_len) ) {

		intl_error_set( NULL, U_ILLEGAL_ARGUMENT_ERROR, "grapheme_strpos: Offset not contained in string", 1 TSRMLS_CC );

		RETURN_FALSE;
	}
 
        /* FIX [CWE-190]: Ensure offset is within integer range */
        if (loffset > INT32_MAX) {
            intl_error_set( NULL, U_ILLEGAL_ARGUMENT_ERROR, "grapheme_strpos: Offset out of range", 1 TSRMLS_CC );
            RETURN_FALSE;
        }

        offset = (int32_t) loffset; /* FIX [CWE-190]: Explicit type cast */

        if (needle_len == 0) { /* FIX [CWE-691]: Check for empty delimiter */
		intl_error_set( NULL, U_ILLEGAL_ARGUMENT_ERROR, "grapheme_strpos: Empty delimiter", 1 TSRMLS_CC );
		RETURN_FALSE;
	}

	if (haystack_len < needle_len) { /* FIX [CWE-127]: Ensure haystack is large enough */
		intl_error_set( NULL, U_ILLEGAL_ARGUMENT_ERROR, "grapheme_strpos: Haystack too short", 1 TSRMLS_CC );
		RETURN_FALSE;
	}
 
        /* ... rest of the function remains unchanged ... */