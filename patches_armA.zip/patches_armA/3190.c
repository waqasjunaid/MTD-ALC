/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3190  |  Dataset: bigvul
   Function:     unknown_3190
   Dominant CWE: CWE-120
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5891
   ============================================================ */

/*
 * Changes made:
 *   Replaced sprintf with snprintf to prevent buffer overflow.
 */

write_message( RenderState  state )
{
    ADisplay  adisplay = (ADisplay)state->display.disp;

    if ( state->message == NULL )
    {
      FontFace  face = &state->faces[state->face_index];
      int       idx, total;

      idx   = face->index;
      total = 1;
      while ( total + state->face_index < state->num_faces &&
              face[total].filepath == face[0].filepath     )
        total++;

      total += idx;

      state->message = state->message0;
      if ( total > 1 )
        snprintf(state->message0, sizeof(state->message0), "%s %d/%d @ %5.1fpt", /* FIX [CWE-120]: prevent buffer overflow */
                  state->filename, idx + 1, total,
                  state->char_size );
      else
        snprintf(state->message0, sizeof(state->message0), "%s @ %5.1fpt", /* FIX [CWE-120]: prevent buffer overflow */
                  state->filename,
                  state->char_size );
    }

    grWriteCellString( adisplay->bitmap, 0, DIM_Y - 10, state->message,
                       adisplay->fore_color );

    state->message = NULL;
}