/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3448  |  Dataset: bigvul
   Function:     unknown_3448
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * CHANGES MADE:
 * - Added input validation for function_name
 */

bool Extension::HasAPIPermission(const std::string& function_name) const {
  if (function_name.empty()) { /* FIX [CWE-20]: Validate all inputs */
    return false;
  }
  base::AutoLock auto_lock(runtime_data_lock_);
  return runtime_data_.GetActivePermissions()->
      HasAccessToFunction(function_name);
}