/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3561  |  Dataset: bigvul
   Function:     ip6_find_1stfragopt
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6885
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for packet_len to prevent out-of-bounds access
 * - Added null pointer check for exthdr to prevent null pointer dereference
 */

int ip6_find_1stfragopt(struct sk_buff *skb, u8 **nexthdr)
{
	u16 offset = sizeof(struct ipv6hdr);
	struct ipv6_opt_hdr *exthdr =
				(struct ipv6_opt_hdr *)(ipv6_hdr(skb) + 1); /* FIX [CWE-119]: potential null pointer dereference */
	unsigned int packet_len = skb_tail_pointer(skb) -
		skb_network_header(skb);

	if (packet_len == 0) { /* FIX [CWE-125]: bounds check for packet_len */
		return offset;
	}

	int found_rhdr = 0;
	*nexthdr = &ipv6_hdr(skb)->nexthdr;

	while (offset + 1 <= packet_len && exthdr != NULL) { /* FIX [CWE-119]: null pointer check */

		switch (**nexthdr) {

		case NEXTHDR_HOP:
			break;
		case NEXTHDR_ROUTING:
			found_rhdr = 1;
			break;
		case NEXTHDR_DEST:
#if IS_ENABLED(CONFIG_IPV6_MIP6)
			if (ipv6_find_tlv(skb, offset, IPV6_TLV_HAO) >= 0)
				break;
#endif
			if (found_rhdr)
				return offset;
			break;
		default:
			return offset;
		}

		offset += ipv6_optlen(exthdr);
		*nexthdr = &exthdr->nexthdr;
		exthdr = (struct ipv6_opt_hdr *)(skb_network_header(skb) +
						 offset); /* FIX [CWE-119]: potential null pointer dereference */
	}

	return offset;
}