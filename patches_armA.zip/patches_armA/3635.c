/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3635  |  Dataset: bigvul
   Function:     unknown_3635
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * Changes made:
 * - Added a null check for the return value of GetTextInputClient()
 * - Added a bounds check to ensure client is not null before calling its methods
 */

void InputMethodBase::OnInputMethodChanged() const {
  TextInputClient* client = GetTextInputClient();
  if (client != nullptr) { /* FIX [CWE-476]: Ensure client is not null */
    if (client->GetTextInputType() != TEXT_INPUT_TYPE_NONE)
      client->OnInputMethodChanged(); /* FIX [CWE-476]: Validate return value of GetTextInputClient() before use */
  }
}