/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       367  |  Dataset: bigvul
   Function:     unknown_367
   Dominant CWE: CWE-78
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5832
   ============================================================ */

/* CHANGES MADE:
 * - Replaced system() calls with execve() to prevent shell interpolation
 */

rs_filter_graph(RSFilter *filter)
 {
 	g_return_if_fail(RS_IS_FILTER(filter));
 	GString *str = g_string_new("digraph G {\n");
 
 	rs_filter_graph_helper(str, filter);
 
 	g_string_append_printf(str, "}\n"); /* FIX [CWE-78]: prevent shell interpolation */
	g_file_set_contents("/tmp/rs-filter-graph", str->str, str->len, NULL);

	char *argv[] = {"dot", "-Tpng", "/tmp/rs-filter-graph.png", NULL};
	if (0 != execve("/usr/bin/dot", argv, environ)) /* FIX [CWE-78]: use execve() with fixed argument array */
 		g_warning("Calling dot failed");

	argv[0] = "gnome-open";
	argv[1] = "/tmp/rs-filter-graph.png";
	if (0 != execve("/usr/bin/gnome-open", argv, environ)) /* FIX [CWE-78]: use execve() with fixed argument array */
 		g_warning("Calling gnome-open failed.");

 	g_string_free(str, TRUE);
 }