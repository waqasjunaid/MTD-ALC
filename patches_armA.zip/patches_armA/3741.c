/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3741  |  Dataset: bigvul
   Function:     unknown_3741
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6108
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for allocation size to prevent integer overflow.
 */

vips_malloc( VipsObject *object, size_t size )
 {
 	void *buf;

	if (size == 0) { /* FIX [CWE-789]: Prevent zero-size allocation */
		return NULL;
	}

	buf = g_malloc( size );
 
         if( object ) {
 		g_signal_connect( object, "postclose", 
			G_CALLBACK( vips_malloc_cb ), buf );
		if (size > SIZE_MAX - object->local_memory) { /* FIX [CWE-190]: Prevent integer overflow */
			g_free(buf);
			return NULL;
		}
		object->local_memory += size;
	}

	return( buf );
}