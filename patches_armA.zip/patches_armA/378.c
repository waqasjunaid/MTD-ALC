/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       378  |  Dataset: bigvul
   Function:     removeElementPreservingChildren
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6793
   ============================================================ */

/* 
 * CHANGES:
 * - Added null checks for 'element' and 'fragment' to prevent potential crashes.
 */

static inline void removeElementPreservingChildren(PassRefPtr<DocumentFragment> fragment, HTMLElement* element)
{
    if (!element || !fragment) /* FIX [CWE-476]: Potential NULL pointer dereference */
        return;

    ExceptionCode ignoredExceptionCode;
    RefPtr<Node> nextChild;
    for (RefPtr<Node> child = element->firstChild(); child; child = nextChild) {
        nextChild = child->nextSibling();
        if (!child.get()) /* FIX [CWE-476]: Potential NULL pointer dereference */
            continue;

        element->removeChild(child.get(), ignoredExceptionCode);
        ASSERT(!ignoredExceptionCode);

        fragment->insertBefore(child, element, ignoredExceptionCode);
        ASSERT(!ignoredExceptionCode);
    }
    fragment->removeChild(element, ignoredExceptionCode);
    ASSERT(!ignoredExceptionCode);
}