/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3792  |  Dataset: bigvul
   Function:     unknown_3792
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * Changes made:
 * - Added a null check for audio_manager to prevent potential crashes.
 */

media::AudioParameters GetDeviceParametersOnDeviceThread(
    media::AudioManager* audio_manager,
    const std::string& unique_id) {
  if (!audio_manager) { /* FIX [CWE-476]: Prevent null pointer dereference */ 
    // Handle the error, for example:
    LOG(ERROR) << "audio_manager is null";
    return media::AudioParameters(); // or some other default value
  }
  DCHECK(audio_manager->GetTaskRunner()->BelongsToCurrentThread());
  return media::AudioDeviceDescription::IsDefaultDevice(unique_id)
             ? audio_manager->GetDefaultOutputStreamParameters()
             : audio_manager->GetOutputStreamParameters(unique_id);
}