/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       3916  |  Dataset: bigvul
   Function:     IsSensitiveURL
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0272
   ALC decision: UNTRUSTWORTHY  T=0.6668
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds checks around pointer/array operations.
 */

bool IsSensitiveURL(const GURL& url,
                    bool is_request_from_browser_or_webui_renderer) {
  bool sensitive_chrome_url = false;
  const char kGoogleCom[] = "google.com";
  const char kClient[] = "clients";
  url::Origin origin = url::Origin::Create(url);
  if (origin.DomainIs(kGoogleCom)) {
    base::StringPiece host = url.host_piece();
    while (!host.empty() && host.ends_with(".")) /* FIX [CWE-119]: bounds check */
      host.remove_suffix(1u);
    if (is_request_from_browser_or_webui_renderer) {
      base::StringPiece::size_type pos = host.rfind(kClient);
      if (pos != base::StringPiece::npos && pos < host.size()) /* FIX [CWE-119]: bounds check */
      {
        bool match = true;
        if (pos > 0 && pos < host.size() && host[pos - 1] != '.') /* FIX [CWE-119]: bounds check */
        {
          match = false;
        } else {
          for (base::StringPiece::const_iterator
                   i = host.begin() + pos + strlen(kClient),
                   end = host.end() - (strlen(kGoogleCom) + 1);
               i != end && i < host.end(); ++i) /* FIX [CWE-119]: bounds check */
          {
            if (!isdigit(*i)) {
              match = false;
              break;
            }
          }
        }
        sensitive_chrome_url = sensitive_chrome_url || match;
      }
    }

    sensitive_chrome_url = sensitive_chrome_url ||
                           (url.DomainIs("chrome.google.com") &&
                             base::StartsWith(url.path_piece(), "/webstore",
                                              base::CompareCase::SENSITIVE));
   }
   return sensitive_chrome_url || extension_urls::IsWebstoreUpdateUrl(url) ||
          extension_urls::IsBlacklistUpdateUrl(url) ||
          extension_urls::IsSafeBrowsingUrl(origin, url.path_piece());
}