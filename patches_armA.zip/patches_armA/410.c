/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       410  |  Dataset: bigvul
   Function:     unknown_410
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for existing_stream to prevent potential null pointer dereference.
 */

WebPluginResourceClient* WebPluginDelegateImpl::CreateResourceClient(
    unsigned long resource_id, const GURL& url, bool notify_needed,
    intptr_t notify_data, intptr_t existing_stream) {
  if (existing_stream && reinterpret_cast<NPAPI::PluginStream*>(existing_stream) != nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
    NPAPI::PluginStream* plugin_stream =
        reinterpret_cast<NPAPI::PluginStream*>(existing_stream);
    return plugin_stream->AsResourceClient();
  }
 
  std::string mime_type;
  NPAPI::PluginStreamUrl *stream = instance()->CreateStream(
      resource_id, url, mime_type, notify_needed,
      reinterpret_cast<void*>(notify_data));
  if (stream != nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
    return stream;
  } else {
    // Handle the case where CreateStream returns a null pointer
    // This could be done by returning a default value, throwing an exception, etc.
    // For this example, we will simply return nullptr
    return nullptr; /* FIX [CWE-476]: Return a safe value in case of error */
  }
}