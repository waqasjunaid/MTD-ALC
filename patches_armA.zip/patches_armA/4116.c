/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       4116  |  Dataset: bigvul
   Function:     put_crypt_info
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6903
   ============================================================ */

/*
 * Changes made:
 * - Added NULL check for ci->ci_keyring_key before calling key_put()
 * - Added NULL check for ci->ci_ctfm before calling crypto_free_skcipher()
 */

static void put_crypt_info(struct fscrypt_info *ci)
{
	if (!ci)
		return;

	if (ci->ci_keyring_key) /* FIX [CWE-690]: prevent potential NULL pointer dereference */
		key_put(ci->ci_keyring_key);
	if (ci->ci_ctfm) /* FIX [CWE-690]: prevent potential NULL pointer dereference */
		crypto_free_skcipher(ci->ci_ctfm);
	kmem_cache_free(fscrypt_info_cachep, ci);
}