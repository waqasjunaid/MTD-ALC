/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       4122  |  Dataset: bigvul
   Function:     SetManualFallbacksForFilling
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6915
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added explicit bounds check for boolean input 'enabled' to prevent potential misuse.
 */

void SetManualFallbacksForFilling(bool enabled) {
  /* FIX [CWE-20]: Validate all inputs */
  if (enabled == true || enabled == false) { /* FIX [CWE-20]: Explicit bounds check */
    if (enabled) {
      scoped_feature_list_.InitAndEnableFeature(
        password_manager::features::kEnableManualFallbacksFilling);
    } else {
      scoped_feature_list_.InitAndDisableFeature(
        password_manager::features::kEnableManualFallbacksFilling);
    }
  } /* FIX [CWE-20]: Prevent potential misuse of 'enabled' */
}