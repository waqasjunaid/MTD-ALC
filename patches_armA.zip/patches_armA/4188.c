/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       4188  |  Dataset: bigvul
   Function:     encrypt
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6908
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added explicit bounds checks around pointer/array operations.
 */

static int encrypt(struct blkcipher_desc *desc,
		   struct scatterlist *dst, struct scatterlist *src,
		   unsigned int nbytes)
{
	struct blkcipher_walk walk;
	struct crypto_blkcipher *tfm = desc->tfm;
	struct salsa20_ctx *ctx = crypto_blkcipher_ctx(tfm);
	int err;

	blkcipher_walk_init(&walk, dst, src, nbytes);
	err = blkcipher_walk_virt_block(desc, &walk, 64);

	if (err) { /* FIX [CWE-390]: Check return value of blkcipher_walk_virt_block */ 
		return err;
	}

	salsa20_ivsetup(ctx, walk.iv);

	if (likely(walk.nbytes == nbytes))
	{
		if (walk.dst.virt.addr != NULL && walk.src.virt.addr != NULL) { /* FIX [CWE-124]: Check for null pointers */
			salsa20_encrypt_bytes(ctx, walk.dst.virt.addr,
					      walk.src.virt.addr, nbytes);
		} else {
			return -EINVAL; /* FIX [CWE-390]: Return error on invalid input */
		}
		return blkcipher_walk_done(desc, &walk, 0);
	}

	while (walk.nbytes >= 64) {
		if (walk.dst.virt.addr != NULL && walk.src.virt.addr != NULL) { /* FIX [CWE-124]: Check for null pointers */
			salsa20_encrypt_bytes(ctx, walk.dst.virt.addr,
					      walk.src.virt.addr,
					      walk.nbytes - (walk.nbytes % 64));
		} else {
			return -EINVAL; /* FIX [CWE-390]: Return error on invalid input */
		}
		err = blkcipher_walk_done(desc, &walk, walk.nbytes % 64);
		if (err) { /* FIX [CWE-390]: Check return value of blkcipher_walk_done */ 
			return err;
		}
	}

	if (walk.nbytes) {
		if (walk.dst.virt.addr != NULL && walk.src.virt.addr != NULL) { /* FIX [CWE-124]: Check for null pointers */
			salsa20_encrypt_bytes(ctx, walk.dst.virt.addr,
					      walk.src.virt.addr, walk.nbytes);
		} else {
			return -EINVAL; /* FIX [CWE-390]: Return error on invalid input */
		}
		err = blkcipher_walk_done(desc, &walk, 0);
		if (err) { /* FIX [CWE-390]: Check return value of blkcipher_walk_done */ 
			return err;
		}
	}

	return err;
}