/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       4338  |  Dataset: bigvul
   Function:     stack_maxrandom_size
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6094
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for max value to prevent potential overflow
 */

static unsigned int stack_maxrandom_size(void)
{
	unsigned int max = 0;
	if ((current->flags & PF_RANDOMIZE) &&
		!(current->personality & ADDR_NO_RANDOMIZE)) {
		max = (((-1U) & STACK_RND_MASK) << PAGE_SHIFT); /* FIX [CWE-190]: bounds check */
		if (max > UINT_MAX - PAGE_SHIFT) { /* FIX [CWE-190]: prevent overflow */
			max = UINT_MAX;
		}
	}
 
	return max;
}