/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       4506  |  Dataset: bigvul
   Function:     omninet_open
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5997
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds checking for array index access in line 5
 */

static int omninet_open(struct tty_struct *tty, struct usb_serial_port *port)
{
	struct usb_serial	*serial = port->serial;
	struct usb_serial_port	*wport;
	if (1 >= 0 && (size_t)1 < ARRAY_SIZE(serial->port)) { /* FIX [CWE-129]: validate array index bounds */
		wport = serial->port[1];
	} else {
		return -EINVAL; /* or some other error handling */
	}
	tty_port_tty_set(&wport->port, tty);
	return usb_serial_generic_open(tty, port);
}