/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       4644  |  Dataset: bigvul
   Function:     unknown_4644
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for index before accessing tab at that index
 */

void TabStripGtk::TabDetachedAt(TabContents* contents, int index) {
   GenerateIdealBounds();
  if (index >= 0 && index < GetNumberOfTabs()) { /* FIX [CWE-129]: bounds check */
    StartRemoveTabAnimation(index, contents->web_contents());
    GetTabAt(index)->set_closing(true);
  }
}