/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       4660  |  Dataset: bigvul
   Function:     ps_files_valid_key
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/* 
 * Changes made:
 * - Added explicit bounds check for pointer operation
 */

static int ps_files_valid_key(const char *key)
{
    size_t len;
    const char *p;
    char c;
    int ret = 1;

    /* FIX [CWE-170]: Validate input pointer */
    if (key == NULL) {
        return 0;
    }

    for (p = key; (c = *p); p++) {
        /* valid characters are a..z,A..Z,0..9 */
        if (!((c >= 'a' && c <= 'z')
                        || (c >= 'A' && c <= 'Z')
                        || (c >= '0' && c <= '9')
                        || c == ','
                        || c == '-')) {
            ret = 0;
            break;
        }
    }

    /* FIX [CWE-119]: Add explicit bounds check for pointer operation */
    if (p - key > SIZE_MAX) {
        return 0;
    }

    len = p - key;

    /* Somewhat arbitrary length limit here, but should be way more than
       anyone needs and avoids file-level warnings later on if we exceed MAX_PATH */
    if (len == 0 || len > 128) {
        ret = 0;
    }
    return ret;
}