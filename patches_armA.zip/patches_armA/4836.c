/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       4836  |  Dataset: bigvul
   Function:     cJSON_AddItemReferenceToObject
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * Changes made:
 * - Added input validation for 'object' and 'item'
 */

void cJSON_AddItemReferenceToObject( cJSON *object, const char *string, cJSON *item )
{
	if (object == NULL || item == NULL) { /* FIX [CWE-690]: Validate all inputs */ 
		return;
	}
	cJSON_AddItemToObject( object, string, create_reference( item ) );
}