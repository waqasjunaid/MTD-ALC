/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5072  |  Dataset: bigvul
   Function:     unknown_5072
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5975
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checks for width and height parameters
 */

void GpuProcessHostUIShim::OnAcceleratedSurfaceNew(
    const GpuHostMsg_AcceleratedSurfaceNew_Params& params) {
  RenderWidgetHostViewPort* view = GetRenderWidgetHostViewFromSurfaceID(
       params.surface_id);
   if (!view)
     return;
   if (params.width <= 0 || params.height <= 0) { /* FIX [CWE-129]: invalid input */
     // handle error or return early
     return;
   }
   view->AcceleratedSurfaceNew(
      params.width, params.height, params.surface_handle);
 }