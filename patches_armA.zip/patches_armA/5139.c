/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5139  |  Dataset: bigvul
   Function:     safecat
   Dominant CWE: CWE-119
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6160
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds checks before every buffer/array access
 */

static size_t safecat(char *buffer, size_t bufsize, size_t pos,
   PNG_CONST char *cat)
 {
    while (pos < bufsize && cat != NULL && *cat != 0) {
       if (pos + 1 >= bufsize) { /* FIX [CWE-119]: prevent buffer overflow */
          break;
       }
       buffer[pos++] = *cat++;
    }

    if (pos >= bufsize) {
       pos = bufsize - 1; /* FIX [CWE-119]: ensure valid index */
    }

   if (pos < bufsize) { /* FIX [CWE-119]: prevent out-of-bounds access */
      buffer[pos] = 0;
   }
 return pos;
}