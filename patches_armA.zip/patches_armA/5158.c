/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5158  |  Dataset: bigvul
   Function:     _out_result
   Dominant CWE: CWE-416
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6123
   ============================================================ */

/*
 * Changes made:
 * - Set pointer to NULL after free() in multiple locations to prevent use-after-free vulnerabilities (CWE-416)
 */

static void _out_result(conn_t out, nad_t nad) {
    int attr;
    jid_t from, to;
    char *rkey;
    int rkeylen;

    attr = nad_find_attr(nad, 0, -1, "from", NULL);
    if(attr < 0 || (from = jid_new(NAD_AVAL(nad, attr), NAD_AVAL_L(nad, attr))) == NULL) {
        log_debug(ZONE, "missing or invalid from on db result packet");
        nad_free(nad);
        return;
    }

    attr = nad_find_attr(nad, 0, -1, "to", NULL);
    if(attr < 0 || (to = jid_new(NAD_AVAL(nad, attr), NAD_AVAL_L(nad, attr))) == NULL) {
        log_debug(ZONE, "missing or invalid to on db result packet");
        jid_free(from);
        nad_free(nad);
        return;
    }

    rkey = s2s_route_key(NULL, to->domain, from->domain);
     rkeylen = strlen(rkey);
 
     /* key is valid */
    if(nad_find_attr(nad, 0, -1, "type", "valid") >= 0) {
         log_write(out->s2s->log, LOG_NOTICE, "[%d] [%s, port=%d] outgoing route '%s' is now valid%s%s", out->fd->fd, out->ip, out->port, rkey, (out->s->flags & SX_SSL_WRAPPER) ? ", TLS negotiated" : "", out->s->compressed ? ", ZLIB compression enabled" : "");
 
         xhash_put(out->states, pstrdup(xhash_pool(out->states), rkey), (void *) conn_VALID);    /* !!! small leak here */

        log_debug(ZONE, "%s valid, flushing queue", rkey);

        /* flush the queue */
        out_flush_route_queue(out->s2s, rkey, rkeylen);

        free(rkey); /* FIX [CWE-416]: Set pointer to NULL after free() */
        rkey = NULL; /* FIX [CWE-416]: Prevent use-after-free */

        jid_free(from);
        from = NULL; /* FIX [CWE-416]: Prevent use-after-free */
        jid_free(to);
        to = NULL; /* FIX [CWE-416]: Prevent use-after-free */

        nad_free(nad);

        return;
    }

    /* invalid */
    log_write(out->s2s->log, LOG_NOTICE, "[%d] [%s, port=%d] outgoing route '%s' is now invalid", out->fd->fd, out->ip, out->port, rkey);

    /* close connection */
    log_write(out->s2s->log, LOG_NOTICE, "[%d] [%s, port=%d] closing connection", out->fd->fd, out->ip, out->port);

    /* report stream error */
    sx_error(out->s, stream_err_INVALID_ID, "dialback negotiation failed");

    /* close the stream */
    sx_close(out->s);

    /* bounce queue */
    out_bounce_route_queue(out->s2s, rkey, rkeylen, stanza_err_SERVICE_UNAVAILABLE);

    free(rkey); /* FIX [CWE-416]: Set pointer to NULL after free() */
    rkey = NULL; /* FIX [CWE-416]: Prevent use-after-free */

    jid_free(from);
    from = NULL; /* FIX [CWE-416]: Prevent use-after-free */
    jid_free(to);
    to = NULL; /* FIX [CWE-416]: Prevent use-after-free */

    nad_free(nad);
}