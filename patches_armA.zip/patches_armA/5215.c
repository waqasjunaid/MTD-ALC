/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5215  |  Dataset: bigvul
   Function:     unknown_5215
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for transaction_ to prevent potential null pointer dereference.
 */

void IndexedDBCursor::RemoveCursorFromTransaction() {
  if (transaction_) { /* FIX [CWE-476]: Prevent null pointer dereference */
    if (transaction_->UnregisterOpenCursor != nullptr) { /* FIX [CWE-476]: Check for valid function pointer */
      transaction_->UnregisterOpenCursor(this);
    }
  }
}