/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5355  |  Dataset: bigvul
   Function:     compile_tree
   Dominant CWE: CWE-120
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6709
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds checking for memcpy operation
 */

size_t compile_tree(struct filter_op **fop)
{
   int i = 1;
    struct filter_op *array = NULL;
    struct unfold_elm *ue;
 
   BUG_IF(tree_root == NULL);
   
    fprintf(stdout, " Unfolding the meta-tree ");
    fflush(stdout);
     
   /* start the recursion on the tree */
   unfold_blk(&tree_root);

   fprintf(stdout, " done.\n\n");

   /* substitute the virtual labels with real offsets */
   labels_to_offsets();
   
   /* convert the tailq into an array */
   TAILQ_FOREACH(ue, &unfolded_tree, next) {

      /* label == 0 means a real instruction */
      if (ue->label == 0) {
         SAFE_REALLOC(array, i * sizeof(struct filter_op));
         /* FIX [CWE-120]: Ensure memcpy does not overflow destination buffer */
         size_t copy_size = sizeof(struct filter_op);
         if (copy_size > sizeof(array[i - 1])) {
            copy_size = sizeof(array[i - 1]);
         }
         memcpy(&array[i - 1], &ue->fop, copy_size); /* FIX [CWE-120]: Use bounded memcpy */
         i++;
      }
   }
   
   /* always append the exit function to a script */
   SAFE_REALLOC(array, i * sizeof(struct filter_op));
   array[i - 1].opcode = FOP_EXIT;
   
   /* return the pointer to the array */
   *fop = array;
   
   return (i);
}