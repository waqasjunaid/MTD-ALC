/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5478  |  Dataset: bigvul
   Function:     ProcessControlLaunched
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6012
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added explicit bounds check for service_pid
 */

void ProcessControlLaunched() {
    base::ScopedAllowBlockingForTesting allow_blocking;
    base::ProcessId service_pid;
    EXPECT_TRUE(GetServiceProcessData(NULL, &service_pid));
    EXPECT_NE(static_cast<base::ProcessId>(0), service_pid);
    if (service_pid > 0) { /* FIX [CWE-119]: bounds check for service_pid */
#if defined(OS_WIN)
        service_process_ =
            base::Process::OpenWithAccess(service_pid,
                                          SYNCHRONIZE | PROCESS_QUERY_INFORMATION);
#else
        service_process_ = base::Process::Open(service_pid);
#endif
    } else {
        // Handle invalid service_pid, e.g., log error or throw exception
    }
    EXPECT_TRUE(service_process_.IsValid());
    base::ThreadTaskRunnerHandle::Get()->PostTask(
        FROM_HERE, base::RunLoop::QuitCurrentWhenIdleClosureDeprecated());
}