/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5538  |  Dataset: bigvul
   Function:     unknown_5538
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5989
   ============================================================ */

/*
 * CHANGES:
 * - Added explicit null check for cue->track()
 */

void TextTrack::addCue(TextTrackCue* cue) {
  DCHECK(cue);

  if (std::isnan(cue->startTime()) || std::isnan(cue->endTime()) ||
      cue->startTime() < 0 || cue->endTime() < 0)
    return;

  if (TextTrack* cue_track = cue->track()) { /* FIX [CWE-476]: potential null pointer dereference */
    if (cue_track != nullptr) { /* FIX [CWE-476]: explicit null check */
      cue_track->removeCue(cue, ASSERT_NO_EXCEPTION);
    }
  }

  cue->SetTrack(this);
  EnsureTextTrackCueList()->Add(cue);

  if (GetCueTimeline() && mode_ != DisabledKeyword())
    GetCueTimeline()->AddCue(this, cue);
}