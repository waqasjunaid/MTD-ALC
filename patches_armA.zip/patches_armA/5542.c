/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5542  |  Dataset: bigvul
   Function:     iwch_l2t_send
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6933
   ============================================================ */

/*
 * Changes made:
 *   - Added bounds check for tdev and skb pointers
 */

static int iwch_l2t_send(struct t3cdev *tdev, struct sk_buff *skb, struct l2t_entry *l2e)
{
	int	error = 0;
	struct cxio_rdev *rdev;

	if (!tdev || !skb) { /* FIX [CWE-119]: null pointer dereference */
		return -EINVAL; /* FIX [CWE-252]: invalid return value */
	}

	rdev = (struct cxio_rdev *)tdev->ulp;
	if (cxio_fatal_error(rdev)) {
		kfree_skb(skb);
		return -EIO;
	}
 	error = l2t_send(tdev, skb, l2e);
 	if (error < 0)
 		kfree_skb(skb);
	return error;
 }