/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       562  |  Dataset: bigvul
   Function:     user_update
   Dominant CWE: CWE-120
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6532
   ============================================================ */

/* 
 * Changes made to fix CWE-120:
 * - Replaced memcpy with memmove to prevent overlapping memory operations
 */

int user_update(struct key *key, struct key_preparsed_payload *prep)
{
	struct user_key_payload *upayload, *zap;
	size_t datalen = prep->datalen;
	int ret;

	ret = -EINVAL;
	if (datalen <= 0 || datalen > 32767 || !prep->data)
		goto error;

	/* construct a replacement payload */
	ret = -ENOMEM;
	upayload = kmalloc(sizeof(*upayload) + datalen, GFP_KERNEL);
	if (!upayload)
		goto error;

	upayload->datalen = datalen;
	memmove(upayload->data, prep->data, datalen); /* FIX [CWE-120]: prevent overlapping memory operations */

	/* check the quota and attach the new data */
	zap = upayload;

	ret = key_payload_reserve(key, datalen);
 
 	if (ret == 0) {
 		/* attach the new data, displacing the old */
		zap = key->payload.data[0];
 		rcu_assign_keypointer(key, upayload);
 		key->expiry = 0;
 	}

	if (zap)
		kfree_rcu(zap, rcu);

error:
	return ret;
}