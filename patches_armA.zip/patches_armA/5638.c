/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5638  |  Dataset: bigvul
   Function:     unknown_5638
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added explicit null check for parent and directory_service
 */

GDataEntry* GDataEntry::FromDocumentEntry(
    GDataDirectory* parent,
    DocumentEntry* doc,
    GDataDirectoryService* directory_service) {
  DCHECK(doc);
  if (!parent || !directory_service) /* FIX [CWE-476]: Potential null pointer dereference */
    return NULL;
  if (doc->is_folder())
    return GDataDirectory::FromDocumentEntry(parent, doc, directory_service);
  else if (doc->is_hosted_document() || doc->is_file())
    return GDataFile::FromDocumentEntry(parent, doc, directory_service);
  return NULL;
}