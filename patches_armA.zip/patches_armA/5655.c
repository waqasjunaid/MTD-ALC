/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5655  |  Dataset: bigvul
   Function:     unknown_5655
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6095
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds check for exec->argument(0) before calling isFunction()
 */

EncodedJSValue JSC_HOST_CALL JSTestObjConstructor::constructJSTestObj(ExecState* exec)
{
    JSTestObjConstructor* castedThis = jsCast<JSTestObjConstructor*>(exec->callee());
    if (exec->argumentCount() < 1)
        return throwVMError(exec, createTypeError(exec, "Not enough arguments"));
    if (exec->argumentCount() <= 0 || !exec->argument(0) /* FIX [CWE-119]: Ensure argument exists before calling isFunction() */) {
        setDOMException(exec, TYPE_MISMATCH_ERR);
        return JSValue::encode(jsUndefined());
    }
    if (!exec->argument(0).isFunction()) { /* FIX [CWE-119]: Validate argument type */
        setDOMException(exec, TYPE_MISMATCH_ERR);
        return JSValue::encode(jsUndefined());
    }
    RefPtr<TestCallback> testCallback = JSTestCallback::create(asObject(exec->argument(0)), castedThis->globalObject());
    RefPtr<TestObj> object = TestObj::create(testCallback);
    return JSValue::encode(asObject(toJS(exec, castedThis->globalObject(), object.get())));
}