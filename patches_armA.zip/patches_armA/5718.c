/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5718  |  Dataset: bigvul
   Function:     unknown_5718
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6101
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for getNode() before calling isHTMLDialogElement()
 */

bool AXNodeObject::isModal() const {
  if (roleValue() != DialogRole && roleValue() != AlertDialogRole)
    return false;
 
   if (hasAttribute(aria_modalAttr)) {
     const AtomicString& modal = getAttribute(aria_modalAttr);
    if (equalIgnoringCase(modal, "true"))
       return true; /* FIX [CWE-20]: Validate input */
    if (equalIgnoringCase(modal, "false"))
       return false; /* FIX [CWE-20]: Validate input */
   }
 
  if (getNode() && getNode()->isHTMLElement()) { /* FIX [CWE-119]: Bounds check */
    if (isHTMLDialogElement(*getNode()))
      return toElement(getNode())->isInTopLayer();
  }

  return false;
}