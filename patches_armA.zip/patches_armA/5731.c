/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5731  |  Dataset: bigvul
   Function:     unknown_5731
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6096
   ============================================================ */

/*
 * CHANGES:
 * - Added input validation for GURL object
 */

base::string16 GetApplicationNameForProtocol(const GURL& url) {
  if (url.is_empty()) { /* FIX [CWE-20]: Validate all inputs */
    return base::string16(); // or throw an exception, depending on the desired behavior
  }

  base::string16 application_name;
  if (base::win::GetVersion() >= base::win::VERSION_WIN8) {
    application_name = GetAppForProtocolUsingAssocQuery(url);
    if (!application_name.empty())
      return application_name;
  }

  return GetAppForProtocolUsingRegistry(url);
}