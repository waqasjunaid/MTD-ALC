/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5859  |  Dataset: bigvul
   Function:     oz_usb_handle_ep_data
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6948
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for len to prevent integer overflow
 * - Added null pointer checks for usb_ctx and usb_hdr
 */

static void oz_usb_handle_ep_data(struct oz_usb_ctx *usb_ctx,
	struct oz_usb_hdr *usb_hdr, int len)
{
	if (!usb_ctx || !usb_hdr) {
		return; /* FIX [CWE-476]: Null pointer dereference */
	}

	if (len < 0 || len > INT_MAX - sizeof(struct oz_multiple_fixed)) {
		return; /* FIX [CWE-190]: Integer overflow */
	}

	struct oz_data *data_hdr = (struct oz_data *)usb_hdr;

	switch (data_hdr->format) {
	case OZ_DATA_F_MULTIPLE_FIXED: {
 			struct oz_multiple_fixed *body =
 				(struct oz_multiple_fixed *)data_hdr;
 			u8 *data = body->data;
			int n = (len - sizeof(struct oz_multiple_fixed)+1)
 				/ body->unit_size;
 			if (n < 0) { /* FIX [CWE-190]: Integer overflow */
 				return;
 			}
 			while (n--) {
 				oz_hcd_data_ind(usb_ctx->hport, body->endpoint,
					data, body->unit_size);
				data += body->unit_size;
			}
		}
		break;
	case OZ_DATA_F_ISOC_FIXED: {
			struct oz_isoc_fixed *body =
				(struct oz_isoc_fixed *)data_hdr;
			int data_len = len-sizeof(struct oz_isoc_fixed)+1;
			if (data_len < 0) { /* FIX [CWE-190]: Integer overflow */
				break;
			}
			int unit_size = body->unit_size;
			u8 *data = body->data;
			int count;
			int i;

			if (!unit_size)
				break;
			count = data_len/unit_size;
			for (i = 0; i < count; i++) {
				oz_hcd_data_ind(usb_ctx->hport,
					body->endpoint, data, unit_size);
				data += unit_size;
			}
		}
		break;
	}

}