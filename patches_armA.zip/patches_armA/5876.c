/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       5876  |  Dataset: bigvul
   Function:     unknown_5876
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6098
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds check for originMap() to prevent potential null pointer dereference
 */

void ThreadableBlobRegistry::registerBlobURL(SecurityOrigin* origin, const KURL& url, const KURL& srcURL)
 {
     if (origin && BlobURL::getOrigin(url) == "null" && originMap()) /* FIX [CWE-476]: Added bounds check for originMap() */
         originMap()->add(url.string(), origin);
 
    if (isMainThread())
        blobRegistry().registerBlobURL(url, srcURL);
    else {
         OwnPtr<BlobRegistryContext> context = adoptPtr(new BlobRegistryContext(url, srcURL));
         callOnMainThread(&registerBlobURLFromTask, context.leakPtr());
     }
}