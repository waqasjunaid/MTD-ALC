/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6039  |  Dataset: bigvul
   Function:     set_socket_blocking
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * Changes made:
 * - Added error handling for fcntl() return values
 * - Added bounds check for opts value
 */

static inline void set_socket_blocking(int s, int blocking)
{
    int opts;
    if ((opts = fcntl(s, F_GETFL)) < 0) { /* FIX [CWE-252]: Check return value of fcntl */
        APPL_TRACE_ERROR("set blocking (%s)", strerror(errno));
        return; /* FIX [CWE-252]: Handle error and exit function */
    }
    if (opts & O_NONBLOCK && !blocking) { /* FIX [CWE-252]: Validate opts value before modification */
        opts &= ~O_NONBLOCK;
    } else if (!(opts & O_NONBLOCK) && blocking) {
        opts |= O_NONBLOCK; /* FIX [CWE-252]: Validate opts value before modification */
    }
    if (fcntl(s, F_SETFL, opts) < 0) { /* FIX [CWE-252]: Check return value of fcntl */
        APPL_TRACE_ERROR("set blocking (%s)", strerror(errno));
    }
}