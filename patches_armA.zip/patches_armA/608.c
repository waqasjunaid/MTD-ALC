/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       608  |  Dataset: bigvul
   Function:     unknown_608
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5799
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index 'i' in the loop
 */

int BN_hex2bn(BIGNUM **bn, const char *a)
{
    BIGNUM *ret = NULL;
    BN_ULONG l = 0;
    int neg = 0, h, m, i, j, k, c;
    int num;

    if ((a == NULL) || (*a == '\0'))
        return (0);

    if (*a == '-') {
        neg = 1;
        a++;
         a++;
     }
 
    for (i = 0; (size_t)i < strlen(a) && isxdigit((unsigned char)a[i]); i++) ; /* FIX [CWE-129]: bounds checking */
 
     num = i + neg;
     if (bn == NULL)
            return (0);
    } else {
        ret = *bn;
        BN_zero(ret);
    }
}