/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6104  |  Dataset: bigvul
   Function:     unknown_6104
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made to fix potential vulnerabilities:
 * - Added bounds check for duration value
 */

bool GesturePoint::IsInSecondClickTimeWindow() const {
   double duration =  last_touch_time_ - last_tap_time_;
   if (duration < 0) { /* FIX [CWE-703]: Ensure non-negative duration */ 
     return false;
   }
  return duration <= kMaximumSecondsBetweenDoubleClick; /* FIX [CWE-703]: Use less-than-or-equal for bounds check */
 }