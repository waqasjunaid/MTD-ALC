/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6163  |  Dataset: bigvul
   Function:     toggle_fpga_eeprom_bus
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6840
   ============================================================ */

/*
 * CHANGES MADE:
 * - Added input validation for the 'cpu_own' parameter.
 */

static void toggle_fpga_eeprom_bus(bool cpu_own)
{
    /* FIX [CWE-20]: Validate input to prevent potential misuse */
    if (cpu_own != 0 && cpu_own != 1) {
        return; /* or handle error, e.g., log and exit */
    }
	qrio_gpio_direction_output(GPIO_A, PROM_SEL_L, !cpu_own);
 }