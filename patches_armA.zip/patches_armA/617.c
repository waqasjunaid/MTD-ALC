/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       617  |  Dataset: bigvul
   Function:     EnableHighDPISupport
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6680
   ============================================================ */

/* 
 * Changes made:
 * - Added explicit bounds check around pointer operation in SetProcessDpiAwarenessWrapper
 */

void EnableHighDPISupport() {
  if (IsHighDPIEnabled() &&
     (base::win::GetVersion() < base::win::VERSION_WIN8_1)) {
    PROCESS_DPI_AWARENESS awareness = PROCESS_SYSTEM_DPI_AWARE;
    /* FIX [CWE-119]: Validate input to prevent potential buffer overflow */
    if (!SetProcessDpiAwarenessWrapper(awareness)) {
      SetProcessDPIAwareWrapper();
    }
  }
}