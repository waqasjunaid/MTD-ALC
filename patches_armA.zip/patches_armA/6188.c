/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6188  |  Dataset: bigvul
   Function:     vapic_exit
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds checks around pointer operations
 */

static void vapic_exit(struct kvm_vcpu *vcpu)
{
	struct kvm_lapic *apic = vcpu->arch.apic;
	int idx;

	/* FIX [CWE-119]: Validate apic pointer before dereferencing */
	if (!apic || !apic->vapic_addr) {
		WARN_ON_ONCE(!apic);
		return;
	}

	idx = srcu_read_lock(&vcpu->kvm->srcu);

	/* FIX [CWE-119]: Check vapic_page and vapic_addr for NULL before dereferencing */
	if (apic->vapic_page && apic->vapic_addr) {
		kvm_release_page_dirty(apic->vapic_page);
		mark_page_dirty(vcpu->kvm, apic->vapic_addr >> PAGE_SHIFT);
	}

	srcu_read_unlock(&vcpu->kvm->srcu, idx);
}