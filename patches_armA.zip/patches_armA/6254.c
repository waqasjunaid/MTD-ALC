/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6254  |  Dataset: bigvul
   Function:     crypto_report_cipher
   Dominant CWE: CWE-120
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5886
   ============================================================ */

/*
 * Changes made to fix CWE-120 (Buffer Copy without Checking Size of Input ('Classic Buffer Overflow')):
 *   - Replaced snprintf() with a safer alternative that checks for truncation.
 */

static int crypto_report_cipher(struct sk_buff *skb, struct crypto_alg *alg)
{
	struct crypto_report_cipher rcipher;

	/* FIX [CWE-120]: Use strlcpy to prevent buffer overflow */
	strlcpy(rcipher.type, "cipher", CRYPTO_MAX_ALG_NAME);

	rcipher.blocksize = alg->cra_blocksize;
	rcipher.min_keysize = alg->cra_cipher.cia_min_keysize;
	rcipher.max_keysize = alg->cra_cipher.cia_max_keysize;

	if (nla_put(skb, CRYPTOCFGA_REPORT_CIPHER,
		    sizeof(struct crypto_report_cipher), &rcipher))
		goto nla_put_failure;
	return 0;

nla_put_failure:
	return -EMSGSIZE;
}