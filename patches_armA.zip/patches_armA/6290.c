/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6290  |  Dataset: bigvul
   Function:     unknown_6290
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for state_stack_ to prevent potential buffer overflow
 */

BaseRenderingContext2D::BaseRenderingContext2D()
    : clip_antialiasing_(kNotAntiAliased) {
   if (state_stack_.size() < state_stack_.max_size()) { /* FIX [CWE-119]: Prevent buffer overflow */
      state_stack_.push_back(CanvasRenderingContext2DState::Create());
   } else {
      // Handle error: stack is full
   }
}