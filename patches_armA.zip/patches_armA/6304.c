/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6304  |  Dataset: bigvul
   Function:     unknown_6304
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5965
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for m_errorCallback before calling handleEvent to prevent potential null pointer dereference.
 */

void RTCSessionDescriptionRequestImpl::requestFailed(const String& error)
{
    if (m_errorCallback != nullptr) /* FIX [CWE-476]: Prevent null pointer dereference */
        m_errorCallback->handleEvent(error);
 
    clear();
}