/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6399  |  Dataset: bigvul
   Function:     hashtable_set
   Dominant CWE: CWE-120
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5984
   ============================================================ */

/* 
 * Changes made:
 * - Replaced strcpy with strlcpy to prevent buffer overflow (CWE-120)
 */

int hashtable_set(hashtable_t *hashtable,
                  const char *key, size_t serial,
                  json_t *value)
{
    pair_t *pair;
    bucket_t *bucket;
     size_t hash, index;
 
     /* rehash if the load ratio exceeds 1 */
    if(hashtable->size >= num_buckets(hashtable))
         if(hashtable_do_rehash(hashtable))
             return -1;
 
     hash = hash_str(key);
    index = hash % num_buckets(hashtable);
     bucket = &hashtable->buckets[index];
     pair = hashtable_find_pair(hashtable, bucket, key, hash);
 
    if(pair)
    {
        json_decref(pair->value);
        pair->value = value;
    }
    else
    {
        /* offsetof(...) returns the size of pair_t without the last,
           flexible member. This way, the correct amount is
           allocated. */
        pair = jsonp_malloc(offsetof(pair_t, key) + strlen(key) + 1);
        if(!pair)
            return -1;

        pair->hash = hash;
        pair->serial = serial;
        strlcpy(pair->key, key, offsetof(pair_t, key) + strlen(key) + 1); /* FIX [CWE-120]: prevent buffer overflow */
        pair->value = value;
        list_init(&pair->list);

        insert_to_bucket(hashtable, bucket, &pair->list);

        hashtable->size++;
    }
    return 0;
}