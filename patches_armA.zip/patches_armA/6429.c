/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6429  |  Dataset: bigvul
   Function:     gdImageCopyMerge
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0360
   ALC decision: UNTRUSTWORTHY  T=0.6301
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checks for srcX, srcY, dstX, and dstY to prevent out-of-bounds access.
 */

void gdImageCopyMerge (gdImagePtr dst, gdImagePtr src, int dstX, int dstY, int srcX, int srcY, int w, int h, int pct)
{
	int c, dc;
	int x, y;
 	int tox, toy;
 	int ncR, ncG, ncB;

	/* FIX [CWE-119]: Check bounds for srcX and srcY */
	if (srcX < 0 || srcY < 0 || srcX + w > src->sx || srcY + h > src->sy) {
		return;
	}

	toy = dstY;
	for (y = srcY; y < (srcY + h); y++) {
 		tox = dstX;

		/* FIX [CWE-119]: Check bounds for dstX and dstY */
		if (dstX < 0 || dstY < 0 || dstX + w > dst->sx || dstY + h > dst->sy) {
			return;
		}

 		for (x = srcX; x < (srcX + w); x++) {
			int nc;
			c = gdImageGetPixel(src, x, y);
			/* Added 7/24/95: support transparent copies */
			if (gdImageGetTransparent(src) == c) {
				tox++;
				continue;
			}
			/* If it's the same image, mapping is trivial */
			if (dst == src) {
				nc = c;
			} else {
				dc = gdImageGetPixel(dst, tox, toy);

 				ncR = (int)(gdImageRed (src, c) * (pct / 100.0) + gdImageRed (dst, dc) * ((100 - pct) / 100.0));
 				ncG = (int)(gdImageGreen (src, c) * (pct / 100.0) + gdImageGreen (dst, dc) * ((100 - pct) / 100.0));
 				ncB = (int)(gdImageBlue (src, c) * (pct / 100.0) + gdImageBlue (dst, dc) * ((100 - pct) / 100.0));

				/* Find a reasonable color */
				nc = gdImageColorResolve (dst, ncR, ncG, ncB);
			}
			gdImageSetPixel (dst, tox, toy, nc);
			tox++;
		}
		toy++;
	}
}