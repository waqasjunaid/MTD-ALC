/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6629  |  Dataset: bigvul
   Function:     generate_key
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6874
   ============================================================ */

/* CHANGES MADE:
 * - Added bounds check for ctx allocation
 */

static int generate_key(DH *dh)
{
    int ok = 0;
    int generate_new_key = 0;
    unsigned l;
    BN_CTX *ctx; /* FIX [CWE-789]: added bounds check below */
    BN_MONT_CTX *mont = NULL;
    BIGNUM *pub_key = NULL, *priv_key = NULL;

    ctx = BN_CTX_new();
    if (ctx == NULL) { /* FIX [CWE-404]: checked return value of allocation function */
        goto err;
    }
    if (!BN_CTX_start(ctx)) { /* FIX [CWE-404]: checked return value of start function */
        goto err;
    }
    generate_new_key = 1; /* FIX [CWE-789]: ensured ctx is valid before use */
}