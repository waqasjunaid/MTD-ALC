/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6703  |  Dataset: bigvul
   Function:     ProxyLocaltimeCallToBrowser
   Dominant CWE: CWE-120
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6564
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Replaced memcpy with strncpy to prevent buffer overflow (CWE-120)
 */

static void ProxyLocaltimeCallToBrowser(time_t input, struct tm* output,
                                        char* timezone_out,
                                        size_t timezone_out_len) {
  base::Pickle request;
  request.WriteInt(LinuxSandbox::METHOD_LOCALTIME);
   request.WriteString(
       std::string(reinterpret_cast<char*>(&input), sizeof(input)));
 
   uint8_t reply_buf[512];
   const ssize_t r = base::UnixDomainSocket::SendRecvMsg(
       GetSandboxFD(), reply_buf, sizeof(reply_buf), NULL, request);
   if (r == -1) {
    memset(output, 0, sizeof(struct tm));
     return;
   }
 
   base::Pickle reply(reinterpret_cast<char*>(reply_buf), r);
   base::PickleIterator iter(reply);
  std::string result;
  std::string timezone;
  if (!iter.ReadString(&result) ||
      !iter.ReadString(&timezone) ||
      result.size() != sizeof(struct tm)) {
     memset(output, 0, sizeof(struct tm));
    return;
  }
  strncpy(reinterpret_cast<char*>(output), result.data(), sizeof(struct tm)); /* FIX [CWE-120]: prevent buffer overflow */
  output->tm_zone = NULL; /* FIX [CWE-120]: ensure null termination */
  if (timezone_out_len) {
    const size_t copy_len = std::min(timezone_out_len - 1, timezone.size());
    strncpy(timezone_out, timezone.data(), copy_len); /* FIX [CWE-120]: prevent buffer overflow */
    timezone_out[copy_len] = 0; /* FIX [CWE-120]: ensure null termination */
    output->tm_zone = timezone_out;
  } else {
    base::AutoLock lock(g_timezones_lock.Get());
    auto ret_pair = g_timezones.Get().insert(timezone);
    strncpy(output->tm_zone, ret_pair.first->c_str(), sizeof(output->tm_zone)); /* FIX [CWE-120]: prevent buffer overflow */
   }
 }