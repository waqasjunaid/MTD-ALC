/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6766  |  Dataset: bigvul
   Function:     unknown_6766
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6113
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for desc_ptr.address to prevent potential buffer overflow
 */

static int emulate_store_desc_ptr(struct x86_emulate_ctxt *ctxt,
				  void (*get)(struct x86_emulate_ctxt *ctxt,
					      struct desc_ptr *ptr))
{
	struct desc_ptr desc_ptr;

	if (ctxt->mode == X86EMUL_MODE_PROT64)
		ctxt->op_bytes = 8;
	get(ctxt, &desc_ptr);
	if (ctxt->op_bytes == 2) {
		ctxt->op_bytes = 4;
		desc_ptr.address &= 0x00ffffff;
 	}
 	/* Disable writeback. */
 	ctxt->dst.type = OP_NONE;
	/* FIX [CWE-119]: Ensure address is within valid bounds */
	if (desc_ptr.address > UINT32_MAX - ctxt->op_bytes) {
		return -EINVAL; /* or some other error code */
	}
	return segmented_write(ctxt, ctxt->dst.addr.mem,
			       &desc_ptr, 2 + ctxt->op_bytes);
 }