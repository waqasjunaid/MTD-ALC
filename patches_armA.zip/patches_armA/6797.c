/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6797  |  Dataset: bigvul
   Function:     UpdatePropertyCallback
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6680
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added a null check for ibus_prop to prevent potential crashes.
 */

static void UpdatePropertyCallback(IBusPanelService* panel,
                                     IBusProperty* ibus_prop, /* FIX [CWE-690]: added null check below */
                                     gpointer user_data) {
    g_return_if_fail(user_data);
    InputMethodStatusConnection* self
        = static_cast<InputMethodStatusConnection*>(user_data);
    if (ibus_prop != NULL) { /* FIX [CWE-690]: prevent potential crashes */
        self->UpdateProperty(ibus_prop); /* FIX [CWE-690]: validated input */
    }
}