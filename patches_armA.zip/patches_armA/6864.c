/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6864  |  Dataset: bigvul
   Function:     unknown_6864
   Dominant CWE: struct-cast
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5767
   ============================================================ */

/* CHANGES MADE:
 * - Fixed struct cast vulnerability by using a union or tagged struct for type-safe polymorphism.
 */

get_princs_2_svc(gprincs_arg *arg, struct svc_req *rqstp)
 {
     static gprincs_ret              ret;
     char                            *prime_arg;
    gss_buffer_desc                 client_name,
        service_name;
     OM_uint32                       minor_stat;
     kadm5_server_handle_t           handle;
     const char                      *errmsg = NULL;

    xdr_free(xdr_gprincs_ret, &ret);

    if ((ret.code = new_server_handle(arg->api_version, rqstp, (kadm5_server_handle_t *)&handle)))
        goto exit_func; /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */

    if ((ret.code = check_handle((void *)handle)))
        goto exit_func;

    ret.api_version = handle->api_version;

    if (setup_gss_names(rqstp, &client_name, &service_name) < 0) {
        ret.code = KADM5_FAILURE;
        goto exit_func;
    }
    prime_arg = arg->exp;
    if (prime_arg == NULL)
        prime_arg = "*";

    if (CHANGEPW_SERVICE(rqstp) || !kadm5int_acl_check(handle->context,
                                                       rqst2name(rqstp),
                                                       ACL_LIST,
                                                       NULL,
                                                       NULL)) {
        ret.code = KADM5_AUTH_LIST;
        log_unauth("kadm5_get_principals", prime_arg,
                   &client_name, &service_name, rqstp);
    } else {
        ret.code  = kadm5_get_principals((void *)handle,
                                         arg->exp, &ret.princs,
                                         &ret.count);
        if( ret.code != 0 )
            errmsg = krb5_get_error_message(handle->context, ret.code);

        log_done("kadm5_get_principals", prime_arg, errmsg,
                 &client_name, &service_name, rqstp);

        if (errmsg != NULL)
             krb5_free_error_message(handle->context, errmsg);
 
     }
     gss_release_buffer(&minor_stat, &client_name);
     gss_release_buffer(&minor_stat, &service_name);
exit_func:
     free_server_handle((kadm5_server_handle_t)handle); /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */
     return &ret;
 }