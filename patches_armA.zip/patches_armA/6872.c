/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6872  |  Dataset: bigvul
   Function:     IsTraceEventArgsWhitelisted
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6919
   ============================================================ */

/*
 * Changes made:
 * - Added null checks for category_group_name and event_name to prevent potential null pointer dereferences.
 */

bool IsTraceEventArgsWhitelisted(const char* category_group_name,
                                 const char* event_name) {
  if (category_group_name != NULL && /* FIX [CWE-476]: Prevent null pointer dereference */
      event_name != NULL && /* FIX [CWE-476]: Prevent null pointer dereference */
      base::MatchPattern(category_group_name, "toplevel") &&
      base::MatchPattern(event_name, "*")) {
    return true;
  }
 
  return false;
}