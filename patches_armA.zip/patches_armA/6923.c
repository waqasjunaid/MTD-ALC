/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       6923  |  Dataset: bigvul
   Function:     svc_rdma_send_error
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6046
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array indices in ctxt->pages and ctxt->sge
 */

void svc_rdma_send_error(struct svcxprt_rdma *xprt, struct rpcrdma_msg *rmsgp,
			 int status)
{
	struct ib_send_wr err_wr;
	struct page *p;
	struct svc_rdma_op_ctxt *ctxt;
	enum rpcrdma_errcode err;
	__be32 *va;
	int length;
	int ret;
	ret = svc_rdma_repost_recv(xprt, GFP_KERNEL);
	if (ret)
		return;
	p = alloc_page(GFP_KERNEL);
	if (!p)
		return;
	va = page_address(p);
	/* XDR encode an error reply */
	err = ERR_CHUNK;
	if (status == -EPROTONOSUPPORT)
		err = ERR_VERS;
	length = svc_rdma_xdr_encode_error(xprt, rmsgp, err, va);
	ctxt = svc_rdma_get_context(xprt);
	ctxt->direction = DMA_TO_DEVICE;
	ctxt->count = 1;
	if (ctxt->count >= 0 && (size_t)ctxt->count < ARRAY_SIZE(ctxt->pages)) {
		ctxt->pages[ctxt->count - 1] = p; /* FIX [CWE-129]: bounds checking */
	}
	/* Prepare SGE for local address */
	if (ctxt->count >= 0 && (size_t)ctxt->count < ARRAY_SIZE(ctxt->sge)) {
		ctxt->sge[ctxt->count - 1].lkey = xprt->sc_pd->local_dma_lkey; /* FIX [CWE-129]: bounds checking */
		ctxt->sge[ctxt->count - 1].length = length; /* FIX [CWE-129]: bounds checking */
		ctxt->sge[ctxt->count - 1].addr = ib_dma_map_page(xprt->sc_cm_id->device,
								p, 0, length, DMA_TO_DEVICE); /* FIX [CWE-129]: bounds checking */
	}
	if (ib_dma_mapping_error(xprt->sc_cm_id->device, ctxt->sge[ctxt->count - 1].addr)) {
		dprintk("svcrdma: Error mapping buffer for protocol error\n");
		svc_rdma_put_context(ctxt, 1);
		return;
	}
	svc_rdma_count_mappings(xprt, ctxt);
	/* Prepare SEND WR */
	memset(&err_wr, 0, sizeof(err_wr));
	ctxt->cqe.done = svc_rdma_wc_send;
	err_wr.wr_cqe = &ctxt->cqe;
	err_wr.sg_list = ctxt->sge;
	err_wr.num_sge = 1;
	err_wr.opcode = IB_WR_SEND;
	err_wr.send_flags = IB_SEND_SIGNALED;
	/* Post It */
	ret = svc_rdma_send(xprt, &err_wr);
	if (ret) {
		dprintk("svcrdma: Error %d posting send for protocol error\n",
			ret);
		svc_rdma_unmap_dma(ctxt);
		svc_rdma_put_context(ctxt, 1);
	}
}