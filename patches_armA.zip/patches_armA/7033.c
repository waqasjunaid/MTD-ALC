/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7033  |  Dataset: bigvul
   Function:     unknown_7033
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6001
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for npobject before assigning it to window_script_object_
 */

void WebPluginDelegateProxy::OnGetWindowScriptNPObject(
    int route_id, bool* success, intptr_t* npobject_ptr) {
   *success = false;
   NPObject* npobject = NULL;
   if (plugin_)
    npobject = plugin_->GetWindowScriptNPObject();

  if (!npobject)
    return;

  // FIX [CWE-119]: Ensure npobject is not null before using it
  if (npobject) {
    window_script_object_ = (new NPObjectStub(
        npobject, channel_host_.get(), route_id, 0, page_url_))->AsWeakPtr();
   *success = true;
  }
  // FIX [CWE-119]: Ensure npobject is not null before assigning it to npobject_ptr
  if (npobject) {
    *npobject_ptr = reinterpret_cast<intptr_t>(npobject);
  } else {
    *npobject_ptr = NULL; /* FIX [CWE-119]: Set npobject_ptr to NULL when npobject is NULL */
  }
}