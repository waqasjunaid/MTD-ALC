/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7062  |  Dataset: bigvul
   Function:     _our_safe_pcap_next_ex
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6941
   ============================================================ */

/*
 * Changes made:
 * - Added explicit bounds checks for pointer operations
 */

int _our_safe_pcap_next_ex(pcap_t *pcap, struct pcap_pkthdr **pkthdr,
        const u_char **pktdata, const char *funcname,
        const int line, const char *file)
{
    int res = pcap_next_ex(pcap, pkthdr, pktdata);

    if (*pktdata && *pkthdr) {
        /* FIX [CWE-119]: Validate packet length bounds */
        if ((*pkthdr)->len > MAXPACKET || (*pkthdr)->len < 0) {
            fprintf(stderr, "safe_pcap_next_ex ERROR: Invalid packet length in %s:%s() line %d: %u is out of bounds\n",
                    file, funcname, line, (*pkthdr)->len);
             exit(-1);
         }
 
        /* FIX [CWE-119]: Validate capture length bounds */
        if ((*pkthdr)->caplen < 0) {
            fprintf(stderr, "safe_pcap_next_ex ERROR: Invalid capture length in %s:%s() line %d: %u is out of bounds\n",
                     file, funcname, line, (*pkthdr)->caplen);
             exit(-1);
         }

        /* FIX [CWE-119]: Validate packet length against capture length */
        if ((*pkthdr)->len < (*pkthdr)->caplen) {
            fprintf(stderr, "safe_pcap_next_ex ERROR: Invalid packet length in %s:%s() line %d: packet length %u is less than capture length %u\n",
                     file, funcname, line, (*pkthdr)->len, (*pkthdr)->caplen);
             exit(-1);
         }
    }

    return res;
}