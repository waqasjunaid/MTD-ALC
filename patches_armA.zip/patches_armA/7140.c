/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7140  |  Dataset: bigvul
   Function:     seedsize
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6900
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for the 'alg' pointer to prevent potential null pointer dereferences.
 */

static unsigned int seedsize(struct crypto_alg *alg)
{
	/* FIX [CWE-690]: Check for null pointer before dereferencing */
	if (alg == NULL) {
		return 0; /* or some other default value, depending on the context */
	}

	struct rng_alg *ralg = container_of(alg, struct rng_alg, base);
 
	return alg->cra_rng.rng_make_random ?
	       alg->cra_rng.seedsize : ralg->seedsize;
}