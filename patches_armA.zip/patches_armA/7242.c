/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7242  |  Dataset: bigvul
   Function:     unknown_7242
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5845
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds checking to prevent out-of-bounds array access.
 */

int PDFiumEngine::GetVisiblePageIndex(FPDF_PAGE page) {
  for (size_t page_index : visible_pages_) { /* FIX [CWE-129]: Ensure index is non-negative */
    if (page_index < sizeof(pages_)/sizeof(pages_[0]) && /* FIX [CWE-129]: Check array bounds before access */
        pages_[page_index]->GetPage() == page)
      return static_cast<int>(page_index); /* FIX [CWE-129]: Cast to int after bounds check */
  }
  return -1;
}