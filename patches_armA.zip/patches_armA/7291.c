/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7291  |  Dataset: bigvul
   Function:     tcp_send_challenge_ack
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6885
   ============================================================ */

/* 
 * Changes made:
 * - Added bounds check for sysctl_tcp_challenge_ack_limit
 */

static void tcp_send_challenge_ack(struct sock *sk, const struct sk_buff *skb)
{
	/* unprotected vars, we dont care of overwrites */
 	static u32 challenge_timestamp;
 	static unsigned int challenge_count;
 	struct tcp_sock *tp = tcp_sk(sk);
	u32 now;
 
 	/* First check our per-socket dupack rate limit. */
 	if (tcp_oow_rate_limited(sock_net(sk), skb,
 				 LINUX_MIB_TCPACKSKIPPEDCHALLENGE,
 				 &tp->last_oow_ack_time))
 		return;
 
	/* Then check the check host-wide RFC 5961 rate limit. */
 	now = jiffies / HZ;
 	if (now != challenge_timestamp) {
 		challenge_timestamp = now;
		challenge_count = 0;
 	}
	if (++challenge_count <= sysctl_tcp_challenge_ack_limit && /* FIX [CWE-190]: added bounds check */ 
	    sysctl_tcp_challenge_ack_limit > 0) { /* FIX [CWE-190]: added bounds check */
 		NET_INC_STATS(sock_net(sk), LINUX_MIB_TCPCHALLENGEACK);
 		tcp_send_ack(sk);
 	}
}