/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       735  |  Dataset: bigvul
   Function:     unknown_735
   Dominant CWE: struct-array
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5767
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for `wallpaper_cache_` array access
 */

void WallpaperManager::OnWallpaperDecoded(
    const AccountId& account_id,
    const wallpaper::WallpaperInfo& info,
    bool update_wallpaper,
    MovableOnDestroyCallbackHolder on_finish,
    std::unique_ptr<user_manager::UserImage> user_image) {
  DCHECK_CURRENTLY_ON(BrowserThread::UI);
  TRACE_EVENT_ASYNC_END0("ui", "LoadAndDecodeWallpaper", this);

  if (user_image->image().isNull()) {
    wallpaper::WallpaperInfo default_info(
         "", wallpaper::WALLPAPER_LAYOUT_CENTER_CROPPED, wallpaper::DEFAULT,
         base::Time::Now().LocalMidnight());
     SetUserWallpaperInfo(account_id, default_info, true);
    if (update_wallpaper)
      DoSetDefaultWallpaper(account_id, std::move(on_finish));
     return;
   }
 
  // FIX [CWE-129]: Validate array index is within bounds before access
  if ((size_t)account_id >= 0 && (size_t)account_id < wallpaper_cache_.size()) {
    wallpaper_cache_[account_id].second = user_image->image();
  }

  if (update_wallpaper)
    SetWallpaper(user_image->image(), info);
}