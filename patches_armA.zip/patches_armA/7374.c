/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7374  |  Dataset: bigvul
   Function:     unknown_7374
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/*
 * CHANGES:
 * - Added explicit bounds check for params.url and url_ to prevent potential NULL pointer dereferences.
 */

void ExtensionViewGuest::DidNavigateMainFrame(
     const content::LoadCommittedDetails& details,
     const content::FrameNavigateParams& params) {
  if (attached() && params.url.is_valid() /* FIX [CWE-119]: Prevent NULL pointer dereference */ 
      && url_.is_valid() /* FIX [CWE-119]: Prevent NULL pointer dereference */ 
      && (params.url.GetOrigin() != url_.GetOrigin())) {
     bad_message::ReceivedBadMessage(web_contents()->GetRenderProcessHost(),
                                     bad_message::EVG_BAD_ORIGIN);
   }
}