/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7415  |  Dataset: bigvul
   Function:     unknown_7415
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5964
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for webPage to prevent potential crashes.
 */

void WebProcessProxy::addExistingWebPage(WebPageProxy* webPage, uint64_t pageID)
{
    if (!webPage) /* FIX [CWE-476]: Prevent null pointer dereference */
        return;
    m_pageMap.set(pageID, webPage);
    globalPageMap().set(pageID, webPage);
#if PLATFORM(MAC)
    if (pageIsProcessSuppressible(webPage))
         m_processSuppressiblePages.add(pageID);
     updateProcessSuppressionState();
#endif
}