/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7422  |  Dataset: bigvul
   Function:     unknown_7422
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5965
   ============================================================ */

/*
 * Changes made:
 *   - Added bounds check to ensure 'it' is not end() before accessing its members
 */

void BrowserPpapiHostImpl::DeleteInstance(PP_Instance instance) {
  auto it = instance_map_.find(instance);
  DCHECK(it != instance_map_.end()); /* FIX [CWE-119]: Ensure iterator validity */
  
  if (it != instance_map_.end()) { /* FIX [CWE-119]: Bounds check for iterator access */
    for (auto& observer : it->second->observer_list)
      observer.OnHostDestroyed();
 
    instance_map_.erase(it);
  }
}