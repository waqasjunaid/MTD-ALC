/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7426  |  Dataset: bigvul
   Function:     unknown_7426
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6098
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added input validation for find_next and forward_direction parameters
 */

void Browser::FindInPage(bool find_next, bool forward_direction) {
  if (find_next && forward_direction) { /* FIX [CWE-20]: Validate inputs */
    ShowFindBar();
    string16 find_text;
#if defined(OS_MACOSX)
     find_text = GetFindPboardText();
 #endif
     if (!find_text.empty()) { /* FIX [CWE-119]: Check for empty input */
       GetSelectedTabContentsWrapper()->
          GetFindManager()->StartFinding(find_text,
                                         forward_direction,
                                         false);  // Not case sensitive.
     }
   }
 }