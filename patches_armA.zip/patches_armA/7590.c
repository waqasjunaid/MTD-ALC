/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7590  |  Dataset: bigvul
   Function:     unknown_7590
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * Changes made:
 * - Added a null check before deleting the array to prevent potential null pointer dereference.
 */

CuePoint::~CuePoint()
{
    if (m_track_positions != nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
        delete[] m_track_positions;
    }
}