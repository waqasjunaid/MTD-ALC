/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7614  |  Dataset: bigvul
   Function:     accept_server_socket
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6903
   ============================================================ */

/* 
 * Changes made:
 * 1. Added error handling for poll() to check for errors other than timeout.
 * 2. Added bounds checking for accept() to ensure that the returned file descriptor is valid.
 */

static int accept_server_socket(int sfd)
{
    struct sockaddr_un remote;
    struct pollfd pfd;
    int fd;
    socklen_t len = sizeof(struct sockaddr_un);

    BTIF_TRACE_EVENT("accept fd %d", sfd);

    /* make sure there is data to process */
    pfd.fd = sfd;
    pfd.events = POLLIN;

    if (poll(&pfd, 1, 0) < 0) { /* FIX [CWE-390]: Check for poll() errors other than timeout */
        BTIF_TRACE_ERROR("poll failed (%s)", strerror(errno));
        return -1;
    } else if (poll(&pfd, 1, 0) == 0) {
        BTIF_TRACE_EVENT("accept poll timeout");
        return -1;
    }

    if ((fd = accept(sfd, (struct sockaddr *)&remote, &len)) < 0) { /* FIX [CWE-252]: Check for invalid file descriptor */
        BTIF_TRACE_ERROR("sock accept failed (%s)", strerror(errno));
        return -1;
    } else if (fd >= FD_SETSIZE) { /* FIX [CWE-252]: Ensure returned file descriptor is within valid range */
        BTIF_TRACE_ERROR("invalid file descriptor");
        close(fd); /* FIX [CWE-404]: Close the invalid file descriptor to prevent resource leak */
        return -1;
    }

    return fd;
}