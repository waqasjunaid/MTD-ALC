/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7659  |  Dataset: bigvul
   Function:     unknown_7659
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for the 'connection' parameter to prevent potential crashes.
 */

void ScreenRecorder::DoAddConnection(
    scoped_refptr<ConnectionToClient> connection) {
  if (connection == nullptr) { /* FIX [CWE-476]: Null pointer dereference */ 
    return; 
  }
  DCHECK(network_loop_->BelongsToCurrentThread());
  connections_.push_back(connection);
}