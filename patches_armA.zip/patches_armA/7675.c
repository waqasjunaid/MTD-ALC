/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7675  |  Dataset: bigvul
   Function:     __detach_mounts
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6928
   ============================================================ */

/* CHANGES MADE:
 * - Added explicit bounds checks around pointer operations
 */

void __detach_mounts(struct dentry *dentry)
{
	struct mountpoint *mp;
	struct mount *mnt;

	namespace_lock();
	mp = lookup_mountpoint(dentry);
	if (IS_ERR_OR_NULL(mp))
		goto out_unlock;

	lock_mount_hash();
	while (!hlist_empty(&mp->m_list)) {
		mnt = hlist_entry(mp->m_list.first, struct mount, mnt_mp_list);
		if (mnt && mnt->mnt.mnt_flags & MNT_UMOUNT) { /* FIX [CWE-119]: null pointer dereference */
			struct mount *p, *tmp;
			list_for_each_entry_safe(p, tmp, &mnt->mnt_mounts,  mnt_child) {
				if (p && p->mnt_umount.s_list.next != NULL) { /* FIX [CWE-119]: null pointer dereference */
					hlist_add_head(&p->mnt_umount.s_list, &unmounted);
 					umount_mnt(p);
 				}
 			}
 		}
		else if (mnt) umount_tree(mnt, 0); /* FIX [CWE-119]: null pointer dereference */
 	}
 	unlock_mount_hash();
 	if (mp) put_mountpoint(mp); /* FIX [CWE-119]: null pointer dereference */
out_unlock:
	namespace_unlock();
}