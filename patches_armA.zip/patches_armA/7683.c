/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7683  |  Dataset: bigvul
   Function:     print_bpf_insn
   Dominant CWE: struct-array
   Error source: MISSED_VULN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6647
   ============================================================ */

/*
 * Changes made:
 * - Added bounds checking for array index access in bpf_alu_string,
 *   bpf_ldst_string, and bpf_jmp_string.
 */

static void print_bpf_insn(struct bpf_insn *insn)
{
    u8 class = BPF_CLASS(insn->code);

    if (class == BPF_ALU || class == BPF_ALU64) {
        if (BPF_SRC(insn->code) == BPF_X)
            verbose("(%02x) %sr%d %s %sr%d\n",
                insn->code, class == BPF_ALU ? "(u32) " : "",
                insn->dst_reg,
                /* FIX [CWE-129]: Validate array index */
                (BPF_OP(insn->code) >> 4 < ARRAY_SIZE(bpf_alu_string)) ?
                    bpf_alu_string[BPF_OP(insn->code) >> 4] : "(unknown)",
                class == BPF_ALU ? "(u32) " : "",
                insn->src_reg);
        else
            verbose("(%02x) %sr%d %s %s%d\n",
                insn->code, class == BPF_ALU ? "(u32) " : "",
                insn->dst_reg,
                /* FIX [CWE-129]: Validate array index */
                (BPF_OP(insn->code) >> 4 < ARRAY_SIZE(bpf_alu_string)) ?
                    bpf_alu_string[BPF_OP(insn->code) >> 4] : "(unknown)",
                class == BPF_ALU ? "(u32) " : "",
                insn->imm);
    } else if (class == BPF_STX) {
        if (BPF_MODE(insn->code) == BPF_MEM)
            verbose("(%02x) *(%s *)(r%d %+d) = r%d\n",
                insn->code,
                /* FIX [CWE-129]: Validate array index */
                (BPF_SIZE(insn->code) >> 3 < ARRAY_SIZE(bpf_ldst_string)) ?
                    bpf_ldst_string[BPF_SIZE(insn->code) >> 3] : "(unknown)",
                insn->src_reg, insn->off);
        else if (insn->code == (BPF_JMP | BPF_JA)) {
            verbose("(%02x) goto pc%+d\n",
                insn->code, insn->off);
        } else if (insn->code == (BPF_JMP | BPF_EXIT)) {
            verbose("(%02x) exit\n", insn->code);
        }
    } else if (class == BPF_LD) {
        if (BPF_MODE(insn->code) == BPF_ABS) {
            verbose("(%02x) r0 = *(%s *)skb[%d]\n",
                insn->code,
                /* FIX [CWE-129]: Validate array index */
                (BPF_SIZE(insn->code) >> 3 < ARRAY_SIZE(bpf_ldst_string)) ?
                    bpf_ldst_string[BPF_SIZE(insn->code) >> 3] : "(unknown)",
                insn->imm);
        } else if (BPF_MODE(insn->code) == BPF_IND) {
            verbose("(%02x) r0 = *(%s *)skb[r%d + %d]\n",
                insn->code,
                /* FIX [CWE-129]: Validate array index */
                (BPF_SIZE(insn->code) >> 3 < ARRAY_SIZE(bpf_ldst_string)) ?
                    bpf_ldst_string[BPF_SIZE(insn->code) >> 3] : "(unknown)",
                insn->src_reg, insn->imm);
        } else if (BPF_MODE(insn->code) == BPF_IMM) {
            verbose("(%02x) r%d = 0x%x\n",
                insn->code, insn->dst_reg, insn->imm);
        }
    } else if (class == BPF_JMP) {
        u8 opcode = BPF_OP(insn->code);

        if (opcode == BPF_CALL) {
            verbose("(%02x) call %s#%d\n", insn->code,
                func_id_name(insn->imm), insn->imm);
        } else if (insn->code == (BPF_JMP | BPF_JA)) {
            verbose("(%02x) goto pc%+d\n",
                insn->code, insn->off);
        } else if (insn->code == (BPF_JMP | BPF_EXIT)) {
            verbose("(%02x) exit\n", insn->code);
        } else if (BPF_SRC(insn->code) == BPF_X) {
            verbose("(%02x) if r%d %s r%d goto pc%+d\n",
                insn->code, insn->dst_reg,
                /* FIX [CWE-129]: Validate array index */
                (BPF_OP(insn->code) >> 4 < ARRAY_SIZE(bpf_jmp_string)) ?
                    bpf_jmp_string[BPF_OP(insn->code) >> 4] : "(unknown)",
                insn->src_reg, insn->off);
        } else {
            verbose("(%02x) if r%d %s 0x%x goto pc%+d\n",
                insn->code, insn->dst_reg,
                /* FIX [CWE-129]: Validate array index */
                (BPF_OP(insn->code) >> 4 < ARRAY_SIZE(bpf_jmp_string)) ?
                    bpf_jmp_string[BPF_OP(insn->code) >> 4] : "(unknown)",
                insn->imm, insn->off);
        }
    } else {
        verbose("(%02x) %s\n", insn->code, bpf_class_string[class]);
    }
}