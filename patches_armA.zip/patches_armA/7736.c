/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7736  |  Dataset: bigvul
   Function:     unknown_7736
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added explicit null check for compositor_client_ to prevent potential null pointer dereference.
 */

void SynchronousCompositorImpl::PostInvalidate() {
   DCHECK(CalledOnValidThread());
   if (compositor_client_) { /* FIX [CWE-476]: Prevent null pointer dereference */
     DCHECK(compositor_client_);
     compositor_client_->PostInvalidate();
   }
 }