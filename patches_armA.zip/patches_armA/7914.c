/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7914  |  Dataset: bigvul
   Function:     unknown_7914
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0131
   ALC decision: UNTRUSTWORTHY  T=0.6969
   ============================================================ */

/*
 * CHANGES:
 * - Added bounds check for dict pointer
 */

FilePath ExtensionPrefs::GetExtensionPath(const std::string& extension_id) {
   const DictionaryValue* dict = GetExtensionPref(extension_id);
   if (!dict) { /* FIX [CWE-476]: null pointer dereference */ 
     return FilePath();
   }
   std::string path;
   if (!dict->GetString(kPrefPath, &path))
     return FilePath();

  return install_directory_.Append(FilePath::FromWStringHack(UTF8ToWide(path)));
}