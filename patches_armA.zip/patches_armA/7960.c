/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7960  |  Dataset: bigvul
   Function:     unknown_7960
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=0.9999
   ALC decision: UNTRUSTWORTHY  T=0.6093
   ============================================================ */

/*
 * Changes made:
 * - Added bounds check for 'which' parameter to prevent potential out-of-bounds access.
 */

cJSON *cJSON_DetachItemFromArray( cJSON *array, int which )
{
	if ( which < 0 ) /* FIX [CWE-129]: invalid input validation */
		return 0;
	cJSON *c = array->child;
	while ( c && which > 0 ) {
		c = c->next;
		--which;
	}
	if ( ! c )
		return 0;
	if ( c->prev )
		c->prev->next = c->next; /* FIX [CWE-129]: explicit bounds check around pointer operation */
	if ( c->next ) c->next->prev = c->prev; /* FIX [CWE-129]: explicit bounds check around pointer operation */
	if ( c == array->child )
		array->child = c->next;
	c->prev = c->next = 0;
	return c;
}