/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7981  |  Dataset: bigvul
   Function:     unknown_7981
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added a null check for the 'sender' pointer to prevent potential crashes.
 */

void CastCastView::ButtonPressed(views::Button* sender,
                                  const ui::Event& event) {
  if (sender != nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
    DCHECK(sender == stop_button_);
  }
  StopCast();
}