/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7987  |  Dataset: bigvul
   Function:     disk_seqf_stop
   Dominant CWE: unknown
   Error source: NOISY_STRATEGY
   MTD verdict:  NON_VULNERABLE  V=0.0225
   ALC decision: UNTRUSTWORTHY  T=0.6924
   ============================================================ */

/*
 * Changes made:
 * - Added NULL check for seqf to prevent potential null pointer dereference
 */

static void disk_seqf_stop(struct seq_file *seqf, void *v)
{
	if (seqf) { /* FIX [CWE-476]: Prevent null pointer dereference */
		struct class_dev_iter *iter = seqf->private;

		/* stop is called even after start failed :-( */
 		if (iter) {
 			class_dev_iter_exit(iter);
 			kfree(iter);
 		}
 	}
 }