/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       7997  |  Dataset: bigvul
   Function:     VectorClamp3
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6743
   ============================================================ */

/* 
 * Changes made:
 * - Added null pointer check for 'value' to prevent potential segmentation faults.
 */

static inline void VectorClamp3(DDSVector3 *value)
{
  if (value != NULL) { /* FIX [CWE-690]: Prevent null pointer dereference */
    value->x = MinF(1.0f,MaxF(0.0f,value->x));
    value->y = MinF(1.0f,MaxF(0.0f,value->y));
    value->z = MinF(1.0f,MaxF(0.0f,value->z));
  }
}