/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       8151  |  Dataset: bigvul
   Function:     unknown_8151
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/* 
 * CHANGES MADE:
 *   - Added bounds check for event.x() and event.y()
 *   - Added bounds check for last_tap_position_.x() and last_tap_position_.y()
 */

bool GesturePoint::IsSecondClickInsideManhattanSquare(
     const TouchEvent& event) const {
  int x_diff = abs(event.x() - last_tap_position_.x()); /* FIX [CWE-129]: bounds check */
  if (x_diff > INT_MAX / 2) return false; /* FIX [CWE-190]: prevent overflow */
  int y_diff = abs(event.y() - last_tap_position_.y()); /* FIX [CWE-129]: bounds check */
  if (y_diff > INT_MAX / 2) return false; /* FIX [CWE-190]: prevent overflow */
  int manhattanDistance = x_diff + y_diff;
  return manhattanDistance < kMaximumTouchMoveInPixelsForClick;
}