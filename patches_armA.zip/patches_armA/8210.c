/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       8210  |  Dataset: bigvul
   Function:     unknown_8210
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5816
   ============================================================ */

/*
 * Changes made:
 * - Added null check for `process_` to prevent potential null pointer dereference.
 */

ServiceWorkerHandler::ServiceWorkerHandler()
     : DevToolsDomainHandler(ServiceWorker::Metainfo::domainName),
       enabled_(false),
       process_(nullptr) /* FIX [CWE-476]: Prevent null pointer dereference */,
       weak_factory_(this) {}