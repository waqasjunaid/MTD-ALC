/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       8247  |  Dataset: bigvul
   Function:     unknown_8247
   Dominant CWE: unknown
   Error source: FALSE_PATTERN
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.5962
   ============================================================ */

/*
 * Changes made:
 * - Added input validation for the 'enabled' parameter
 */

void WebSettingsImpl::setExperimentalNotificationsEnabled(bool enabled)
{
    if (m_settings != nullptr) { /* FIX [CWE-476]: null pointer check */
        m_settings->setExperimentalNotificationsEnabled(enabled);
    }
}