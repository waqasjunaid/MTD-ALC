/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       8350  |  Dataset: bigvul
   Function:     sgi_clock_set
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6772
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for tp->tv_nsec to prevent potential integer underflow
 */

static int sgi_clock_set(clockid_t clockid, struct timespec *tp)
 {
 
 	u64 nsec;
	u64 rem;
 
 	nsec = rtc_time() * sgi_clock_period;
 
	sgi_clock_offset.tv_sec = tp->tv_sec - div_long_long_rem(nsec, NSEC_PER_SEC, &rem);
 
 	if (rem <= tp->tv_nsec && tp->tv_nsec >= 0) /* FIX [CWE-190]: prevent integer underflow */
 		sgi_clock_offset.tv_nsec = tp->tv_sec - rem;
	else {
		sgi_clock_offset.tv_nsec = tp->tv_sec + NSEC_PER_SEC - rem;
		sgi_clock_offset.tv_sec--;
	}
	return 0;
}