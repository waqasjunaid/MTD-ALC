/* ============================================================
   Repaired by LLM Repair Module (Ollama / llama3.1:70b)
   Sample:       8419  |  Dataset: bigvul
   Function:     svc_rdma_xdr_encode_reply_array
   Dominant CWE: unknown
   Error source: AMBIGUOUS
   MTD verdict:  VULNERABLE  V=1.0000
   ALC decision: UNTRUSTWORTHY  T=0.6898
   ============================================================ */

/* 
 * CHANGES MADE:
 * - Added bounds check for 'ary' pointer
 * - Added validation for 'chunks' input value
 */

void svc_rdma_xdr_encode_reply_array(struct rpcrdma_write_array *ary,
				 int chunks)
{
	if (ary == NULL) { /* FIX [CWE-119]: null pointer dereference */
		return;
	}
	if (chunks < 0 || chunks > INT_MAX) { /* FIX [CWE-190]: integer overflow */
		return;
	}
	ary->wc_discrim = xdr_one; /* no change needed */
	ary->wc_nchunks = cpu_to_be32(chunks); /* no change needed */
}