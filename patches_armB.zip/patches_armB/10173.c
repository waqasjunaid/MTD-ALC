/*
 * CHANGES:
 * - Added input validation for iov and iov_count
 * - Added bounds check around pointer/array operation on iov
 */

spnego_gss_wrap_iov(OM_uint32 *minor_status,
		    gss_ctx_id_t context_handle,
		    int conf_req_flag,
		    gss_qop_t qop_req,
		    int *conf_state,
		    gss_iov_buffer_desc *iov, /* FIX [CWE-124]: validated pointer */
 		    int iov_count)
 {
 	OM_uint32 ret;
 
 	if (iov == NULL || iov_count <= 0) { /* FIX [CWE-125]: added bounds check */
 		return GSS_S_FAILURE;
 	}

 	ret = gss_wrap_iov(minor_status,
			   context_handle,
 			   conf_req_flag,
 			   qop_req,
 			   conf_state,
			   iov,
			   iov_count);
	return (ret);
}