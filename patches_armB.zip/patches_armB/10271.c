/* CHANGES:
 * - Added input validation for ufd
 */

struct bpf_map *bpf_map_get_with_uref(u32 ufd)
{
	/* FIX [CWE-20]: Validate input to prevent invalid file descriptor */
	if (ufd < 0) {
		return ERR_PTR(-EBADF);
	}

	struct fd f = fdget(ufd);
	struct bpf_map *map;

	map = __bpf_map_get(f);
 	if (IS_ERR(map))
 		return map;
 
	bpf_map_inc(map, true);
 	fdput(f);
 
 	return map;
}