/* 
 * CHANGES MADE:
 * - Added bounds check for pointer operations on extension_system and extension_service.
 */

void AppShortcutManager::OnceOffCreateShortcuts() {
  bool was_enabled = prefs_->GetBoolean(prefs::kAppShortcutsHaveBeenCreated);
#if defined(OS_MACOSX)
  bool is_now_enabled = apps::IsAppShimsEnabled();
#else
  bool is_now_enabled = true;
#endif  // defined(OS_MACOSX)
  if (was_enabled != is_now_enabled)
    prefs_->SetBoolean(prefs::kAppShortcutsHaveBeenCreated, is_now_enabled);
  if (was_enabled || !is_now_enabled)
     return;

  extensions::ExtensionSystem* extension_system;
  ExtensionServiceInterface* extension_service;
  if (!(extension_system = extensions::ExtensionSystem::Get(profile_)) ||
      !(extension_service = extension_system->extension_service()))
    return;

  // FIX [CWE-119]: Check for null pointer before accessing member function
  if (extension_system && extension_service) {
    const extensions::ExtensionSet* apps = extension_service->extensions();
    // FIX [CWE-119]: Check for null pointer before accessing member function
    if (apps) {
      for (extensions::ExtensionSet::const_iterator it = apps->begin();
           it != apps->end(); ++it) {
        if (ShouldCreateShortcutFor(profile_, it->get()))
          CreateShortcutsInApplicationsMenu(profile_, it->get());
      }
    }
  }
}