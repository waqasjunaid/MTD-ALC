/* 
 * Changes made:
 * - Added NULL checks for q and hb to prevent potential null pointer dereferences.
 */

queue_unlock(struct futex_q *q, struct futex_hash_bucket *hb)
{
	if (hb != NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
		spin_unlock(&hb->lock);
	}
	if (q != NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
		drop_futex_key_refs(&q->key);
	}
}