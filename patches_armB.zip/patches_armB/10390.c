/*
 * CHANGES:
 * - Added bounds check for file pointer to prevent null pointer dereference.
 */

loff_t ftrace_regex_lseek(struct file *file, loff_t offset, int whence)
{
	loff_t ret;

	if (file == NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
		ret = -EINVAL; /* Return an error code for invalid input */
	} else if (file->f_mode & FMODE_READ) {
		ret = seq_lseek(file, offset, whence);
	} else {
		file->f_pos = ret = 1;
	}

	return ret;
}