/*
 * CHANGES MADE:
 * - Added NULL check for cJSON_New_Item() return value to prevent potential dereference of NULL pointer.
 */

cJSON *cJSON_CreateObject( void )
{
	cJSON *item = cJSON_New_Item();
	if ( item != NULL ) /* FIX [CWE-690]: Prevent potential dereference of NULL pointer */
		item->type = cJSON_Object;
	return item;
}