/*
 * CHANGES MADE:
 * - Added a NULL check for the 'private' parameter to prevent potential NULL pointer dereferences.
 */

static void skcipher_release(void *private)
{
	if (private != NULL) { /* FIX [CWE-690]: Prevent NULL pointer dereference */
		crypto_free_skcipher(private);
	}
}