/* CHANGES MADE:
 * - Added bounds check for arr_size to prevent potential out-of-bounds access
 * - Added null pointer checks for arr and arr[i*2] to prevent potential null pointer dereferences
 */

static void array_cleanup( char* arr[] , int arr_size)
 {
 	if (arr == NULL || arr_size < 0) { /* FIX [CWE-119]: bounds check */ 
 		return;
 	}
	int i=0;
	for( i=0; i< arr_size; i++ ){ 
 		if(arr != NULL && arr[i*2] != NULL){ /* FIX [CWE-476]: null pointer check */
 			efree( arr[i*2]);
 		}
	}
	if (arr != NULL) { /* FIX [CWE-476]: null pointer check */ 
 		efree(arr);
 	}
}