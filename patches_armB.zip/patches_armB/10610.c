/*
 * CHANGES:
 * - Added null check for 'window' parameter
 */

void PartialMagnificationController::OnWindowDestroying(aura::Window* window) {
  if (window == nullptr) { /* FIX [CWE-476]: Potential null pointer dereference */ 
    return;
  }
  
  CloseMagnifierWindow();
 
  aura::Window* new_root_window = GetCurrentRootWindow();
  if (new_root_window != nullptr && new_root_window != window) { /* FIX [CWE-476]: Potential null pointer dereference */
    SwitchTargetRootWindow(new_root_window);
  }
}