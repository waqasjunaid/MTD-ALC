/* 
 * CHANGES MADE:
 * - Added a bounds check to ensure the input enum value is within valid range.
 */

PP_InputEvent_Type ConvertEventTypes(WebInputEvent::Type wetype) {
  if (wetype < WebInputEvent::MouseDown || wetype > WebInputEvent::Undefined) { /* FIX [CWE-129]: out-of-bounds enum value */ 
    return PP_INPUTEVENT_TYPE_UNDEFINED;
  }
  
  switch (wetype) {
    case WebInputEvent::MouseDown:
      return PP_INPUTEVENT_TYPE_MOUSEDOWN;
    case WebInputEvent::MouseUp:
      return PP_INPUTEVENT_TYPE_MOUSEUP;
    case WebInputEvent::MouseMove:
      return PP_INPUTEVENT_TYPE_MOUSEMOVE;
    case WebInputEvent::MouseEnter:
       return PP_INPUTEVENT_TYPE_MOUSEENTER;
     case WebInputEvent::MouseLeave:
       return PP_INPUTEVENT_TYPE_MOUSELEAVE;
     case WebInputEvent::MouseWheel:
       return PP_INPUTEVENT_TYPE_MOUSEWHEEL;
     case WebInputEvent::RawKeyDown:
      return PP_INPUTEVENT_TYPE_RAWKEYDOWN;
    case WebInputEvent::KeyDown:
      return PP_INPUTEVENT_TYPE_KEYDOWN;
    case WebInputEvent::KeyUp:
      return PP_INPUTEVENT_TYPE_KEYUP;
    case WebInputEvent::Char:
      return PP_INPUTEVENT_TYPE_CHAR;
    default: /* FIX [CWE-129]: explicit default to handle remaining values */
      return PP_INPUTEVENT_TYPE_UNDEFINED;
  }
}