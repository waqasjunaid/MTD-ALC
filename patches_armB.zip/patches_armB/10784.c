/* 
 * CHANGES:
 * - Added bounds check for script_state to prevent null pointer dereference
 */

ImageBitmapFactories::ImageBitmapLoader::ImageBitmapLoader(
     ImageBitmapFactories& factory,
     base::Optional<IntRect> crop_rect,
     ScriptState* script_state, /* FIX [CWE-476]: Prevent null pointer dereference */
     const ImageBitmapOptions* options)
    : loader_(
           FileReaderLoader::Create(FileReaderLoader::kReadAsArrayBuffer, this)),
       factory_(&factory),
       resolver_(script_state ? ScriptPromiseResolver::Create(script_state) : nullptr), /* FIX [CWE-476]: Check for null before dereferencing */
       crop_rect_(crop_rect),
       options_(options) {}