/*
 * CHANGES:
 * - Added explicit bounds check around pointer operation for pairing_delegate_
 */

void BluetoothDeviceChromeOS::UnregisterAgent() {
  if (!agent_.get())
    return;
  DCHECK(pairing_delegate_);
  DCHECK(pincode_callback_.is_null());
  DCHECK(passkey_callback_.is_null());
  DCHECK(confirmation_callback_.is_null());
  if (pairing_delegate_) { /* FIX [CWE-476]: Ensure pairing_delegate_ is not null before use */
    pairing_delegate_->DismissDisplayOrConfirm();
  }
  pairing_delegate_ = NULL;
  agent_.reset();
  VLOG(1) << object_path_.value() << ": Unregistering pairing agent";
  DBusThreadManager::Get()->GetBluetoothAgentManagerClient()->
      UnregisterAgent(
          dbus::ObjectPath(kAgentPath),
          base::Bind(&base::DoNothing),
          base::Bind(&BluetoothDeviceChromeOS::OnUnregisterAgentError,
                     weak_ptr_factory_.GetWeakPtr()));
}