/**
 * Changes made:
 * - Added input validation for the 'email' and 'proxy_id' parameters.
 */

static void CloudPrintInfoCallback(bool enabled,
                                    const std::string& email,
                                    const std::string& proxy_id) {
    if (!email.empty() && !proxy_id.empty()) { /* FIX [CWE-20]: Validate inputs */
        QuitMessageLoop();
    }
}