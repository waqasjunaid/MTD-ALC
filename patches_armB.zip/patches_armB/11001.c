/*
 * CHANGES MADE:
 * - Added null pointer check for 'library' to prevent potential null pointer dereference.
 */

void CrosLibrary::TestApi::SetBrightnessLibrary(
    BrightnessLibrary* library, bool own) {
  if (library != nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
    library_->brightness_lib_.SetImpl(library, own);
  }
}