/* 
 * CHANGES:
 * - Added null check for webKitPlatformSupport() return value to prevent potential null pointer dereference.
 */

CCLayerTreeHostTest()
         : m_beginning(false)
         , m_endWhenBeginReturns(false)
        , m_running(false)
         , m_timedOut(false)
     {
         WebKitPlatformSupport* support = webKitPlatformSupport();
         if (support) { /* FIX [CWE-476]: prevent null pointer dereference */
             m_webThread = adoptPtr(support->createThread("CCLayerTreeHostTest"));
             WebCompositor::setThread(m_webThread.get());
         } else {
             // Handle the case where webKitPlatformSupport() returns null
             // For example, you could throw an exception or log an error
         }
#if USE(THREADED_COMPOSITING)
        m_settings.enableCompositorThread = true;
#else
        m_settings.enableCompositorThread = false;
 #endif
     }