/*
 * Changes made:
 * - Added explicit bounds checks around pointer operations
 */

static int parse_token(char **name, char **value, char **cp)
{
	char *end;

	if (!name || !value || !cp)
		return -BLKID_ERR_PARAM;

	if (!(*value = strchr(*cp, '=')))
		return 0;

	**value = '\0';
	*name = strip_line(*cp);
 	*value = skip_over_blank(*value + 1);

 	if (**value == '"') {
		end = strchr(*value + 1, '"');
		if (!end) {
 			DBG(READ, ul_debug("unbalanced quotes at: %s", *value));
 			*cp = *value;
 			return -BLKID_ERR_CACHE;
 		}
 		/* FIX [CWE-170]: Ensure end pointer is within bounds */
 		if (end < *value || end > *value + strlen(*value)) {
 			DBG(READ, ul_debug("invalid quote at: %s", *value));
 			*cp = *value;
 			return -BLKID_ERR_CACHE;
 		}
 		(*value)++;
 		*end = '\0';
		end++;
 	} else {
 		end = skip_over_word(*value);
 		if (*end) {
			/* FIX [CWE-170]: Ensure end pointer is within bounds */
 			if (end < *value || end > *value + strlen(*value)) {
 				DBG(READ, ul_debug("invalid word at: %s", *value));
 				*cp = *value;
 				return -BLKID_ERR_CACHE;
 			}
			*end = '\0';
			end++;
		}
	}
	/* FIX [CWE-170]: Ensure end pointer is within bounds */
	if (end < *cp || end > *cp + strlen(*cp)) {
		DBG(READ, ul_debug("invalid end at: %s", *cp));
		return -BLKID_ERR_CACHE;
	}
	*cp = end;

	return 1;
}