/* 
 * CHANGES:
 * - No changes made as the function does not contain any obvious vulnerabilities.
 *   The CWE report indicates "nan" which suggests that no dominant CWE was found.
 */

RenderFrameObserverNatives::RenderFrameObserverNatives(ScriptContext* context)
    : ObjectBackedNativeHandler(context) {
   RouteFunction(
       "OnDocumentElementCreated",
       base::Bind(&RenderFrameObserverNatives::OnDocumentElementCreated,
                  base::Unretained(this)));
 }