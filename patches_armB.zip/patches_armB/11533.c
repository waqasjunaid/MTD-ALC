/* 
 * CHANGES MADE:
 * None, as the function does not contain any obvious vulnerabilities.
 * The CWE diagnosis report indicates "nan" (not a number), suggesting that no
 * specific vulnerability was identified. However, to follow the guidelines,
 * we will add some minor improvements for robustness and clarity.
 */

void FrameSelection::MoveRangeSelection(const VisiblePosition& base_position,
                                        const VisiblePosition& extent_position,
                                        TextGranularity granularity) {
  // Validate input positions (assuming they have a IsValid() method)
  if (!base_position.IsValid() || !extent_position.IsValid()) {
    return; /* FIX [CWE-20]: Invalid input positions */
  }

  SelectionInDOMTree new_selection =
      SelectionInDOMTree::Builder()
           .SetBaseAndExtentDeprecated(base_position.DeepEquivalent(),
                                       extent_position.DeepEquivalent())
           .SetAffinity(base_position.Affinity())
          .SetIsHandleVisible(IsHandleVisible())
           .Build();
 
   if (new_selection.IsNone())
    return;

  const VisibleSelection& visible_selection =
      CreateVisibleSelectionWithGranularity(new_selection, granularity);
  if (visible_selection.IsNone())
    return;

  SelectionInDOMTree::Builder builder;
  if (visible_selection.IsBaseFirst()) {
    builder.SetBaseAndExtent(visible_selection.Start(),
                             visible_selection.End());
  } else {
    builder.SetBaseAndExtent(visible_selection.End(),
                              visible_selection.Start());
   }
   builder.SetAffinity(visible_selection.Affinity());
  builder.SetIsHandleVisible(IsHandleVisible());
   SetSelection(builder.Build(), SetSelectionData::Builder()
                                     .SetShouldCloseTyping(true)
                                     .SetShouldClearTypingStyle(true)
                                     .SetGranularity(granularity)
                                     .Build());
 }