/* 
 * CHANGES:
 * - Added bounds check for redirect_info.new_url to prevent potential null pointer dereference.
 */

void DownloadResourceHandler::OnRequestRedirected(
    const net::RedirectInfo& redirect_info,
    network::ResourceResponse* response,
    std::unique_ptr<ResourceController> controller) {
  if (!redirect_info.new_url.is_valid()) { /* FIX [CWE-476]: prevent null pointer dereference */
    LOG(ERROR) << "Invalid new URL in redirect info.";
    controller->Cancel();
    return;
  }
  url::Origin new_origin(url::Origin::Create(redirect_info.new_url));
  if (!follow_cross_origin_redirects_ &&
      !first_origin_.IsSameOriginWith(new_origin)) {
    base::PostTaskWithTraits(
        FROM_HERE, {BrowserThread::UI},
        base::BindOnce(
            &NavigateOnUIThread, redirect_info.new_url, request()->url_chain(),
            Referrer(GURL(redirect_info.new_referrer),
                      Referrer::NetReferrerPolicyToBlinkReferrerPolicy(
                          redirect_info.new_referrer_policy)),
             GetRequestInfo()->HasUserGesture(),
            GetRequestInfo()->GetWebContentsGetterForRequest()));
     controller->Cancel();
     return;
   }
  if (core_.OnRequestRedirected()) {
    controller->Resume();
  } else {
    controller->Cancel();
  }
}