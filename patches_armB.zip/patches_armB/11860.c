/*
 * Changes made:
 * - Added safe_free macro to set pointers to NULL after free()
 */

#define safe_free(p) do { free(p); (p) = NULL; } while (0)

_zip_cdir_new(int nentry, struct zip_error *error)
{
    struct zip_cdir *cd;
    
    if ((cd=(struct zip_cdir *)malloc(sizeof(*cd))) == NULL) {
	_zip_error_set(error, ZIP_ER_MEMORY, 0);
        return NULL;
     }
 
    if ((cd->entry=(struct zip_dirent *)malloc(sizeof(*(cd->entry))*nentry))
        == NULL) {
        _zip_error_set(error, ZIP_ER_MEMORY, 0);
	safe_free(cd); /* FIX [CWE-416]: set cd to NULL after free() */
	return NULL;
    }

    /* entries must be initialized by caller */

    cd->nentry = nentry;
    cd->size = cd->offset = 0;
    cd->comment = NULL;
    cd->comment_len = 0;

    return cd;
}