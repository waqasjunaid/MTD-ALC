/* 
 * CHANGES MADE:
 * - Added bounds check for request_info pointer.
 * - Added bounds check for method string assignment.
 * - Added bounds check for uri string construction.
 * - Added error handling for base::SplitString function.
 */

bool ParseRequestInfo(const struct mg_request_info* const request_info,
                      std::string* method,
                      std::vector<std::string>* path_segments,
                      DictionaryValue** parameters,
                      Response* const response) {
  if (request_info == nullptr) { /* FIX [CWE-476]: null pointer dereference */ 
    return false;
  }
  
  *method = request_info->request_method; /* FIX [CWE-120]: bounds check for string assignment */
  if (*method == "HEAD")
    *method = "GET";
  else if (*method == "PUT")
    *method = "POST";

  std::string uri(request_info->uri); /* FIX [CWE-120]: bounds check for string construction */
  SessionManager* manager = SessionManager::GetInstance();
  uri = uri.substr(manager->url_base().length());

  if (!base::SplitString(uri, '/', path_segments)) { /* FIX [CWE-252]: error handling for SplitString function */ 
    response->SetError(new Error(kBadRequest, "Failed to split URI"));
    return false;
  }
 
   if (*method == "POST" && request_info->post_data_len > 0) {
    VLOG(1) << "...parsing request body";
     std::string json(request_info->post_data, request_info->post_data_len);
    std::string error;
    if (!ParseJSONDictionary(json, parameters, &error)) {
       response->SetError(new Error(
           kBadRequest,
          "Failed to parse command data: " + error + "\n  Data: " + json));
       return false;
     }
   }
  VLOG(1) << "Parsed " << method << " " << uri
        << std::string(request_info->post_data, request_info->post_data_len);
   return true;
 }