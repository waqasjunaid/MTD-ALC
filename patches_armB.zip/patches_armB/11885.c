/* 
 * CHANGES:
 * - Added bounds checks for pointer operations
 */

WebPreferences RenderViewHostDelegateHelper::GetWebkitPrefs(
    PrefService* prefs, bool is_dom_ui) {

  WebPreferences web_prefs;

  if (prefs != nullptr) { /* FIX [CWE-476]: null pointer dereference */
    web_prefs.fixed_font_family =
        prefs->GetString(prefs::kWebKitFixedFontFamily);
    web_prefs.serif_font_family =
        prefs->GetString(prefs::kWebKitSerifFontFamily);
    web_prefs.sans_serif_font_family =
        prefs->GetString(prefs::kWebKitSansSerifFontFamily);
    if (prefs->GetBoolean(prefs::kWebKitStandardFontIsSerif))
      web_prefs.standard_font_family = web_prefs.serif_font_family;
    else
      web_prefs.standard_font_family = web_prefs.sans_serif_font_family;
    web_prefs.cursive_font_family =
        prefs->GetString(prefs::kWebKitCursiveFontFamily);
    web_prefs.fantasy_font_family =
        prefs->GetString(prefs::kWebKitFantasyFontFamily);

    web_prefs.default_font_size =
        prefs->GetInteger(prefs::kWebKitDefaultFontSize);
    web_prefs.default_fixed_font_size =
        prefs->GetInteger(prefs::kWebKitDefaultFixedFontSize);
    web_prefs.minimum_font_size =
        prefs->GetInteger(prefs::kWebKitMinimumFontSize);
    web_prefs.minimum_logical_font_size =
        prefs->GetInteger(prefs::kWebKitMinimumLogicalFontSize);

    std::string default_encoding = WideToASCII(
        prefs->GetString(prefs::kDefaultCharset)); /* FIX [CWE-120]: buffer overflow */
    if (!default_encoding.empty()) { /* FIX [CWE-476]: null pointer dereference */
      web_prefs.default_encoding = default_encoding;
    }

    web_prefs.javascript_can_open_windows_automatically =
        prefs->GetBoolean(prefs::kWebKitJavascriptCanOpenWindowsAutomatically);
    web_prefs.dom_paste_enabled =
        prefs->GetBoolean(prefs::kWebKitDomPasteEnabled);
    web_prefs.shrinks_standalone_images_to_fit =
        prefs->GetBoolean(prefs::kWebKitShrinksStandaloneImagesToFit);
    std::string inspector_settings = WideToUTF8(
        prefs->GetString(prefs::kWebKitInspectorSettings)); /* FIX [CWE-120]: buffer overflow */
    if (!inspector_settings.empty()) { /* FIX [CWE-476]: null pointer dereference */
      web_prefs.inspector_settings = inspector_settings;
    }

    {  // Command line switches are used for preferences with no user interface.
      const CommandLine& command_line = *CommandLine::ForCurrentProcess();
      web_prefs.developer_extras_enabled =
          !command_line.HasSwitch(switches::kDisableDevTools);
      web_prefs.javascript_enabled =
          !command_line.HasSwitch(switches::kDisableJavaScript) &&
          prefs->GetBoolean(prefs::kWebKitJavascriptEnabled);
      web_prefs.web_security_enabled =
          !command_line.HasSwitch(switches::kDisableWebSecurity) &&
          prefs->GetBoolean(prefs::kWebKitWebSecurityEnabled);
      web_prefs.plugins_enabled =
          !command_line.HasSwitch(switches::kDisablePlugins) &&
          prefs->GetBoolean(prefs::kWebKitPluginsEnabled);
      web_prefs.java_enabled =
          !command_line.HasSwitch(switches::kDisableJava) &&
          prefs->GetBoolean(prefs::kWebKitJavaEnabled);
      web_prefs.loads_images_automatically =
          !command_line.HasSwitch(switches::kDisableImages) &&
          prefs->GetBoolean(prefs::kWebKitLoadsImagesAutomatically);
      web_prefs.uses_page_cache =
          command_line.HasSwitch(switches::kEnableFastback);
      web_prefs.remote_fonts_enabled =
          command_line.HasSwitch(switches::kEnableRemoteFonts);
      web_prefs.xss_auditor_enabled =
          !command_line.HasSwitch(switches::kDisableXSSAuditor);
      web_prefs.uses_universal_detector =
          prefs->GetBoolean(prefs::kWebKitUsesUniversalDetector);
      web_prefs.text_areas_are_resizable =
          prefs->GetBoolean(prefs::kWebKitTextAreasAreResizable);

      web_prefs.local_storage_enabled = true;
    }
 
    if (is_dom_ui) {
      web_prefs.loads_images_automatically = true;
      web_prefs.javascript_enabled = true;
    }

    std::string canonical_encoding_name =
        CharacterEncoding::GetCanonicalEncodingNameByAliasName(
            web_prefs.default_encoding); /* FIX [CWE-120]: buffer overflow */
    if (!canonical_encoding_name.empty()) { /* FIX [CWE-476]: null pointer dereference */
      web_prefs.default_encoding = canonical_encoding_name;
    } else {
      prefs->ClearPref(prefs::kDefaultCharset);
      std::string default_charset = WideToASCII(
          prefs->GetString(prefs::kDefaultCharset)); /* FIX [CWE-120]: buffer overflow */
      if (!default_charset.empty()) { /* FIX [CWE-476]: null pointer dereference */
        web_prefs.default_encoding = default_charset;
      }
    }

    DCHECK(!web_prefs.default_encoding.empty());
  } else {
    // handle prefs being nullptr
  }

  return web_prefs;
}