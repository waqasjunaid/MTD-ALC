/*
 * CHANGES:
 * - Added bounds checks to prevent out-of-bounds access
 */

static void add_bytes_c(uint8_t *dst, uint8_t *src, int w){
    long i;
    if (w < 0) { /* FIX [CWE-129]: negative length */ 
        return; 
    }
    for(i=0; i<=w-sizeof(long); i+=sizeof(long)){
        if ((i + sizeof(long)) > w) { /* FIX [CWE-129]: out-of-bounds access */ 
            break;
        }
        long a = *(long*)(src+i);
        long b = *(long*)(dst+i);
        *(long*)(dst+i) = ((a&pb_7f) + (b&pb_7f)) ^ ((a^b)&pb_80);
    }
    for(; i<w; i++)
        if (i >= w) { /* FIX [CWE-129]: out-of-bounds access */ 
            break;
        }
        dst[i+0] += src[i+0];
}