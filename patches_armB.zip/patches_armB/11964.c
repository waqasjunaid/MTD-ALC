/* 
 * Changes made:
 * - Added explicit null check for data_object
 */

bool ClipboardUtil::HasFilenames(IDataObject* data_object) {
  if (data_object == nullptr) { /* FIX [CWE-476]: Null pointer dereference */ 
    return false;
  }
  DCHECK(data_object);
  return HasData(data_object, Clipboard::GetCFHDropFormatType());
}