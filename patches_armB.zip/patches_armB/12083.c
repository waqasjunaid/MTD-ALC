/* CHANGES MADE:
 * - Added bounds check for video_ before calling Init() and Begin()
 * - Added bounds check for decoder_ after allocation
 */

virtual void SetUp() {
    video_ = new libvpx_test::WebMVideoSource(kVP9TestFile);
    ASSERT_TRUE(video_ != NULL);

    if (video_) { /* FIX [CWE-690]: Ensure video_ is not null before use */
        video_->Init();
        video_->Begin();
    }

    vpx_codec_dec_cfg_t cfg = {0};
    decoder_ = new libvpx_test::VP9Decoder(cfg, 0);
    if (decoder_) { /* FIX [CWE-690]: Ensure decoder_ is not null after allocation */
        // No action needed here
    }
}