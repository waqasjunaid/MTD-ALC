/* CHANGES MADE:
 * - Added bounds check for GetFrame() to prevent null pointer dereferences.
 */

Document* LocalDOMWindow::InstallNewDocument(const String& mime_type,
                                             const DocumentInit& init,
                                             bool force_xhtml) {
  DCHECK_EQ(init.GetFrame(), GetFrame());

  ClearDocument();

  document_ = CreateDocument(mime_type, init, force_xhtml);
  event_queue_ = DOMWindowEventQueue::Create(document_.Get());
  document_->Initialize();

  if (!GetFrame()) /* FIX [CWE-476]: Prevent null pointer dereference */
    return document_;

  Frame* frame = GetFrame(); /* FIX [CWE-476]: Cache frame to avoid repeated calls */
  if (frame) {
    frame->GetScriptController().UpdateDocument();
    document_->UpdateViewportDescription();

    if (frame->GetPage() && frame->View()) {
      frame->GetPage()->GetChromeClient().InstallSupplements(*frame);

      ScrollingCoordinator* scrolling_coordinator =
          frame->GetPage()->GetScrollingCoordinator(); /* FIX [CWE-476]: Check for null before dereference */
      if (scrolling_coordinator) {
        scrolling_coordinator->ScrollableAreaScrollbarLayerDidChange(
            frame->View(), kHorizontalScrollbar);
        scrolling_coordinator->ScrollableAreaScrollbarLayerDidChange(
            frame->View(), kVerticalScrollbar);
        scrolling_coordinator->ScrollableAreaScrollLayerDidChange(
            frame->View());
      }
    }

    frame->Selection().UpdateSecureKeyboardEntryIfActive();
    if (frame->IsCrossOriginSubframe())
      document_->RecordDeferredLoadReason(WouldLoadReason::kCreated);
  }

  return document_;
}