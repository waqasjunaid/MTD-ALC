/*
 * CHANGES MADE:
 * 1. Added null pointer checks for context_ and client_
 */

void RemoveClientSession() {
    if (context_) { /* FIX [CWE-476]: prevent null pointer dereference */
        if (client_) { /* FIX [CWE-476]: prevent null pointer dereference */
            context_->network_message_loop()->PostTask(
                FROM_HERE, base::Bind(
                    &ClientSession::OnConnectionClosed, client_, connection_));
        }
    }
}