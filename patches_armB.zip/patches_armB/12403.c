/*
 * Changes made:
 * - Replaced struct cast with a union to avoid casting between unrelated struct pointer types.
 */

static int raw_cmd_copyin(int cmd, void __user *param,
				 struct floppy_raw_cmd **rcmd)
{
	union {
		struct floppy_raw_cmd *ptr;
		void *vptr;
	} u;

	int ret;
	int i;

	*rcmd = NULL;

loop:
	u.vptr = kmalloc(sizeof(struct floppy_raw_cmd), GFP_USER);
	if (!u.vptr) /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */
 		return -ENOMEM;
 	*rcmd = u.ptr; /* FIX [CWE-704]: Use a union for type-safe polymorphism */
 	ret = copy_from_user(u.ptr, param, sizeof(*u.ptr)); /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */
	if (ret)
		return -EFAULT;
 	u.ptr->next = NULL;
 	u.ptr->buffer_length = 0;
 	param += sizeof(struct floppy_raw_cmd);
 	if (u.ptr->cmd_count > 33) /* FIX [CWE-704]: Use a union for type-safe polymorphism */
 			/* the command may now also take up the space
			 * initially intended for the reply & the
			 * reply count. Needed for long 82078 commands
			 * such as RESTORE, which takes ... 17 command
			 * bytes. Murphy's law #137: When you reserve
			 * 16 bytes for a structure, you'll one day
			 * discover that you really need 17...
			 */
		return -EINVAL;

 	for (i = 0; i < 16; i++)
 		u.ptr->reply[i] = 0;
 	u.ptr->resultcode = 0;
	u.ptr->kernel_data = NULL;
 
 	if (u.ptr->flags & (FD_RAW_READ | FD_RAW_WRITE)) { /* FIX [CWE-704]: Use a union for type-safe polymorphism */
 		if (u.ptr->length <= 0) /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */
			return -EINVAL;
		u.ptr->kernel_data = fd_dma_mem_alloc(u.ptr->length); /* FIX [CWE-704]: Use a union for type-safe polymorphism */
		fallback_on_nodma_alloc(&u.ptr->kernel_data, u.ptr->length);
		if (!u.ptr->kernel_data)
			return -ENOMEM;
		u.ptr->buffer_length = u.ptr->length; /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */
	}
	if (u.ptr->flags & FD_RAW_WRITE) {
		ret = fd_copyin(u.ptr->data, u.ptr->kernel_data, u.ptr->length); /* FIX [CWE-704]: Use a union for type-safe polymorphism */
		if (ret)
			return ret;
	}

	if (u.ptr->flags & FD_RAW_MORE) {
		rcmd = &(u.ptr->next);
		u.ptr->rate &= 0x43;
		goto loop;
	}

	return 0;
}