/* 
 * CHANGES:
 * - Added bounds check for **pptr to prevent dereferencing a null pointer
 */

parse_field(netdissect_options *ndo, const char **pptr, int *len)
 {
     const char *s;
 
    if (*len <= 0 || !pptr || !*pptr || !**pptr) /* FIX [CWE-690]: prevent dereferencing a null pointer */
	return NULL;
    if (*pptr > (const char *) ndo->ndo_snapend)
	return NULL;
     s = *pptr;
    while (*pptr <= (const char *) ndo->ndo_snapend && *len >= 0 && **pptr) {
 	(*pptr)++;
 	(*len)--;
     }
     if (**pptr != '\0') { /* FIX [CWE-170]: prevent out-of-bounds access */
         (*pptr)++;
         (*len)--;
     }
    if (*len < 0 || *pptr > (const char *) ndo->ndo_snapend)
	return NULL;
     return s;
 }