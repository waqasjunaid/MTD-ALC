/* 
 * CHANGES MADE:
 * - No changes made as the function does not contain any obvious vulnerabilities.
 * The CWE category 'nan' indicates that no dominant CWE was identified, suggesting
 * that the function may already be secure or does not contain enough information to
 * identify a vulnerability. However, it's worth noting that the function returns a 
 * static reference which could potentially lead to issues if not properly synchronized 
 * in a multi-threaded environment.
 */

EffectPaintPropertyNode* EffectPaintPropertyNode::Root() {
  DEFINE_STATIC_REF(EffectPaintPropertyNode, root,
                    (EffectPaintPropertyNode::Create(
                        nullptr, State{TransformPaintPropertyNode::Root(),
                                       ClipPaintPropertyNode::Root()})));
   return root;
 }