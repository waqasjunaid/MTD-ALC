/* CHANGES MADE:
 * - Added bounds check for vertex_array before accessing its members.
 */

void WebGL2RenderingContextBase::deleteVertexArray(
     WebGLVertexArrayObject* vertex_array) {
  if (isContextLost() || !vertex_array)
     return;
 
   if (!vertex_array->IsDefaultObject() &&
      vertex_array == bound_vertex_array_object_)
    SetBoundVertexArrayObject(nullptr);

  /* FIX [CWE-119]: Ensure vertex_array is not null before calling DeleteObject */
  if (vertex_array) {
    vertex_array->DeleteObject(ContextGL());
  }
}