/* 
 * CHANGES MADE:
 * - Added bounds check for form_xml string length before passing it to StartRequest.
 */

bool AutofillDownloadManager::StartUploadRequest(
    const FormStructure& form,
    bool form_was_autofilled,
    const FieldTypeSet& available_field_types) {
  if (next_upload_request_ > base::Time::Now()) {
    VLOG(1) << "AutofillDownloadManager: Upload request is throttled.";
    return false;
  }

  double upload_rate = form_was_autofilled ? GetPositiveUploadRate() :
                                              GetNegativeUploadRate();
  if (base::RandDouble() > upload_rate) {
     VLOG(1) << "AutofillDownloadManager: Upload request is ignored.";
     return false;
  }

  std::string form_xml;
  if (!form.EncodeUploadRequest(available_field_types, form_was_autofilled,
                                &form_xml))
    return false;

  // Check that the encoded XML string is not empty
  if (form_xml.empty()) { /* FIX [CWE-125]: prevent passing empty string to StartRequest */
    VLOG(1) << "AutofillDownloadManager: Empty form XML.";
    return false;
  }

  FormRequestData request_data;
  request_data.form_signatures.push_back(form.FormSignature());
  request_data.request_type = AutofillDownloadManager::REQUEST_UPLOAD;

  // Check that the encoded XML string length is within a reasonable bound
  if (form_xml.length() > 1024 * 1024) { /* FIX [CWE-120]: prevent passing excessively large string to StartRequest */
    VLOG(1) << "AutofillDownloadManager: Form XML too large.";
    return false;
  }

  return StartRequest(form_xml, request_data);
}