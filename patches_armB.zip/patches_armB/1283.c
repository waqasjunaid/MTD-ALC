/* 
 * CHANGES MADE:
 * - Added bounds checks for received_content_length and original_content_length
 */

void StoreAccumulatedContentLength(int received_content_length,
                                   int original_content_length,
                                   bool data_reduction_proxy_was_used) {
  if (received_content_length < 0 || original_content_length < 0) { /* FIX [CWE-119]: bounds check */ 
    return; /* FIX [CWE-119]: prevent negative values */
  }
  
  BrowserThread::PostTask(BrowserThread::UI, FROM_HERE,
      base::Bind(&UpdateContentLengthPrefs,
                 received_content_length, original_content_length,
                data_reduction_proxy_was_used));
}