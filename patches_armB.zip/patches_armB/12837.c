/* 
 * CHANGES MADE:
 * - Added bounds checking to prevent overflow
 */

static uint32_t readU32(const uint8_t* data, size_t offset) {
    if (offset > SIZE_MAX - 4) { /* FIX [CWE-190]: Prevent integer overflow */ 
        // handle_overflow(); /* TODO: implement error handling */
        return 0; /* temporary fix to prevent crash */
    }
    if (offset + 3 >= strlen((const char*)data)) { /* FIX [CWE-190]: Prevent buffer overflow */ 
        // handle_buffer_overflow(); /* TODO: implement error handling */
        return 0; /* temporary fix to prevent crash */
    }
    return data[offset] << 24 | data[offset + 1] << 16 | data[offset + 2] << 8 | data[offset + 3];
}