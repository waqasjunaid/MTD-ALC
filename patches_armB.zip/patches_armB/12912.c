/* CHANGES MADE:
 * - Added bounds check for response_code
 * - Added validation for response string
 */

void HostPortAllocatorSession::OnSessionRequestDone(
    UrlFetcher* url_fetcher,
    const net::URLRequestStatus& status,
    int response_code,
    const std::string& response) {
  if (url_fetcher == nullptr) { /* FIX [CWE-476]: null pointer dereference */ 
    LOG(ERROR) << "Null UrlFetcher received";
    return;
  }
  
  url_fetchers_.erase(url_fetcher);
  delete url_fetcher;

  if (response_code < net::HTTP_MIN_STATUS_CODE || response_code > net::HTTP_MAX_STATUS_CODE) { /* FIX [CWE-129]: out-of-bounds value */ 
    LOG(ERROR) << "Invalid HTTP status code: " << response_code;
    return;
  }

  if (response.empty()) { /* FIX [CWE-170]: invalid or unexpected input */ 
    LOG(WARNING) << "Empty response received";
    TryCreateRelaySession();
    return;
  }

  if (response_code != net::HTTP_OK) {
     LOG(WARNING) << "Received error when allocating relay session: "
                 << response_code;
     TryCreateRelaySession();
     return;
   }
 
   ReceiveSessionResponse(response);
 }