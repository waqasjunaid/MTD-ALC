/* 
 * CHANGES MADE:
 * - Added null checks for pointer operations
 */

void AppLauncherHandler::FillAppDictionary(base::DictionaryValue* dictionary) {
  if (!dictionary) { /* FIX [CWE-476]: Potential NULL pointer dereference */ 
    return;
  }

  base::AutoReset<bool> auto_reset(&ignore_changes_, true);

  base::ListValue* list = new base::ListValue();
  if (!list) { /* FIX [CWE-772]: Potential memory leak on allocation failure */
    return;
  }

  Profile* profile = Profile::FromWebUI(web_ui());
  if (!profile) { /* FIX [CWE-476]: Potential NULL pointer dereference */ 
    delete list; // Avoid memory leak
    return;
  }

  PrefService* prefs = profile->GetPrefs();
  if (!prefs) { /* FIX [CWE-476]: Potential NULL pointer dereference */ 
    delete list; // Avoid memory leak
    return;
  }

  for (std::set<std::string>::iterator it = visible_apps_.begin();
       it != visible_apps_.end(); ++it) {
    const Extension* extension = extension_service_->GetInstalledExtension(*it);
    if (extension && extensions::ui_util::ShouldDisplayInNewTabPage(
            extension, profile)) {
      base::DictionaryValue* app_info = GetAppInfo(extension);
      if (!app_info) { /* FIX [CWE-476]: Potential NULL pointer dereference */ 
        continue;
      }
      list->Append(app_info);
    }
  }

  dictionary->Set("apps", list);

#if defined(OS_MACOSX)
  dictionary->SetBoolean("disableAppWindowLaunch", true);
  dictionary->SetBoolean("disableCreateAppShortcut", true);
#endif
#if defined(OS_CHROMEOS)
  dictionary->SetBoolean("disableCreateAppShortcut", true);
#endif

  const base::ListValue* app_page_names =
      prefs->GetList(prefs::kNtpAppPageNames);
  if (!app_page_names || !app_page_names->GetSize()) {
    ListPrefUpdate update(prefs, prefs::kNtpAppPageNames);
    base::ListValue* list = update.Get();
    if (!list) { /* FIX [CWE-772]: Potential memory leak on allocation failure */
      return;
    }
    list->Set(0, new base::StringValue(
        l10n_util::GetStringUTF16(IDS_APP_DEFAULT_PAGE_NAME)));
    dictionary->Set("appPageNames",
                    static_cast<base::ListValue*>(list->DeepCopy()));
  } else {
    dictionary->Set("appPageNames",
                    static_cast<base::ListValue*>(app_page_names->DeepCopy()));
  }
}