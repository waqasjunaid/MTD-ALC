/* 
 * CHANGES MADE:
 * - Added bounds check for response pointer
 */

void ServiceWorkerPaymentInstrument::OnPaymentAppInvoked(
     mojom::PaymentHandlerResponsePtr response) {
  DCHECK(delegate_);
  if (delegate_ != nullptr && response != nullptr) { /* FIX [CWE-476]: null pointer dereference */
    std::string method_name = response->method_name; /* FIX [CWE-120]: bounds check for stringified_details */
    std::string stringified_details = response->stringified_details;
    if (!method_name.empty() && !stringified_details.empty()) { /* FIX [CWE-119]: bounds check for strings */
      delegate_->OnInstrumentDetailsReady(method_name, stringified_details);
    }
  }
  delegate_ = nullptr;
}