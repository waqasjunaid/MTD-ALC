/* CHANGES MADE:
   - Added bounds check for playback_rate to prevent potential division by zero or out-of-range values.
*/

void TestPlaybackRate(double playback_rate) {
    static const int kDefaultBufferSize = kSamplesPerSecond / 10;
    static const int kDefaultFramesRequested = 5 * kSamplesPerSecond;

    if (playback_rate <= 0.0 || playback_rate > 100.0) { /* FIX [CWE-189]: Validate input to prevent out-of-range values */
        // Handle invalid playback rate, e.g., set to default or return an error
        playback_rate = 1.0; /* FIX [CWE-189]: Set to a safe default value */
    }

    TestPlaybackRate(playback_rate, kDefaultBufferSize,
                     kDefaultFramesRequested);
}