/*
 * Changes made:
 * - Added null check for m_page to prevent potential null pointer dereference
 */

void WebPagePrivate::didComposite()
{
    if (!m_page) /* FIX [CWE-476]: Prevent null pointer dereference */
        return;
    if (!m_page->settings()->developerExtrasEnabled())
        return;
    InspectorInstrumentation::didComposite(m_page);
}