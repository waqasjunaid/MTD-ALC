/* 
 * CHANGES MADE:
 * - Added a null check for m_info to prevent potential null pointer dereference.
 */

const char* Track::GetLanguage() const
{
    if (m_info != nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
        return m_info.language;
    } else {
        return ""; /* Return an empty string or a default value when m_info is null */
    }
}