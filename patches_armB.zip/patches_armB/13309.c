/* 
 * CHANGES MADE:
 * - Added bounds checks for integer overflow prevention.
 */

bool InputWindowInfo::frameContainsPoint(int32_t x, int32_t y) const {
    /* FIX [CWE-190]: Prevent integer overflow by checking if coordinates are within valid range */
    if (x < INT32_MIN || x > INT32_MAX || y < INT32_MIN || y > INT32_MAX) {
        return false;
    }
    
    /* FIX [CWE-190]: Ensure frame bounds are not swapped to prevent incorrect results */
    int32_t left = std::min(frameLeft, frameRight);  /* FIX [CWE-190]: Use min to ensure correct ordering */
    int32_t right = std::max(frameLeft, frameRight); /* FIX [CWE-190]: Use max to ensure correct ordering */
    int32_t top = std::min(frameTop, frameBottom);   /* FIX [CWE-190]: Use min to ensure correct ordering */
    int32_t bottom = std::max(frameTop, frameBottom);/* FIX [CWE-190]: Use max to ensure correct ordering */

    return x >= left && x <= right
            && y >= top && y <= bottom;
}