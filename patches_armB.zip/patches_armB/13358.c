/*
 * Changes made:
 * - Added bounds check for size to prevent potential buffer overflow
 */

void GpuVideoDecodeAccelerator::OnDecode(
    base::SharedMemoryHandle handle, int32 id, int32 size) {
   DCHECK(video_decode_accelerator_.get());
   if (size < 0 || size > std::numeric_limits<int32>::max()) { /* FIX [CWE-119]: bounds check for size */
     LOG(ERROR) << "Invalid size: " << size;
     return;
   }
   video_decode_accelerator_->Decode(media::BitstreamBuffer(id, handle, size));
 }