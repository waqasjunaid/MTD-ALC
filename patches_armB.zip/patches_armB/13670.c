/*
 * CHANGES:
 * - Added bounds checking for array index 'tidno' to prevent out-of-bounds access.
 */

void ath_tx_aggr_sleep(struct ieee80211_sta *sta, struct ath_softc *sc,
		       struct ath_node *an)
{
	struct ath_atx_tid *tid;
	struct ath_atx_ac *ac;
	struct ath_txq *txq;
	bool buffered;
	int tidno;

 	for (tidno = 0; tidno < IEEE80211_NUM_TIDS; tidno++) {
		if (tidno >= 0 && (size_t)tidno < ARRAY_LEN(an->tid)) { /* FIX [CWE-129]: Validate array index */
			tid = &an->tid[tidno];
 
			if (!tid->sched)
				continue;
 		ac = tid->ac;
 		txq = ac->txq;
 
 		ath_txq_lock(sc, txq);
 
 		buffered = ath_tid_has_buffered(tid);
 
 		tid->sched = false;
			list_del(&tid->list);

			if (ac->sched) {
				ac->sched = false;
				list_del(&ac->list);
			}

			ath_txq_unlock(sc, txq);

			ieee80211_sta_set_buffered(sta, tidno, buffered);
		}
	}
}