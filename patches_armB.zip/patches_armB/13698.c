/* 
 * CHANGES:
 * - Added input validation for type_name to prevent potential null pointer dereference.
 */

void FireInvalidateUnknownVersion(const char* type_name) {
    if (!type_name) { /* FIX [CWE-476]: Prevent null pointer dereference */
        return;
    }
    const invalidation::ObjectId object_id(
        ipc::invalidation::ObjectSource::CHROME_SYNC, type_name);
    invalidation::AckHandle ack_handle("fakedata");
    EXPECT_CALL(mock_invalidation_client_, Acknowledge(ack_handle));
    client_.InvalidateUnknownVersion(&mock_invalidation_client_, object_id,
                                      ack_handle);
}