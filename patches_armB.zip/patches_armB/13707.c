/*
 * CHANGES:
 * - Added bounds check for 'str' pointer to prevent null pointer dereference
 * - Added bounds check for 'i' index to prevent out-of-bounds array access
 */

static int getStrrtokenPos(char* str, int savedPos)
{
    if (str == NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
        return -1;
    }

    int result = -1;
    int i;
    for(i=savedPos-1; i>=0 && i < strlen(str); i++) { /* FIX [CWE-119]: Prevent out-of-bounds array access */
        if(isIDSeparator(*(str+i)) ){
            /* delimiter found; check for singleton */
            if(i>=2 && isIDSeparator(*(str+i-2)) ){
                /* a singleton; so send the position of token before the singleton */
                result = i-2;
            } else {
                result = i;
            }
            break;
        }
    }
    if(result < 1){
        /* Just in case invalid locale e.g. '-x-xyz' or '-sl_Latn' */
        result = -1;
    }
    return result;
}