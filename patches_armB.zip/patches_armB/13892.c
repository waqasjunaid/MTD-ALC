/*
 * CHANGES:
 * - Added bounds checking for array access in handle_priv->interface_handle
 */

static int hid_abort_transfers(int sub_api, struct usbi_transfer *itransfer)
{
	struct libusb_transfer *transfer = USBI_TRANSFER_TO_LIBUSB_TRANSFER(itransfer);
	struct windows_transfer_priv *transfer_priv = (struct windows_transfer_priv*)usbi_transfer_get_os_priv(itransfer);
	struct windows_device_handle_priv *handle_priv = _device_handle_priv(transfer->dev_handle);
	HANDLE hid_handle;
	int current_interface;
	CHECK_HID_AVAILABLE;
	current_interface = transfer_priv->interface_number;
	if (current_interface >= 0 && (size_t)current_interface < ARRAY_LEN(handle_priv->interface_handle)) { /* FIX [CWE-129]: bounds checking for array access */
		hid_handle = handle_priv->interface_handle[current_interface].api_handle;
		CancelIo(hid_handle);
	} else {
		return LIBUSB_ERROR_INVALID_PARAM; /* return error if index is out of bounds */
	}
	return LIBUSB_SUCCESS;
}