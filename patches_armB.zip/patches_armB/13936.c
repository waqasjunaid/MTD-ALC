/*
 * CHANGES MADE:
 * - Added explicit cast to unsigned long for size parameter
 * - Validated value is in range before explicit cast
 */

static void *__alloc_from_pool(size_t size, struct page **ret_page, gfp_t flags)
{
	unsigned long val;
	void *ptr = NULL;

	if (!atomic_pool) {
		WARN(1, "coherent pool not initialised!\n");
		return NULL;
	}

	val = gen_pool_alloc(atomic_pool, (unsigned long)size); /* FIX [CWE-704]: explicit cast to unsigned long */
	if (val != (unsigned long)-1 && val <= SIZE_MAX) { /* FIX [CWE-704]: validate value is in range */
		phys_addr_t phys = gen_pool_virt_to_phys(atomic_pool, val);
 
 		*ret_page = phys_to_page(phys);
 		ptr = (void *)val;
		if (flags & __GFP_ZERO)
			memset(ptr, 0, size);
 	}
 
 	return ptr;
}