/*
 * Changes made:
 * - Added bounds checking for array index 'i' in the loop
 */

static void unix_detach_fds(struct scm_cookie *scm, struct sk_buff *skb)
{
	int i;

	scm->fp = UNIXCB(skb).fp;
 	UNIXCB(skb).fp = NULL;
 
 	for (i = scm->fp->count-1; i >= 0 && (size_t)i < scm->fp->count; i--) /* FIX [CWE-129]: validated array index */
		unix_notinflight(scm->fp->fp[i]); /* FIX [CWE-129]: ensured valid access to fp array */
 }