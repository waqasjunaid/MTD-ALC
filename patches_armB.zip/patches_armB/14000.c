/* 
 * CHANGES:
 * - Added bounds check for pageFromObject() return value
 * - Added null check for HeapObjectHeader::fromPayload() return value
 */

void HeapAllocator::backingFree(void* address) {
  if (!address)
    return;

  ThreadState* state = ThreadState::current();
  if (state->sweepForbidden())
    return;
  ASSERT(!state->isInGC());

  BasePage* page = pageFromObject(address);
  if (!page) /* FIX [CWE-119]: null pointer dereference */ 
    return;

  if (page->isLargeObjectPage() || page->arena()->getThreadState() != state)
     return;
 
   HeapObjectHeader* header = HeapObjectHeader::fromPayload(address);
  if (!header) /* FIX [CWE-119]: null pointer dereference */ 
    return;

  ASSERT(header->checkHeader());
   NormalPageArena* arena = static_cast<NormalPage*>(page)->arenaForNormalPage();
   state->promptlyFreed(header->gcInfoIndex());
   arena->promptlyFreeObject(header);
}