/* 
 * Changes made:
 * 1. Added bounds check to prevent division by zero.
 */

void MediaControlsProgressView::HandleSeeking(
    const gfx::Point& location_in_bar) {
   if (progress_bar_->width() == 0) { /* FIX [CWE-369]: Prevent division by zero */
     return;
   }
   double seek_to_progress =
       static_cast<double>(location_in_bar.x()) / progress_bar_->width();
   seek_callback_.Run(seek_to_progress);
}