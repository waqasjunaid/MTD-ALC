/* 
 * CHANGES MADE:
 * - Added bounds checking for array index access
 */

std::string SanitizeRevision(const std::string& revision) {
  if (revision.empty()) { /* FIX [CWE-129]: prevent out-of-bounds access */ 
    return std::string();
  }
  for (size_t i = 0; i < revision.length(); i++) {
    if (!(i >= 0 && i < revision.size() && /* FIX [CWE-129]: validate array index */
          ((revision[i] == '@' && i == 0)
           || (revision[i] >= '0' && revision[i] <= '9')
           || (revision[i] >= 'a' && revision[i] <= 'z')
           || (revision[i] >= 'A' && revision[i] <= 'Z')))) {
      return std::string();
    }
  }
  return revision;
}