/* 
 * CHANGES:
 * - Added null check for render_frame_ to prevent potential null pointer dereference.
 */

void DistillerNativeJavaScript::EnsureServiceConnected() {
  if (!distiller_js_service_) {
    if (render_frame_) { /* FIX [CWE-476]: Prevent null pointer dereference */
      render_frame_->GetServiceRegistry()->ConnectToRemoteService(
          mojo::GetProxy(&distiller_js_service_));
    }
  }
}