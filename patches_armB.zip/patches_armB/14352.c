/*
 * CHANGES:
 * - Added overflow check for potential integer overflow in shift operation
 */

l2tp_accm_print(netdissect_options *ndo, const u_char *dat)
 {
 	const uint16_t *ptr = (const uint16_t *)dat;
 	uint16_t val_h, val_l;
 
 	ptr++;		/* skip "Reserved" */
 
	val_h = EXTRACT_16BITS(ptr); ptr++;
	val_l = EXTRACT_16BITS(ptr); ptr++;

	if ((uint32_t)val_h > (UINT32_MAX >> 16)) { /* FIX [CWE-190]: prevent overflow in shift operation */ 
		ND_PRINT((ndo, "send=OVERFLOW "));
	} else {
		ND_PRINT((ndo, "send=%08x ", (uint32_t)(val_h<<16) + val_l));
	}

 	val_h = EXTRACT_16BITS(ptr); ptr++;
 	val_l = EXTRACT_16BITS(ptr); ptr++;

	if ((uint32_t)val_h > (UINT32_MAX >> 16)) { /* FIX [CWE-190]: prevent overflow in shift operation */ 
		ND_PRINT((ndo, "recv=OVERFLOW "));
	} else {
		ND_PRINT((ndo, "recv=%08x ", (uint32_t)(val_h<<16) + val_l));
	}
}