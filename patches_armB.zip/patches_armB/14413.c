/* 
 * CHANGES MADE:
 * - Added bounds checking for array indices to prevent out-of-bounds access.
 */

static opj_bool pi_next_lrcp(opj_pi_iterator_t * pi)
 {
     opj_pi_comp_t *comp = NULL;
    opj_pi_resolution_t *res = NULL;
    long index = 0;

    if (!pi->first) {
        /* FIX [CWE-129]: Validate array index before access */
        if (pi->compno >= 0 && (size_t)pi->compno < sizeof(pi->comps) / sizeof(pi->comps[0])) {
            comp = &pi->comps[pi->compno];
            /* FIX [CWE-129]: Validate array index before access */
            if (pi->resno >= 0 && (size_t)pi->resno < comp->numresolutions) {
                res = &comp->resolutions[pi->resno];
            }
        }
        goto LABEL_SKIP;
    } else {
        pi->first = 0;
    }

    for (pi->layno = pi->poc.layno0; pi->layno < pi->poc.layno1; pi->layno++) {
        for (pi->resno = pi->poc.resno0; pi->resno < pi->poc.resno1;
                pi->resno++) {
            for (pi->compno = pi->poc.compno0; pi->compno < pi->poc.compno1; pi->compno++) {
                /* FIX [CWE-129]: Validate array index before access */
                if (pi->compno >= 0 && (size_t)pi->compno < sizeof(pi->comps) / sizeof(pi->comps[0])) {
                    comp = &pi->comps[pi->compno];
                    /* FIX [CWE-129]: Validate array index before access */
                    if (pi->resno >= 0 && pi->resno < comp->numresolutions) {
                        res = &comp->resolutions[pi->resno];
                        if (!pi->tp_on) {
                            pi->poc.precno1 = res->pw * res->ph;
                        }
                         for (pi->precno = pi->poc.precno0; pi->precno < pi->poc.precno1; pi->precno++) {
                             index = pi->layno * pi->step_l + pi->resno * pi->step_r + pi->compno *
                                     pi->step_c + pi->precno * pi->step_p;
                             /* FIX [CWE-129]: Validate array index before access */
                             if (index >= 0 && (size_t)index < sizeof(pi->include) / sizeof(pi->include[0])) {
                                 if (!pi->include[index]) {
                                     pi->include[index] = 1;
                                     return OPJ_TRUE;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return OPJ_FALSE;
LABEL_SKIP:
    ;
}