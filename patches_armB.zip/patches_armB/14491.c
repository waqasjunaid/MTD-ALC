/* 
 * CHANGES MADE:
 * - Added input validation for 'size' parameter to prevent potential integer overflow.
 */

void* ipc_alloc(int size)
{
	void* out;
	if (size <= 0) { /* FIX [CWE-839]: invalid input */ 
		return NULL; /* FIX [CWE-839]: handle invalid input */
	}
	if(size > PAGE_SIZE)
 		out = vmalloc(size);
 	else
		out = kmalloc(size, GFP_KERNEL);
	if (!out) { /* FIX [CWE-690]: check return value of allocation function */ 
		return NULL; /* FIX [CWE-690]: handle allocation failure */
	}
	return out;
}