/*
 * Changes made:
 * - Added overflow check before left shift operation
 */

static void copyStereo8(
         short *dst,
        const int *const *src,
         unsigned nSamples,
         unsigned /* nChannels */) {
    for (unsigned i = 0; i < nSamples; ++i) {
        if ((src[0][i] & 0xFF000000) != 0 || src[0][i] > 127) { /* FIX [CWE-190]: check for overflow before left shift */ 
            // handle_overflow(); // implement proper error handling
            return;
        }
        *dst++ = (short)(src[0][i] << 8);
        
        if ((src[1][i] & 0xFF000000) != 0 || src[1][i] > 127) { /* FIX [CWE-190]: check for overflow before left shift */ 
            // handle_overflow(); // implement proper error handling
            return;
        }
        *dst++ = (short)(src[1][i] << 8);
    }
}