/* CHANGES MADE:
 * - Added bounds check to prevent iterator invalidation
 */

void UserSelectionScreen::OnBeforeUserRemoved(const AccountId& account_id) {
  for (user_manager::UserList::iterator it = users_.begin(); it != users_.end();
       ++it) {
    if ((*it)->GetAccountId() == account_id) {
      user_manager::UserList::iterator temp_it = it; /* FIX [CWE-469]: prevent iterator invalidation */
      ++temp_it;
      users_.erase(it);
      break;
    }
  }
}