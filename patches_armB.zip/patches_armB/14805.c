/* 
 * CHANGES:
 * - Added null check for render_frame to prevent potential null pointer dereference.
 */

PasswordAutofillAgent::PasswordAutofillAgent(content::RenderFrame* render_frame)
     : content::RenderFrameObserver(render_frame ? render_frame : nullptr), /* FIX [CWE-476]: Prevent null pointer dereference */
       logging_state_active_(false),
       was_username_autofilled_(false),
       was_password_autofilled_(false),
       weak_ptr_factory_(this) {
   if (render_frame) { /* FIX [CWE-476]: Check for null before using render_frame */
     Send(new AutofillHostMsg_PasswordAutofillAgentConstructed(routing_id()));
   }
 }