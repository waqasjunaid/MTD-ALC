/*
 * CHANGES:
 * - Added bounds check for port_id pointer
 */

void ChromeMockRenderThread::OnMsgOpenChannelToExtension(
    int routing_id, const std::string& source_extension_id,
     const std::string& target_extension_id,
    const std::string& channel_name, int* port_id) {
  if (port_id != nullptr) { /* FIX [CWE-124]: prevent null pointer dereference */
    *port_id = 0;
  }
}