/*
 * Changes made:
 * - Added bounds checking for array index in __bdevname function call
 */

static struct block_device *ext3_blkdev_get(dev_t dev, struct super_block *sb)
{
	struct block_device *bdev;
	char b[BDEVNAME_SIZE];

	bdev = blkdev_get_by_dev(dev, FMODE_READ|FMODE_WRITE|FMODE_EXCL, sb);
	if (IS_ERR(bdev))
		goto fail;
 	return bdev;
 
 fail:
	size_t idx = dev;
	if (idx >= 0 && (size_t)idx < BDEVNAME_SIZE) { /* FIX [CWE-129]: validate array index */
		ext3_msg(sb, "error: failed to open journal device %s: %ld",
 			__bdevname(dev, b), PTR_ERR(bdev));
	} else {
		ext3_msg(sb, "error: invalid dev_t value: %lu", (unsigned long)dev);
	}
 
 	return NULL;
}