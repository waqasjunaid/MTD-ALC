/* CHANGES MADE:
 * - Added bounds checking for array index access in instance_map_ and live_resources_
 */

bool ResourceTracker::UnrefResource(PP_Resource res) {
  DLOG_IF(ERROR, !CheckIdType(res, PP_ID_TYPE_RESOURCE))
      << res << " is not a PP_Resource.";
  ResourceMap::iterator i = live_resources_.find(res);
  if (i != live_resources_.end()) {
    if (!--i->second.second) {
      Resource* to_release = i->second.first;
      PP_Instance instance = to_release->instance()->pp_instance();
      /* FIX [CWE-129]: Validate array index before access */
      if ((size_t)instance < instance_map_.size()) { 
        instance_map_[instance]->resources.erase(res);
      }
      live_resources_.erase(i);
    }
    return true;
  } else {
    return false;
  }
}