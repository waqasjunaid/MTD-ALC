/* CHANGES MADE:
 * - Added bounds checking for array access in the line where 'text[0]' is accessed.
 */

void TypingCommand::insertText(Document& document,
                               const String& text,
                               Options options,
                               TextCompositionType composition,
                               const bool isIncrementalInsertion) {
  LocalFrame* frame = document.frame();
  DCHECK(frame);

  if (!text.isEmpty() && (size_t)0 < text.length()) { /* FIX [CWE-129]: validate array index */
     document.frame()->spellChecker().updateMarkersForWordsAffectedByEditing(
         isSpaceOrNewline(text[0])); /* FIX [CWE-129]: safe access to 'text' array */
  }
 
  insertText(document, text,
             frame->selection().computeVisibleSelectionInDOMTreeDeprecated(),
             options, composition, isIncrementalInsertion);
 }