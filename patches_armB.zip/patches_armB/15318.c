/*
 * Changes made:
 * - Added a null check for encT to prevent potential null pointer dereference.
 */

static void prefetch_enc(void)
{
    if (encT != NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
        prefetch_table((const void *)encT, sizeof(encT));
    }
}