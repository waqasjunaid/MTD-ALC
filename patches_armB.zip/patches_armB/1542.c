/* 
 * CHANGES:
 * - Added bounds checking for array index access to prevent out-of-bounds read.
 */

string16 ExtensionInstallUI::Prompt::GetHeading(std::string extension_name)
    const {
   if (type_ == INLINE_INSTALL_PROMPT) {
     return UTF8ToUTF16(extension_name);
   } else {
    size_t type_idx = static_cast<size_t>(type_);
    if (type_idx >= 0 && type_idx < ARRAYSIZE(kHeadingIds)) { /* FIX [CWE-129]: Validate array index */
      return l10n_util::GetStringFUTF16(
          kHeadingIds[type_], UTF8ToUTF16(extension_name));
    } else {
      // Handle out-of-bounds error, e.g., return an empty string or throw an exception
      return string16();
    }
  }
}