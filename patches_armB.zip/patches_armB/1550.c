/*
 * Changes made:
 * - Added bounds checking for array index access in args
 */

static v8::Handle<v8::Value> methodWithCallbackArgCallback(const v8::Arguments& args)
{
    INC_STATS("DOM.TestObj.methodWithCallbackArg");
    if (args.Length() < 1)
        return V8Proxy::throwNotEnoughArgumentsError();
    TestObj* imp = V8TestObj::toNative(args.Holder());
    if (args.Length() <= 0 || !args[0]->IsFunction())
         return throwError(TYPE_MISMATCH_ERR, args.GetIsolate());
    size_t idx = 0; /* FIX [CWE-129]: introduced index variable */
    if (idx >= 0 && (size_t)idx < args.Length()) { /* FIX [CWE-129]: bounds checking for array access */
        RefPtr<TestCallback> callback = V8TestCallback::create(args[idx], getScriptExecutionContext()); /* FIX [CWE-129]: use index variable */
    } else {
        return throwError(INDEX_SIZE_ERR, args.GetIsolate()); /* FIX [CWE-129]: handle out-of-bounds error */
    }
    imp->methodWithCallbackArg(callback);
    return v8::Handle<v8::Value>();
}