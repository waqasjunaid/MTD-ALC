/*
 * Changes made:
 * - Added bounds check for pointer ct
 * - Added return value checks for nfct_attr_is_set and ct_build_* functions
 */

static void build_l4proto_sctp(const struct nf_conntrack *ct, struct nethdr *n)
{
    if (ct == NULL) { /* FIX [CWE-476]: null pointer dereference */ 
        return;
    }

    if (nfct_attr_is_set(ct, ATTR_GRP_ORIG_PORT)) {
        ct_build_group(ct, ATTR_GRP_ORIG_PORT, n, NTA_PORT,
                sizeof(struct nfct_attr_grp_port));
    } else { /* FIX [CWE-252]: unchecked return value */ 
        // handle error
    }

    if (nfct_attr_is_set(ct, ATTR_SCTP_STATE)) {
        ct_build_u8(ct, ATTR_SCTP_STATE, n, NTA_SCTP_STATE);
        if (!ct_build_u32(ct, ATTR_SCTP_VTAG_ORIG, n, NTA_SCTP_VTAG_ORIG)) { /* FIX [CWE-252]: unchecked return value */ 
            // handle error
        }
        if (!ct_build_u32(ct, ATTR_SCTP_VTAG_REPL, n, NTA_SCTP_VTAG_REPL)) { /* FIX [CWE-252]: unchecked return value */ 
            // handle error
        }
    } else {
        // handle error
    }
}