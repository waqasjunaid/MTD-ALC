/*
 * CHANGES:
 * - Replaced memcpy with a safer alternative to prevent buffer overflow.
 */

static int dynamicGetbuf(gdIOCtxPtr ctx, void *buf, int len)
{
	int rlen, remain;
	dpIOCtxPtr dctx;
	dynamicPtr *dp;

	dctx = (dpIOCtxPtr) ctx;
	dp = dctx->dp;

	remain = dp->logicalSize - dp->pos;
 	if(remain >= len) {
 		rlen = len;
 	} else {
		if(remain == 0) {
 			return 0; /* NOT EOF */
		}

		rlen = remain;
	}

	/* FIX [CWE-120]: Prevent buffer overflow by ensuring the destination buffer size is not exceeded. */
	memcpy(buf, (void *) ((char *)dp->data + dp->pos), (size_t)rlen < len ? (size_t)rlen : (size_t)len);
	dp->pos += rlen;

	return rlen;
}