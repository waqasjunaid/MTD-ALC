/*
 * CHANGES MADE:
 * 1. Added NULL check for sma to prevent potential null pointer dereference.
 */

static inline void sem_getref_and_unlock(struct sem_array *sma)
{
	if (sma != NULL) { /* FIX [CWE-690]: Prevent null pointer dereference */
		ipc_rcu_getref(sma);
		ipc_unlock(&(sma)->sem_perm);
	}
}