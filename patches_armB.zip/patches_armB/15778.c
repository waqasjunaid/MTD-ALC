/*
 * Changes made:
 * - Added a null pointer check for the context parameter to prevent potential crashes.
 */

static void unregisterBlobURLTask(void* context)
{
    if (!context) { /* FIX [CWE-690]: Prevent null pointer dereference */ 
        return;
    }
    OwnPtr<BlobRegistryContext> blobRegistryContext = adoptPtr(static_cast<BlobRegistryContext*>(context));
    if (blobRegistryContext && blobRegistryContext->url) { /* FIX [CWE-690]: Check for valid context and url before use */
        blobRegistry().unregisterBlobURL(blobRegistryContext->url);
    }
}