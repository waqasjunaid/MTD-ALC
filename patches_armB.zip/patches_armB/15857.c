/* 
 * CHANGES MADE:
 * - Added a check for the return value of malloc to prevent NULL pointer dereferences.
 */

SQLWCHAR* _multi_string_alloc_and_expand( LPCSTR in )
{
    SQLWCHAR *chr = NULL; /* FIX [CWE-476]: Initialize chr to NULL */
    int len = 0;
 
     if ( !in )
     {
        return in;
     }
     
     while ( in[ len ] != 0 || in[ len + 1 ] != 0 )
    {
        len ++;
    }

    chr = malloc(sizeof( SQLWCHAR ) * ( len + 2 )); /* FIX [CWE-476]: Check for NULL */
    if (!chr) { /* FIX [CWE-476]: Abort on NULL return value */
        abort();
    }

    len = 0;
    while ( in[ len ] != 0 || in[ len + 1 ] != 0 )
    {
        chr[ len ] = in[ len ];
        len ++;
    }
    chr[ len ++ ] = 0;
    chr[ len ++ ] = 0;

    return chr;
}