/*
 * CHANGES MADE:
 * None. The original function does not contain any identifiable vulnerabilities.
 */

LockContentsView::UserState::UserState(AccountId account_id)
    : account_id(account_id) {}