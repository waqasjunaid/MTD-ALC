/* 
 * CHANGES:
 * - Added bounds check for fmt to prevent null pointer dereference
 */

static void die(const char *fmt, ...) {
    if (fmt == NULL) { /* FIX [CWE-476]: prevent null pointer dereference */
        printf("Error: null format string\n");
        exit(EXIT_FAILURE);
    }
    
    va_list ap;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    if(fmt[strlen(fmt)-1] != '\n')
        printf("\n");
    exit(EXIT_FAILURE);
}