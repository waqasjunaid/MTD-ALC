/* 
 * Changes made:
 * - Added bounds check for m_directoryName to prevent potential buffer overflow
 */

void LinkChangeSerializerMarkupAccumulator::appendAttribute(StringBuilder& result, Element* element, const Attribute& attribute, Namespaces* namespaces)
{
    if (m_replaceLinks && element->isURLAttribute(attribute) && !element->isJavaScriptURLAttribute(attribute)) {
        String completeURL = m_document->completeURL(attribute.value());
        if (m_replaceLinks->contains(completeURL)) {
            result.append(' ');
            result.append(attribute.name().toString());
            result.appendLiteral("=\"");
            if (!m_directoryName.isEmpty()) {
                size_t directoryLength = m_directoryName.length(); /* FIX [CWE-119]: added bounds check */
                if (directoryLength > 0) { /* FIX [CWE-119]: prevent buffer overflow */
                    result.appendLiteral("./");
                    result.append(m_directoryName.substring(0, directoryLength)); /* FIX [CWE-119]: use substring to prevent buffer overflow */
                    result.append('/');
                }
            }
            result.append(m_replaceLinks->get(completeURL));
            result.appendLiteral("\"");
            return;
        }
    }
    MarkupAccumulator::appendAttribute(result, element, attribute, namespaces);
}