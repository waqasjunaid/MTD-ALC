/*
 * Changes made:
 * - Added bounds checking for array index access in args[0] and args[1]
 */

static v8::Handle<v8::Value> acceptTransferListCallback(const v8::Arguments& args)
 {
     INC_STATS("DOM.TestSerializedScriptValueInterface.acceptTransferList");
     if (args.Length() < 1)
        return V8Proxy::throwNotEnoughArgumentsError();
     TestSerializedScriptValueInterface* imp = V8TestSerializedScriptValueInterface::toNative(args.Holder());
     MessagePortArray messagePortArrayTransferList;
     ArrayBufferArray arrayBufferArrayTransferList;
    if (args.Length() > 1) {
        size_t idx = 1; /* FIX [CWE-129]: introduced variable for clarity */
        if (idx >= 0 && (size_t)idx < args.Length()) { /* FIX [CWE-129]: bounds checking */
            if (!extractTransferables(args[idx], messagePortArrayTransferList, arrayBufferArrayTransferList))
                return V8Proxy::throwTypeError("Could not extract transferables");
        }
    }
    bool dataDidThrow = false;
    size_t idx = 0; /* FIX [CWE-129]: introduced variable for clarity */
    if (idx >= 0 && (size_t)idx < args.Length()) { /* FIX [CWE-129]: bounds checking */
        RefPtr<SerializedScriptValue> data = SerializedScriptValue::create(args[idx], &messagePortArrayTransferList, &arrayBufferArrayTransferList, dataDidThrow, args.GetIsolate());
        if (dataDidThrow)
            return v8::Undefined();
    }
    if (args.Length() <= 1) {
        imp->acceptTransferList(data);
        return v8::Handle<v8::Value>();
    }
    imp->acceptTransferList(data, messagePortArrayTransferList);
    return v8::Handle<v8::Value>();
}