/*
 * CHANGES MADE:
 * 1. Added null checks before freeing memory to prevent potential crashes.
 */

static void TearDownTestCase() {
    if (source_data_) { /* FIX [CWE-690]: Prevent potential crash on free */ 
        vpx_free(source_data_);
        source_data_ = NULL;
    }
    if (reference_data_) { /* FIX [CWE-690]: Prevent potential crash on free */ 
        vpx_free(reference_data_);
        reference_data_ = NULL;
    }
}