/*
 * CHANGES:
 * - Added null checks for context and callbacks to prevent potential crashes.
 */

void LocalFileSystem::fileSystemNotAllowedInternal(
    PassRefPtrWillBeRawPtr<ExecutionContext> context,
    PassRefPtr<CallbackWrapper> callbacks)
{
    if (context && callbacks) { /* FIX [CWE-476]: Prevent null pointer dereferences */
        context->postTask(createCrossThreadTask(&reportFailure, callbacks->release(), FileError::ABORT_ERR));
    }
}