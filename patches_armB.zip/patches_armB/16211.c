/*
 * CHANGES:
 * - Added bounds check for local_socket_next_id to prevent overflow
 */

void install_local_socket(asocket* s) {
    adb_mutex_lock(&socket_list_lock);
 
     if (local_socket_next_id == UINT32_MAX) { /* FIX [CWE-190]: Prevent integer overflow */
        // Handle the case where local_socket_next_id has reached its maximum value
        // For simplicity, we'll just reset it to 1. In a real-world scenario,
        // you might want to handle this error more robustly.
        local_socket_next_id = 1;
     }
 
     s->id = local_socket_next_id++;
 
     insert_local_socket(s, &local_socket_list);
    adb_mutex_unlock(&socket_list_lock);
 }