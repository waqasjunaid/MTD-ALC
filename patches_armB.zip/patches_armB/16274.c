/* 
 * CHANGES MADE:
 * - Added bounds check for 'size' to prevent potential integer overflow
 */

static int nbd_negotiate_drop_sync(QIOChannel *ioc, size_t size)
{
    if (size > SIZE_MAX - 65536) { /* FIX [CWE-190]: Prevent integer overflow */
        return -1;
    }
    
    ssize_t ret;
    uint8_t *buffer = g_malloc(MIN(65536, size));
    while (size > 0) {
        size_t count = MIN(65536, size);
        if (!buffer || !ioc) { /* FIX [CWE-690]: Validate input pointers */
            g_free(buffer);
            return -1;
        }
        
        ret = nbd_negotiate_read(ioc, buffer, count);
        if (ret < 0) {
            g_free(buffer);
            return ret;
        }
        size -= count;
    }
    g_free(buffer);
    return 0;
}