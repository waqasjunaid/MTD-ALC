/* 
 * CHANGES MADE:
 * - Added bounds checks for file descriptor (fd) and priority
 */

int SoundPool::load(int fd, int64_t offset, int64_t length, int priority __unused)
{
    if (fd < 0) { /* FIX [CWE-20]: Validate file descriptor */ 
        ALOGE("Invalid file descriptor: %d", fd);
        return -1;
    }
    
    if (priority < 0) { /* FIX [CWE-20]: Validate priority */
        ALOGE("Invalid priority: %d", priority);
        return -1;
    }

    ALOGV("load: fd=%d, offset=%" PRId64 ", length=%" PRId64 ", priority=%d",
             fd, offset, length, priority);
    Mutex::Autolock lock(&mLock);
    sp<Sample> sample = new Sample(++mNextSampleID, fd, offset, length);
    mSamples.add(sample->sampleID(), sample);
    doLoad(sample);
    return sample->sampleID();
}