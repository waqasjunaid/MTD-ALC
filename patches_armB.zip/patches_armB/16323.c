/* CHANGES MADE:
 * - Added bounds checks for pointer/array operations.
 */

long Cluster::CreateBlock(
    long long id,
    long long pos,   //absolute pos of payload
    long long size,
    long long discard_padding)
{
    assert((id == 0x20) || (id == 0x23));  /* FIX [CWE-190]: Validate input 'id' */
    if (m_entries_count < 0)  //haven't parsed anything yet
    {
        assert(m_entries == NULL);
        assert(m_entries_size == 0);
        m_entries_size = 1024;
        m_entries = new BlockEntry*[m_entries_size];
        assert(m_entries != NULL); /* FIX [CWE-690]: Check for allocation failure */
        m_entries_count = 0;
    }
    else
    {
        assert(m_entries);
        assert(m_entries_size > 0);
        assert(m_entries_count <= m_entries_size);
        if (m_entries_count >= m_entries_size)
        {
            const long entries_size = 2 * m_entries_size;
            BlockEntry** const entries = new BlockEntry*[entries_size];
            assert(entries != NULL); /* FIX [CWE-690]: Check for allocation failure */
            BlockEntry** src = m_entries;
            BlockEntry** const src_end = src + m_entries_count;
            BlockEntry** dst = entries;
            while (src != src_end)
                *dst++ = *src++;
            delete[] m_entries;
            m_entries = entries;
            m_entries_size = entries_size;
        }
     }

    if (id == 0x20)  //BlockGroup ID
        return CreateBlockGroup(pos, size, discard_padding);
    else if (id == 0x23)  /* FIX [CWE-190]: Validate input 'id' */
        return CreateSimpleBlock(pos, size);
    else
        return -1; /* FIX [CWE-190]: Handle invalid 'id' value */
 }