/* 
 * CHANGES:
 * - No changes made as the function does not contain any obvious vulnerabilities.
 * The function appears to be a test case and does not handle user input or perform any operations that could lead to security issues.
 */

void FireInvalidateAll() {
    invalidation::AckHandle ack_handle("fakedata");
    EXPECT_CALL(mock_invalidation_client_, Acknowledge(ack_handle));
    client_.InvalidateAll(&mock_invalidation_client_, ack_handle);
}