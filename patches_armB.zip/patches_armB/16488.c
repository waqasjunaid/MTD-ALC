/*
 * CHANGES:
 * - Added null check for video to prevent potential null pointer dereference.
 */

void DecoderTest::RunLoop(CompressedVideoSource *video) {
  if (video == NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
    return;
  }
  vpx_codec_dec_cfg_t dec_cfg = {0};
  Decoder* const decoder = codec_->CreateDecoder(dec_cfg, 0);
   ASSERT_TRUE(decoder != NULL);
 
  for (video->Begin(); video->cxdata(); video->Next()) {
     PreDecodeFrameHook(*video, decoder);
    vpx_codec_err_t res_dec = decoder->DecodeFrame(video->cxdata(),
                                                   video->frame_size());
    if (res_dec != VPX_CODEC_OK) { /* FIX [CWE-252]: Check return value */
      ASSERT_EQ(VPX_CODEC_OK, res_dec) << decoder->DecodeError();
    }
 
     DxDataIterator dec_iter = decoder->GetDxData();
     const vpx_image_t *img = NULL;


     while ((img = dec_iter.Next()) != NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
       DecompressedFrameHook(*img, video->frame_number());
   }
   delete decoder;
 }