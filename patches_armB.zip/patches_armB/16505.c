/* 
 * CHANGES:
 * - Added null checks for m_surface and m_glContext to prevent potential crashes.
 */

void makeCurrent()
{
#if PLATFORM(QT)
    m_detachedContext = QOpenGLContext::currentContext();
    if (m_detachedContext) {
        /* FIX [CWE-476]: Prevent potential crash by checking for null pointer */
        if (m_detachedContext->surface()) 
            m_detachedSurface = m_detachedContext->surface();
    }
    if (m_surface && m_glContext) {
        /* FIX [CWE-476]: Prevent potential crash by checking for null pointer */
        if (m_surface.get() && m_glContext)
            m_glContext->makeCurrent(m_surface.get());
    }
#elif PLATFORM(EFL)
    m_detachedContext = glXGetCurrentContext();
    m_detachedSurface = glXGetCurrentDrawable();
    if (m_surface && m_glContext) {
        /* FIX [CWE-476]: Prevent potential crash by checking for null pointer */
        if (m_display && m_surface && m_glContext)
            glXMakeCurrent(m_display, m_surface, m_glContext);
    }
#endif
}