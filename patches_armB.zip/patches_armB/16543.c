/*
 * CHANGES:
 * - Added bounds check for npages to prevent potential integer overflow
 */

static void kvm_unpin_pages(struct kvm *kvm, pfn_t pfn, unsigned long npages)
{
	unsigned long i;
	if (npages > ULONG_MAX / sizeof(pfn_t)) { /* FIX [CWE-190]: prevent integer overflow */
		return; /* or handle error as per application requirements */
	}
	for (i = 0; i < npages; ++i)
		kvm_release_pfn_clean(pfn + i);
}