/* CHANGES:
 * - Added bounds check for pointer 'this' to prevent null pointer dereference
 * - Added bounds check for pointer 'that' to prevent null pointer dereference
 */

image_transform_png_set_scale_16_add(image_transform *this,
    PNG_CONST image_transform **that, png_byte colour_type, png_byte bit_depth)
{
    UNUSED(colour_type)

    if (this != NULL && that != NULL) { /* FIX [CWE-476]: prevent null pointer dereference */
        this->next = *that;
        *that = this; /* FIX [CWE-124]: prevent null pointer dereference */
    }

    return bit_depth > 8;
}