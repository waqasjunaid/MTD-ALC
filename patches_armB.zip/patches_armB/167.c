/* 
 * CHANGES:
 * - Added bounds check for channel_name to prevent potential buffer overflow
 */

bool UnprivilegedProcessDelegate::CreateConnectedIpcChannel(
    const std::string& channel_name,
    IPC::Listener* delegate,
    ScopedHandle* client_out,
    scoped_ptr<IPC::ChannelProxy>* server_out) {
  if (channel_name.empty()) { /* FIX [CWE-119]: prevent empty string */ 
    return false;
  }
  
  scoped_ptr<IPC::ChannelProxy> server;
  if (!CreateIpcChannel(channel_name, kDaemonIpcSecurityDescriptor,
                        io_task_runner_, delegate, &server)) {
    return false;
  }
  std::string pipe_name(kChromePipeNamePrefix);
  pipe_name.append(channel_name);
  
  // UTF8ToUTF16 can potentially throw an exception if the input string is too large
  try { /* FIX [CWE-120]: catch potential exception */
    ScopedHandle client;
    SECURITY_ATTRIBUTES security_attributes;
    security_attributes.nLength = sizeof(security_attributes);
    security_attributes.lpSecurityDescriptor = NULL;
    security_attributes.bInheritHandle = TRUE;
    client.Set(CreateFile(UTF8ToUTF16(pipe_name).c_str(),
                          GENERIC_READ | GENERIC_WRITE,
                          0,
                          &security_attributes,
                          OPEN_EXISTING,
                          SECURITY_SQOS_PRESENT | SECURITY_IDENTIFICATION |
                              FILE_FLAG_OVERLAPPED,
                          NULL));
    if (!client.IsValid())
      return false;
    *client_out = client.Pass();
    *server_out = server.Pass();
    return true;
  } catch (...) { /* FIX [CWE-120]: handle exception */
    return false;
  }
}