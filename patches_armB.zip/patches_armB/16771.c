/*
 * CHANGES MADE:
 * - Added bounds check for rel to prevent potential integer overflow
 */

static inline void jmp_rel(struct x86_emulate_ctxt *ctxt, int rel)
{
    /* FIX [CWE-190]: Prevent potential integer overflow by checking rel value */
    if (rel < INT_MIN || rel > INT_MAX) {
        /* Handle error: invalid relative jump offset */
        return;
    }
    assign_eip_near(ctxt, ctxt->_eip + rel);
}