/*
 * CHANGES:
 * - Added bounds check for indx and size to prevent potential out-of-bounds access.
 */

static int set_registers(rtl8150_t * dev, u16 indx, u16 size, void *data)
{
	if (indx >= RTL8150_MAX_REGS || size > RTL8150_MAX_REG_SIZE) {
		return -EINVAL; /* FIX [CWE-119]: bounds check */
	}
	return usb_control_msg(dev->udev, usb_sndctrlpipe(dev->udev, 0),
			       RTL8150_REQ_SET_REGS, RTL8150_REQT_WRITE,
			       indx, 0, data, size, 500);
}