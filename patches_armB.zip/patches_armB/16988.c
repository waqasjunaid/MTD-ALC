/* 
 * CHANGES:
 * - Added null check for 'window' to prevent potential null pointer dereference.
 */

~OffScreenRootWindow()
{
    if (!--refCount) {
#if PLATFORM(QT)
        if (window) { /* FIX [CWE-476]: Prevent null pointer dereference */
            delete window;
            window = 0;
        }
#elif PLATFORM(EFL)
        if (display && window) { /* FIX [CWE-476]: Prevent null pointer dereference */
            XUnmapWindow(display, window);
            XDestroyWindow(display, window);
        }
#endif
    }
}