/*
 * CHANGES:
 * - Added null check for input 'string' to prevent potential null pointer dereference.
 */

cJSON *cJSON_CreateString( const char *string )
{
	cJSON *item = cJSON_New_Item();
	if ( string && item ) { /* FIX [CWE-476]: Prevent null pointer dereference */
		item->type = cJSON_String;
		item->valuestring = cJSON_strdup( string );
	}
	return item;
}