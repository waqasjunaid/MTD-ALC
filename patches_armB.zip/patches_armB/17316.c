/*
 * Changes made:
 * - Added bounds check for lineIndex to prevent out-of-bounds access.
 */

static inline bool shouldSetStrutOnBlock(const LayoutBlockFlow& block, const RootInlineBox& lineBox, LayoutUnit lineLogicalOffset, int lineIndex, LayoutUnit remainingLogicalHeight)
{
    bool wantsStrutOnBlock = false;
    if (!block.style()->hasAutoOrphans() && block.style()->orphans() >= 0 && lineIndex >= 0 && block.style()->orphans() >= lineIndex) { /* FIX [CWE-129]: Added bounds check for lineIndex */
        wantsStrutOnBlock = true;
    } else if (lineBox == block.firstRootBox() && lineLogicalOffset == block.borderAndPaddingBefore()) {
        LayoutUnit lineHeight = lineBox.lineBottomWithLeading() - lineBox.lineTopWithLeading();
        LayoutUnit totalLogicalHeight = lineHeight + std::max<LayoutUnit>(0, lineLogicalOffset);
        LayoutUnit pageLogicalHeightAtNewOffset = block.pageLogicalHeightForOffset(lineLogicalOffset + remainingLogicalHeight);
         if (totalLogicalHeight < pageLogicalHeightAtNewOffset)
             wantsStrutOnBlock = true;
     }
    if (!wantsStrutOnBlock || block.isOutOfFlowPositioned())
        return false;
    LayoutBlock* containingBlock = block.containingBlock();
    return containingBlock && containingBlock->isLayoutBlockFlow();
 }