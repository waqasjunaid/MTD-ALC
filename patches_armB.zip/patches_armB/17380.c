/*
 * CHANGES MADE:
 * - Added null pointer checks for visitor and its members
 */

void FrameLoader::Trace(blink::Visitor* visitor) {
  if (visitor) { /* FIX [CWE-690]: prevent null pointer dereference */
    visitor->Trace(frame_);
    visitor->Trace(progress_tracker_);
    visitor->Trace(document_loader_);
    visitor->Trace(provisional_document_loader_);
  }
}