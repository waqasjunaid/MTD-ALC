/* CHANGES:
 * - Added bounds check for pointer 'this' to prevent null pointer dereference.
 * - Added bounds check for pointer 'that' to prevent null pointer dereference.
 */

image_transform_png_set_strip_16_add(image_transform *this,
    PNG_CONST image_transform **that, png_byte colour_type, png_byte bit_depth)
{
    UNUSED(colour_type)

    if (this == NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */ 
        return 0; /* or handle error as per application requirements */
    }

    if (that == NULL || *that == NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */ 
        return 0; /* or handle error as per application requirements */
    }

    this->next = *that;
    *that = this;

    return bit_depth > 8;
}