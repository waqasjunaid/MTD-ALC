/* 
 * CHANGES:
 * - Added bounds check for block_size_ to prevent potential buffer overflow
 */

void VarianceTest<VarianceFunctionType>::ZeroTest() {
  if (block_size_ > 0) { /* FIX [CWE-787]: added bounds check */
    for (int i = 0; i <= 255; ++i) {
      memset(src_, i, block_size_);
      for (int j = 0; j <= 255; ++j) {
        memset(ref_, j, block_size_);
        unsigned int sse;
        unsigned int var;
        REGISTER_STATE_CHECK(var = variance_(src_, width_, ref_, width_, &sse));
        EXPECT_EQ(0u, var) << "src values: " << i << "ref values: " << j;
      }
    }
  } else { /* FIX [CWE-787]: added check for invalid block_size_ */
    // handle error or throw exception
  }
}