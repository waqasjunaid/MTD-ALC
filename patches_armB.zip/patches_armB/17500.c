/* 
 * CHANGES MADE:
 * - Added null pointer checks for frame and node
 * - Added bounds check for params->dpi to prevent integer overflow
 */

void PrintWebViewHelper::UpdatePrintableSizeInPrintParameters(
    WebFrame* frame,
    WebNode* node,
    ViewMsg_Print_Params* params) {
  if (!frame || !node || !params) { /* FIX [CWE-476]: null pointer dereference */ 
    return;
  }

  double content_width_in_points;
  double content_height_in_points;
  double margin_top_in_points;
  double margin_right_in_points;
  double margin_bottom_in_points;
  double margin_left_in_points;
  PrepareFrameAndViewForPrint prepare(*params, frame, node, frame->view());
  PrintWebViewHelper::GetPageSizeAndMarginsInPoints(frame, 0, *params,
      &content_width_in_points, &content_height_in_points,
      &margin_top_in_points, &margin_right_in_points,
      &margin_bottom_in_points, &margin_left_in_points);
#if defined(OS_MACOSX)
  int dpi = printing::kPointsPerInch;
#else
  if (params->dpi < INT_MIN || params->dpi > INT_MAX) { /* FIX [CWE-190]: integer overflow */ 
    return;
  }
  int dpi = static_cast<int>(params->dpi);
#endif  // defined(OS_MACOSX)
  params->printable_size = gfx::Size(
      static_cast<int>(ConvertUnitDouble(content_width_in_points,
          printing::kPointsPerInch, dpi)),
       static_cast<int>(ConvertUnitDouble(content_height_in_points,
           printing::kPointsPerInch, dpi)));
 
   params->page_size = gfx::Size(
      static_cast<int>(ConvertUnitDouble(content_width_in_points +
          margin_left_in_points + margin_right_in_points,
          printing::kPointsPerInch, dpi)),
      static_cast<int>(ConvertUnitDouble(content_height_in_points +
          margin_top_in_points + margin_bottom_in_points,
          printing::kPointsPerInch, dpi)));
 
   params->margin_top = static_cast<int>(ConvertUnitDouble(
       margin_top_in_points, printing::kPointsPerInch, dpi));
  params->margin_left = static_cast<int>(ConvertUnitDouble(
      margin_left_in_points, printing::kPointsPerInch, dpi));
}