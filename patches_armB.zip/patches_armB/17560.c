/* 
 * Changes made:
 * - Added bounds checking for name_len
 */

static int svc_can_register(const uint16_t *name, size_t name_len, pid_t spid, uid_t uid)
{
    const char *perm = "add";
 
    if (uid >= AID_APP) {
         return 0; /* Don't allow apps to register services */
     }
 
    if (name == NULL || name_len == 0) { /* FIX [CWE-119]: null pointer dereference and zero-length buffer */
        return 0;
    }

    char *str_name = str8(name, name_len);
    if (str_name == NULL) { /* FIX [CWE-391]: unchecked return value */
        return 0;
    }

    int ret = check_mac_perms_from_lookup(spid, uid, perm, str_name) ? 1 : 0;

    free(str_name); /* FIX [CWE-401]: memory leak */

    return ret;
}