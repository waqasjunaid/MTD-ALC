/*
 * CHANGES:
 * - Added null pointer check for web_contents before calling Observe
 */

FrameImpl::FrameImpl(std::unique_ptr<content::WebContents> web_contents,
                     chromium::web::FrameObserverPtr observer)
    : web_contents_(std::move(web_contents)), observer_(std::move(observer)) {
  if (web_contents_) { /* FIX [CWE-476]: prevent null pointer dereference */
    Observe(web_contents.get());
  }
}