/* CHANGES MADE:
 * - Added null pointer check for icon_ to prevent potential null pointer dereference.
 */

void TranslateInfoBarBase::Layout() {
  InfoBar::Layout();
 
  if (icon_) { /* FIX [CWE-476]: Prevent null pointer dereference */
    gfx::Size icon_ps = icon_->GetPreferredSize();
    icon_->SetBounds(InfoBar::kHorizontalPadding, InfoBar::OffsetY(this, icon_ps),
        icon_ps.width(), icon_ps.height());
  }
}