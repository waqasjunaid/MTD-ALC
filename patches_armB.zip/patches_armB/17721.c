/* CHANGES MADE:
 * - Added bounds check for little and bigone pointers
 */

static bool tailmatch(const char *little, const char *bigone)
{
  if(!little || !bigone) /* FIX [CWE-690]: null pointer dereference */
    return FALSE;

  size_t littlelen = strlen(little);
  size_t biglen = strlen(bigone);

  if(littlelen > biglen)
    return FALSE;

  if(biglen < littlelen) /* FIX [CWE-125]: out-of-bounds read */
    return FALSE;

  return Curl_raw_equal(little, bigone+biglen-littlelen) ? TRUE : FALSE;
}