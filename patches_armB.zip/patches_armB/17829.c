/*
 * CHANGES:
 * - Added explicit bounds checks for pointer operations
 */

jas_matrix_t *jas_seq2d_create(int xstart, int ystart, int xend, int yend)
{
	jas_matrix_t *matrix;
	assert(xstart <= xend && ystart <= yend);
	if (xend < 0 || yend < 0) { /* FIX [CWE-129]: prevent negative size */ 
		return NULL; 
	}
	size_t width = (size_t)(xend - xstart); /* FIX [CWE-190]: prevent integer overflow */
	size_t height = (size_t)(yend - ystart);
	if (!(matrix = jas_matrix_create(height, width))) {
		return 0;
	}
	matrix->xstart_ = xstart;
	matrix->ystart_ = ystart;
	matrix->xend_ = xend;
	matrix->yend_ = yend;
	return matrix;
}