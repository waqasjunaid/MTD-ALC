/*
 * CHANGES MADE:
 * - Added explicit null check for widget before using it.
 */

void PartialMagnificationController::OnWidgetDestroying(views::Widget* widget) {
  if (widget != NULL) { /* FIX [CWE-476]: prevent null pointer dereference */
    DCHECK_EQ(widget, zoom_widget_);
  }
   RemoveZoomWidgetObservers();
  zoom_widget_ = NULL;
 }