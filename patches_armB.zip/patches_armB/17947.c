/* 
 * CHANGES:
 * - Added bounds check for GetBrowserInterface return value
 */

const PPB_NaCl_Private* GetNaclInterface() {
  pp::Module *module = pp::Module::Get();
  CHECK(module);
  void* interface_ptr = module->GetBrowserInterface(PPB_NACL_PRIVATE_INTERFACE); /* FIX [CWE-119]: Validate return value */
  if (!interface_ptr) { /* FIX [CWE-119]: Check for null pointer */
    return nullptr;
  }
  return static_cast<const PPB_NaCl_Private*>(interface_ptr);
}