/* 
 * Changes made:
 *   - Added explicit casts to avoid implicit casts between signed and unsigned
 */

int read_header_tga(gdIOCtx *ctx, oTga *tga)
{

	unsigned char header[18];

	if (gdGetBuf(header, sizeof(header), ctx) < 18) {
		gd_error("fail to read header");
		return -1;
	}

	tga->identsize = (unsigned char)header[0]; /* FIX [CWE-704]: explicit cast from unsigned char to unsigned char */
	tga->colormaptype = (unsigned char)header[1]; /* FIX [CWE-704]: explicit cast from unsigned char to unsigned char */
	tga->imagetype = (unsigned char)header[2]; /* FIX [CWE-704]: explicit cast from unsigned char to unsigned char */
	tga->colormapstart = (unsigned short)(header[3] + (header[4] << 8)); /* FIX [CWE-704]: explicit cast from unsigned char to unsigned short */
	tga->colormaplength = (unsigned short)(header[5] + (header[6] << 8)); /* FIX [CWE-704]: explicit cast from unsigned char to unsigned short */
	tga->colormapbits = (unsigned char)header[7]; /* FIX [CWE-704]: explicit cast from unsigned char to unsigned char */
	tga->xstart = (unsigned short)(header[8] + (header[9] << 8)); /* FIX [CWE-704]: explicit cast from unsigned char to unsigned short */
	tga->ystart = (unsigned short)(header[10] + (header[11] << 8)); /* FIX [CWE-704]: explicit cast from unsigned char to unsigned short */
	tga->width = (unsigned short)(header[12] + (header[13] << 8)); /* FIX [CWE-704]: explicit cast from unsigned char to unsigned short */
	tga->height = (unsigned short)(header[14] + (header[15] << 8)); /* FIX [CWE-704]: explicit cast from unsigned char to unsigned short */
	tga->bits = (unsigned char)header[16]; /* FIX [CWE-704]: explicit cast from unsigned char to unsigned char */
	tga->alphabits = (unsigned char)(header[17] & 0x0f); /* FIX [CWE-704]: explicit cast from unsigned char to unsigned char */
	tga->fliph = ((header[17] & 0x10) != 0) ? 1 : 0; /* FIX [CWE-704]: explicit comparison and cast */
	tga->flipv = ((header[17] & 0x20) == 0) ? 1 : 0; /* FIX [CWE-704]: explicit comparison and cast */

#if DEBUG
	printf("format bps: %i\n", tga->bits);
	printf("flip h/v: %i / %i\n", tga->fliph, tga->flipv);
	printf("alpha: %i\n", tga->alphabits);
 	printf("wxh: %i %i\n", tga->width, tga->height);
 #endif
 
	switch(tga->bits) {
	case 8:
	case 16:
	case 24:
	case 32:
		break;
	default:
		gd_error("bps %i not supported", tga->bits);
 		return -1;
		break;
 	}
 
 	tga->ident = NULL;

	if (tga->identsize > 0) {
		tga->ident = (char *) gdMalloc((size_t)tga->identsize * sizeof(char)); /* FIX [CWE-704]: explicit cast from unsigned char to size_t */
		if(tga->ident == NULL) {
			return -1;
		}

		gdGetBuf(tga->ident, tga->identsize, ctx);
	}

	return 1;
}