/* 
 * CHANGES MADE:
 * - Added bounds check for delegate_ to prevent null pointer dereference.
 */

void WebPluginImpl::didFinishLoadingFrameRequest(
     const WebURL& url, void* notify_data) {
   if (delegate_) { /* FIX [CWE-476]: Prevent null pointer dereference */
     delegate_->DidFinishLoadWithReason(
        url, NPRES_DONE, reinterpret_cast<intptr_t>(notify_data));
   }
 }