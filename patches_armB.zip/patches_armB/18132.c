/*
 * Changes made:
 * - Added explicit bounds check for multiplication overflow
 */

checked_xcalloc (size_t num, size_t size)
{
    if (SIZE_MAX / num < size) /* FIX [CWE-190]: prevent multiplication overflow */
        alloc_limit_assert ("checked_xcalloc", SIZE_MAX);
    else
        alloc_limit_assert ("checked_xcalloc", (num * size));
    return xcalloc (num, size);
}