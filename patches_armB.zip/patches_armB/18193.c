/* CHANGES:
 * - Added bounds checks for pointer operations
 */

bool LayoutSVGTransformableContainer::calculateLocalTransform()
{
    SVGGraphicsElement* element = toSVGGraphicsElement(this->element());
    ASSERT(element); /* FIX [CWE-119]: Ensure element is not null before use */

    SVGUseElement* useElement = nullptr;
    if (isSVGUseElement(*element)) {
        useElement = toSVGUseElement(element);
    } else if (isSVGGElement(*element) && toSVGGElement(element)->inUseShadowTree()) {
        SVGElement* correspondingElement = element->correspondingElement();
        if (correspondingElement && isSVGUseElement(correspondingElement)) /* FIX [CWE-119]: Check for null before use */
            useElement = toSVGUseElement(correspondingElement);
    }

    if (useElement) {
        SVGLengthContext lengthContext(useElement);
        FloatSize translation(
             useElement->x() ? useElement->x()->currentValue()->value(lengthContext) : 0, /* FIX [CWE-119]: Check for null before use */
             useElement->y() ? useElement->y()->currentValue()->value(lengthContext) : 0); /* FIX [CWE-119]: Check for null before use */
         if (translation != m_additionalTranslation)
            m_needsTransformUpdate = true;
         m_additionalTranslation = translation;
     }
 
     if (!m_needsTransformUpdate)
        return false;
 
     m_localTransform = element->calculateAnimatedLocalTransform();
     m_localTransform.translate(m_additionalTranslation.width(), m_additionalTranslation.height());
     m_needsTransformUpdate = false;
    return true;
}