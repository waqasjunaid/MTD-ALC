/* 
 * CHANGES MADE:
 * - Added bounds check for ExecutionContext pointer
 */

void LocalFileSystem::deleteFileSystem(ExecutionContext* context, FileSystemType type, PassOwnPtr<AsyncFileSystemCallbacks> callbacks)
{
    if (!context) { /* FIX [CWE-476]: null pointer dereference */ return; }
    RefPtrWillBeRawPtr<ExecutionContext> contextPtr(context);
     ASSERT(context->isDocument()); /* FIX [CWE-476]: bounds check for ExecutionContext pointer */
 
    RefPtr<CallbackWrapper> wrapper = adoptRef(new CallbackWrapper(callbacks));
     requestFileSystemAccessInternal(context,
         bind(&LocalFileSystem::deleteFileSystemInternal, this, contextPtr, type, wrapper),
         bind(&LocalFileSystem::fileSystemNotAllowedInternal, this, contextPtr, wrapper));
}