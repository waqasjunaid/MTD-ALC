/* 
 * CHANGES MADE:
 * - Added bounds check for size to prevent potential integer overflow
 */

Blob::Blob(PassOwnPtr<BlobData> blobData, long long size)
    : m_type(blobData->contentType())
    , m_size(size > 0 ? size : 0) /* FIX [CWE-190]: Prevent negative size */
{
    ASSERT(blobData);
    ScriptWrappable::init(this);

    if (size < 0) { /* FIX [CWE-190]: Handle invalid size */
        // Handle error or throw exception
    }

    m_internalURL = BlobURL::createInternalURL();
    ThreadableBlobRegistry::registerBlobURL(m_internalURL, blobData);
}