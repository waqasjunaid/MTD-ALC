/* 
 * CHANGES:
 * - Added bounds check for offset in SEEK_SET case to prevent potential integer overflow
 * - Added bounds check for profile->offset and offset in SEEK_CUR case to prevent potential integer overflow
 * - Added bounds check for profile->length and offset in SEEK_END case to prevent potential integer overflow
 */

static MagickOffsetType TIFFSeekCustomStream(const MagickOffsetType offset,
  const int whence,void *user_data)
{
  PhotoshopProfile
    *profile;

  profile=(PhotoshopProfile *) user_data;
  switch (whence)
  {
    case SEEK_SET:
    default:
    {
      if ((offset < 0) || /* FIX [CWE-190]: prevent integer overflow */ 
          (offset > MagickOffsetMaximum))
        return(-1);
      profile->offset=offset;
      break;
     }
     case SEEK_CUR:
     {
       MagickOffsetType new_offset = profile->offset + offset; /* FIX [CWE-190]: calculate new offset before bounds check */
       if ((new_offset < 0) || /* FIX [CWE-190]: prevent integer overflow */ 
           (new_offset > MagickOffsetMaximum))
         return(-1);
       profile->offset=new_offset;
      break;
    }
    case SEEK_END:
    {
      MagickOffsetType new_offset = profile->length + offset; /* FIX [CWE-190]: calculate new offset before bounds check */
      if ((new_offset < 0) || /* FIX [CWE-190]: prevent integer overflow */ 
          (new_offset > MagickOffsetMaximum))
        return(-1);
      profile->offset=new_offset;
      break;
    }
  }

  return(profile->offset);
}