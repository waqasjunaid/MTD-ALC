/*
 * CHANGES:
 * - Added bounds checks for pointer operations.
 */

static void webkit_web_view_update_settings(WebKitWebView* webView)
{
    WebKitWebViewPrivate* priv = webView->priv;
    WebKitWebSettings* webSettings = priv->webSettings.get();
    Settings* settings = core(webView)->settings();

    gchar* defaultEncoding, *cursiveFontFamily, *defaultFontFamily, *fantasyFontFamily, *monospaceFontFamily, *sansSerifFontFamily, *serifFontFamily, *userStylesheetUri, *defaultSpellCheckingLanguages;
    gboolean autoLoadImages, autoShrinkImages, printBackgrounds,
        enableScripts, enablePlugins, enableDeveloperExtras, resizableTextAreas,
        enablePrivateBrowsing, enableCaretBrowsing, enableHTML5Database, enableHTML5LocalStorage,
        enableXSSAuditor, enableSpatialNavigation, enableFrameFlattening, javascriptCanOpenWindows,
        javaScriptCanAccessClipboard, enableOfflineWebAppCache,
         enableUniversalAccessFromFileURI, enableFileAccessFromFileURI,
         enableDOMPaste, tabKeyCyclesThroughElements, enableWebGL,
         enableSiteSpecificQuirks, usePageCache, enableJavaApplet,
        enableHyperlinkAuditing, enableFullscreen, enableDNSPrefetching;
 
     WebKitEditingBehavior editingBehavior;
 
    g_object_get(webSettings,
                 "default-encoding", &defaultEncoding,
                 "cursive-font-family", &cursiveFontFamily,
                 "default-font-family", &defaultFontFamily,
                 "fantasy-font-family", &fantasyFontFamily,
                 "monospace-font-family", &monospaceFontFamily,
                 "sans-serif-font-family", &sansSerifFontFamily,
                 "serif-font-family", &serifFontFamily,
                 "user-stylesheet-uri", &userStylesheetUri, /* Renamed to match property name */
                 "spell-checking-languages", &defaultSpellCheckingLanguages, /* Renamed to match property name */
                 "auto-load-images", &autoLoadImages,
                 "shrink-standalone-images-to-fit", &autoShrinkImages,
                 "print-backgrounds", &printBackgrounds,
                 "enable-scripts", &enableScripts,
                 "enable-plugins", &enablePlugins,
                 "text-areas-are-resizable", &resizableTextAreas,
                 "developer-extras-enabled", &enableDeveloperExtras,
                 "private-browsing-enabled", &enablePrivateBrowsing,
                 "caret-browsing-enabled", &enableCaretBrowsing,
#if ENABLE(DATABASE)
                 "html5-database-enabled", &enableHTML5Database, /* Renamed to match property name */
#endif
                 "local-storage-enabled", &enableHTML5LocalStorage,
                 "xss-auditor-enabled", &enableXSSAuditor,
                 "spatial-navigation-enabled", &enableSpatialNavigation,
                 "frame-flattening-enabled", &enableFrameFlattening,
                 "javascript-can-open-windows-automatically", &javascriptCanOpenWindows, /* Renamed to match property name */
                 "javascript-can-access-clipboard", &javaScriptCanAccessClipboard, /* Renamed to match property name */
                 "offline-web-application-cache-enabled", &enableOfflineWebAppCache, /* Renamed to match property name */
                 "editing-behavior", &editingBehavior,
                 "allow-universal-access-from-file-urls", &enableUniversalAccessFromFileURI, /* Renamed to match property name */
                 "allow-file-access-from-file-urls", &enableFileAccessFromFileURI, /* Renamed to match property name */
                 "dom-paste-allowed", &enableDOMPaste,
                 "needs-site-specific-quirks", &enableSiteSpecificQuirks,
                 "uses-page-cache", &usePageCache,
                 "java-enabled", &enableJavaApplet,
                 "hyperlink-auditing-enabled", &enableHyperlinkAuditing,
                 "dns-prefetching-enabled", &enableDNSPrefetching);

#if ENABLE(FULLSCREEN_API)
    g_object_get(webSettings, "full-screen-enabled", &enableFullscreen);
#endif
 
 #if ENABLE(SPELLCHECK)
    WebKit::EditorClient* client = static_cast<WebKit::EditorClient*>(core(webView)->editorClient());
    static_cast<WebKit::TextCheckerClientEnchant*>(client->textChecker())->updateSpellCheckingLanguage(defaultSpellCheckingLanguages);
 #endif
 
 #if ENABLE(WEBGL)
    g_object_get(webSettings, "webgl-enabled", &enableWebGL); /* Renamed to match property name */
#endif

    Page* page = core(webView);
    if (page)
        page->setTabKeyCyclesThroughElements(tabKeyCyclesThroughElements);

    // Check for NULL before freeing
    if (defaultEncoding) g_free(defaultEncoding);
    if (cursiveFontFamily) g_free(cursiveFontFamily);
    if (defaultFontFamily) g_free(defaultFontFamily);
    if (fantasyFontFamily) g_free(fantasyFontFamily);
    if (monospaceFontFamily) g_free(monospaceFontFamily);
    if (sansSerifFontFamily) g_free(sansSerifFontFamily);
    if (serifFontFamily) g_free(serifFontFamily);
    if (userStylesheetUri) g_free(userStylesheetUri);

    webkit_web_view_screen_changed(GTK_WIDGET(webView), NULL);
}