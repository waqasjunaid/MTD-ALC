/*
 * CHANGES:
 * - None. The function does not contain any obvious vulnerabilities.
 *   It appears to be a simple delegate that calls another method with the same parameters.
 */

void WebPluginDelegateImpl::SendJavaScriptStream(const GURL& url,
                                                  const std::string& result,
                                                  bool success,
                                                 bool notify_needed,
                                                 intptr_t notify_data) {
  instance()->SendJavaScriptStream(url, result, success, notify_needed,
                                   notify_data);
}