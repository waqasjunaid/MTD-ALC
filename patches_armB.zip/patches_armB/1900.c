/* 
 * CHANGES MADE:
 * - Added bounds check for contents_point to prevent potential out-of-bounds access.
 */

void FrameSelection::MoveRangeSelectionExtent(const IntPoint& contents_point) {
  if (ComputeVisibleSelectionInDOMTree().IsNone())
    return;

  // Validate contents_point coordinates
  int x = std::max(0, std::min(contents_point.X(), frame_->GetContentsWidth())); /* FIX [CWE-119]: bounds check */
  int y = std::max(0, std::min(contents_point.Y(), frame_->GetContentsHeight())); /* FIX [CWE-119]: bounds check */

  SetSelection(
      SelectionInDOMTree::Builder(
          GetGranularityStrategy()->UpdateExtent(IntPoint(x, y), frame_)) /* FIX [CWE-119]: use validated coordinates */
         .SetIsHandleVisible(true)
         .Build(),
      SetSelectionData::Builder()
         .SetShouldCloseTyping(true)
         .SetShouldClearTypingStyle(true)
         .SetDoNotClearStrategy(true)
         .SetSetSelectionBy(SetSelectionBy::kUser)
         .Build());
}