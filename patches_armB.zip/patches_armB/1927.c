/* 
 * Changes made:
 * None. The function does not contain any obvious vulnerabilities.
 * It performs a simple bitwise operation and returns the result as a boolean value.
 */

bool Block::IsInvisible() const
{
    return bool(int(m_flags & 0x08) != 0);
}