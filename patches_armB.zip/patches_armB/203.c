/* 
 * Changes made:
 * 1. Added bounds check for key string to prevent potential null pointer dereference.
 */

SchedulerObject::_continue(std::string key, std::string &/*reason*/, std::string &text)
 {
        if (key.empty()) { /* FIX [CWE-476]: Prevent null pointer dereference */
                dprintf(D_FULLDEBUG, "Remove: Key string is empty\n");
                text = "Invalid Id";
                return false;
        }

        PROC_ID id = getProcByString(key.c_str());
       if (id.cluster < 0 || id.proc < 0) {
                dprintf(D_FULLDEBUG, "Remove: Failed to parse id: %s\n", key.c_str());
                text = "Invalid Id";
                return false;
	}

	scheduler.enqueueActOnJobMyself(id,JA_CONTINUE_JOBS,true);

	return true;
}