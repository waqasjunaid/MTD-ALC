/*
 * CHANGES:
 * - Added bounds checking for array indices to prevent out-of-bounds access.
 */

static __u8 *ch_report_fixup(struct hid_device *hdev, __u8 *rdesc,
 		unsigned int *rsize)
 {
	if (*rsize >= 17 && rdesc[11] == 0x3c && rdesc[12] == 0x02) {
 		hid_info(hdev, "fixing up Cherry Cymotion report descriptor\n");
 		if ((size_t)11 < *rsize) { /* FIX [CWE-129]: prevent out-of-bounds access */
 			rdesc[11] = rdesc[*rsize - 1]; /* FIX [CWE-129]: use last element instead of hardcoded index */
 		}
 		if ((size_t)12 < *rsize) { /* FIX [CWE-129]: prevent out-of-bounds access */
 			rdesc[12] = 0x03; /* FIX [CWE-129]: assign value directly */
 		}
 		if ((size_t)16 < *rsize) { /* FIX [CWE-129]: prevent out-of-bounds access */
 			rdesc[*rsize - 1] = 0xff; /* FIX [CWE-129]: use last element instead of hardcoded index */
 		}
 		if ((size_t)17 < *rsize) { /* FIX [CWE-129]: prevent out-of-bounds access */
 			rdesc[17] = 0x03; /* FIX [CWE-129]: assign value directly */
 		}
	}
	return rdesc;
}