/*
 * CHANGES:
 * - Added bounds check for pointer operation on frame_host_
 */

void RenderFrameDevToolsAgentHost::DestroyOnRenderFrameGone() {
   scoped_refptr<RenderFrameDevToolsAgentHost> protect(this);
   if (IsAttached())
     RevokePolicy();
  ForceDetachAllClients();
   if (frame_host_) /* FIX [CWE-476]: Added bounds check for pointer operation */
     frame_host_ = nullptr;
   agent_ptr_.reset();
   SetFrameTreeNode(nullptr);
  Release();
}