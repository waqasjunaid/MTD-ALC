/*
 * CHANGES:
 * - Added explicit bounds checks around pointer operations
 */

void bdt_enable(void)
{
    if (sBtInterface == NULL) { /* FIX [CWE-690]: null pointer dereference */
        bdt_log("Error: sBtInterface is null");
        return;
    }

    bdt_log("ENABLE BT");

    if (bt_enabled) {
        bdt_log("Bluetooth is already enabled");
        return;
    }

    status = sBtInterface->enable();

    check_return_status(status);
}