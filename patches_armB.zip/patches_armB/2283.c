/*
 * Changes made:
 * - Added bounds check for pointer 'surface' before calling 'QueueFrame'
 */

void OffscreenCanvasFrameReceiverImpl::SubmitCompositorFrame(
    const cc::SurfaceId& surface_id,
    cc::CompositorFrame frame) {
  cc::Surface* surface = GetSurfaceManager()->GetSurfaceForId(surface_id);
  if (surface != nullptr /* FIX [CWE-690]: Ensure pointer is not null */) {
    surface->QueueFrame(std::move(frame), base::Closure());
  }
}