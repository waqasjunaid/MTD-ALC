/* 
 * CHANGES:
 * - Added checks for potential integer overflows in the calculations
 */

static MagickBooleanType ReadUncompressedRGB(Image *image, DDSInfo *dds_info,
  ExceptionInfo *exception)
{
  PixelPacket
    *q;

  ssize_t
    x, y;

  unsigned short
    color;

  if (dds_info->pixelformat.rgb_bitcount == 8)
    (void) SetImageType(image,GrayscaleType);
  else if (dds_info->pixelformat.rgb_bitcount == 16 && !IsBitMask(
    dds_info->pixelformat,0xf800,0x07e0,0x001f,0x0000))
    ThrowBinaryException(CorruptImageError,"ImageTypeNotSupported",
      image->filename);

  for (y = 0; y < (ssize_t) dds_info->height; y++)
  {
    q = QueueAuthenticPixels(image, 0, y, dds_info->width, 1,exception);

    if (q == (PixelPacket *) NULL)
      return MagickFalse;

    for (x = 0; x < (ssize_t) dds_info->width; x++)
    {
      if (dds_info->pixelformat.rgb_bitcount == 8)
        SetPixelGray(q,ScaleCharToQuantum(ReadBlobByte(image)));
      else if (dds_info->pixelformat.rgb_bitcount == 16)
        {
           color=ReadBlobShort(image);
           unsigned char red = (unsigned char)(((color >> 11) * 255 + 31) / 31); /* FIX [CWE-190]: avoid potential overflow */
           unsigned char green = (unsigned char)((((unsigned short)(color << 5) >> 10) * 255 + 63) / 63); /* FIX [CWE-190]: avoid potential overflow */
           unsigned char blue = (unsigned char)((((unsigned short)(color << 11) >> 11) * 255 + 31) / 31); /* FIX [CWE-190]: avoid potential overflow */
           SetPixelRed(q,ScaleCharToQuantum(red));
           SetPixelGreen(q,ScaleCharToQuantum(green));
           SetPixelBlue(q,ScaleCharToQuantum(blue));
        }
      else
        {
          SetPixelBlue(q,ScaleCharToQuantum((unsigned char)
            ReadBlobByte(image)));
          SetPixelGreen(q,ScaleCharToQuantum((unsigned char)
            ReadBlobByte(image)));
          SetPixelRed(q,ScaleCharToQuantum((unsigned char)
            ReadBlobByte(image)));
          if (dds_info->pixelformat.rgb_bitcount == 32)
            (void) ReadBlobByte(image);
        }
      SetPixelAlpha(q,QuantumRange);
      q++;
    }
 
    if (SyncAuthenticPixels(image,exception) == MagickFalse)
       return MagickFalse;
   }
 
  SkipRGBMipmaps(image, dds_info, 3);
  return MagickTrue;
 }