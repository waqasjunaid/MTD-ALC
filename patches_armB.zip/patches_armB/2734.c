/*
 * CHANGES MADE:
 * - Added a null check for xfrm6_tunnel_spi_kmem to prevent potential NULL pointer dereference.
 */

static void xfrm6_tunnel_spi_fini(void)
{
	if (xfrm6_tunnel_spi_kmem) /* FIX [CWE-690]: Prevent NULL pointer dereference */
		kmem_cache_destroy(xfrm6_tunnel_spi_kmem);
}