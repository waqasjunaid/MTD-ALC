/* 
 * CHANGES MADE:
 * - Added input validation for cached_resource
 */

String InspectorPageAgent::CachedResourceTypeJson(
    const Resource& cached_resource) {
  if (!cached_resource.is_valid()) { /* FIX [CWE-20]: Validate input */
    return "";
  }
  return ResourceTypeJson(CachedResourceType(cached_resource));
}