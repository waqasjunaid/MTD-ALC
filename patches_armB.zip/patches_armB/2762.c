/* 
 * CHANGES MADE:
 * - Fixed struct casting issue by using a union to hold the reply data.
 */

XGetModifierMapping(register Display *dpy)
{
    union {
        xGetModifierMappingReply rep;
        char pad[4];
    } u; /* FIX [CWE-843]: use a union for type-safe polymorphism */
    register xReq *req;
    unsigned long nbytes;
    XModifierKeymap *res;

    LockDisplay(dpy);
     GetEmptyReq(GetModifierMapping, req);
     (void) _XReply (dpy, (xReply *)&u.rep, 0, xFalse); /* FIX [CWE-843]: cast to union member */
 
    if (u.rep.length < (INT_MAX >> 2)) {
 	nbytes = (unsigned long)u.rep.length << 2; /* FIX [CWE-843]: access through union member */
 	res = Xmalloc(sizeof (XModifierKeymap));
 	if (res)
    } else
	res = NULL;
    if ((! res) || (! res->modifiermap)) {
	Xfree(res);
	res = (XModifierKeymap *) NULL;
	_XEatDataWords(dpy, u.rep.length); /* FIX [CWE-843]: access through union member */
    } else {
	_XReadPad(dpy, (char *) res->modifiermap, (long) nbytes);
	res->max_keypermod = u.rep.numKeyPerModifier; /* FIX [CWE-843]: access through union member */
    }

    UnlockDisplay(dpy);
    SyncHandle();
    return (res);
}