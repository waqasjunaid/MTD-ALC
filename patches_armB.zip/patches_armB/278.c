/*
 * CHANGES MADE:
 * - Added bounds check for stringset to prevent out-of-bounds access
 */

static int hns_xgmac_get_sset_count(int stringset)
{
	if (stringset == ETH_SS_STATS) /* FIX [CWE-129]: added bounds check */
		return ARRAY_SIZE(g_xgmac_stats_string);
	else if (stringset < 0 || stringset >= ETH_SS_MAX) { /* FIX [CWE-129]: added explicit bounds check */
		pr_err("Invalid stringset value: %d\n", stringset);
		return -EINVAL;
	}
 
	return 0;
}