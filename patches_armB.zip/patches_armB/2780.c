/* 
 * CHANGES:
 * - Added null pointer check for context to prevent potential null pointer dereference.
 */

static void addDataToStreamTask(void* context)
{
    if (context == nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
        return;
    }
    
    OwnPtr<BlobRegistryContext> blobRegistryContext = adoptPtr(static_cast<BlobRegistryContext*>(context));
    if (!blobRegistryContext->url || !blobRegistryContext->streamData) { /* FIX [CWE-476]: Validate input pointers */
        return;
    }
    
    blobRegistry().addDataToStream(blobRegistryContext->url, blobRegistryContext->streamData);
}