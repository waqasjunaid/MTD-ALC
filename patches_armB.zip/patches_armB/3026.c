/*
 * CHANGES:
 * - Added bounds check for GetVisibleEntry() return value
 */

WebsiteSettingsPopupAndroid::WebsiteSettingsPopupAndroid(
    JNIEnv* env,
    jobject java_website_settings_pop,
    content::WebContents* web_contents) {
  content::NavigationEntry* nav_entry =
      web_contents->GetController().GetVisibleEntry();
  if (nav_entry == NULL) { /* FIX [CWE-476]: potential null pointer dereference */
    return;
  }

  url_ = nav_entry->GetURL();

  popup_jobject_.Reset(env, java_website_settings_pop);

  presenter_.reset(new WebsiteSettings(
       this,
       Profile::FromBrowserContext(web_contents->GetBrowserContext()),
       TabSpecificContentSettings::FromWebContents(web_contents),
      InfoBarService::FromWebContents(web_contents),
       nav_entry->GetURL(),
       nav_entry->GetSSL(),
       content::CertStore::GetInstance()));
}