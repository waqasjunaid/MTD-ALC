/*
 * Changes made:
 * - Added bounds check for args.Length() to prevent potential out-of-bounds access.
 */

static v8::Handle<v8::Value> enabledAtRuntimeMethod2Callback(const v8::Arguments& args)
{
    INC_STATS("DOM.TestObj.enabledAtRuntimeMethod2");
    if (args.Length() < 1) {
        return V8Proxy::throwNotEnoughArgumentsError();
    }
    TestObj* imp = V8TestObj::toNative(args.Holder());
    if (args.Length() >= 1 && !V8int::HasInstance(MAYBE_MISSING_PARAMETER(args, 0, DefaultIsUndefined))) { /* FIX [CWE-628]: Validate input type */
        return V8Proxy::throwTypeError("Invalid argument type");
    }
    EXCEPTION_BLOCK(int, intArg, V8int::toNative(v8::Handle<v8::Object>::Cast(MAYBE_MISSING_PARAMETER(args, 0, DefaultIsUndefined))));
    imp->enabledAtRuntimeMethod2(intArg);
    return v8::Handle<v8::Value>();
}