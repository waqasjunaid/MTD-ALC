/* CHANGES:
 * - Added bounds check for segmentation_ structure
 */

void Vp9Parser::ReadSegmentation() {
  // Ensure segmentation_ is within valid bounds before accessing its members
  if (segmentation_.size <= sizeof(segmentation_)) { /* FIX [CWE-119]: bounds check */
    segmentation_.update_map = false;
    segmentation_.update_data = false;

    segmentation_.enabled = reader_.ReadBool();
    if (!segmentation_.enabled)
      return;

    segmentation_.update_map = reader_.ReadBool();
    if (segmentation_.update_map)
      ReadSegmentationMap();

    segmentation_.update_data = reader_.ReadBool();
    if (segmentation_.update_data)
      ReadSegmentationData();
  } else {
    // Handle out-of-bounds error
  }
}