/*
 * CHANGES:
 * - Added bounds checks for FloatRect coordinates
 */

void AddSimpleRectChunk(TestPaintArtifact& artifact) {
    const float x = 100.0f;
    const float y = 100.0f;
    const float width = 200.0f;
    const float height = 100.0f;

    if (x < 0 || y < 0 || width <= 0 || height <= 0) {
        // Handle invalid rectangle coordinates
        return; /* FIX [CWE-119]: bounds check for FloatRect */
    }

    artifact
        .Chunk(TransformPaintPropertyNode::Root(),
               ClipPaintPropertyNode::Root(), EffectPaintPropertyNode::Root())
         .RectDrawing(FloatRect(x, y, width, height), Color::kBlack);
}