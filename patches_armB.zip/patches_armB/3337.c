/*
 * CHANGES:
 * - Added NULL pointer check for user
 */

int ipmi_destroy_user(struct ipmi_user *user)
{
	if (user == NULL) { /* FIX [CWE-690]: Prevent NULL pointer dereference */
		return -EINVAL; /* FIX [CWE-690]: Return error on invalid input */
	}

	_ipmi_destroy_user(user);
 
	cleanup_srcu_struct(&user->release_barrier);
 	kref_put(&user->refcount, free_user);
 
 	return 0;
}