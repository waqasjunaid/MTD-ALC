/*
 * CHANGES MADE:
 * - Added input validation for server_whitelist
 */

void HttpAuthFilterWhitelist::SetWhitelist(
    const std::string& server_whitelist) {
  if (!server_whitelist.empty()) { /* FIX [CWE-20]: Validate non-empty input */
    rules_.ParseFromString(server_whitelist);
  } else {
    // Handle empty input, e.g., log an error or throw an exception
  }
}