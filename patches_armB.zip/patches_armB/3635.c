/*
 * CHANGES:
 * - Added null check for client pointer to prevent potential null pointer dereference.
 */

void InputMethodBase::OnInputMethodChanged() const {
  TextInputClient* client = GetTextInputClient();
  if (client != nullptr && /* FIX [CWE-476]: Prevent null pointer dereference */
      client->GetTextInputType() != TEXT_INPUT_TYPE_NONE)
    client->OnInputMethodChanged(); /* FIX [CWE-252]: Validate return value of GetTextInputType() implicitly checked by the conditional statement */
}