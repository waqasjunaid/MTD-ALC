/* CHANGES MADE:
 * - Replaced system() calls with execve() to prevent shell interpolation
 */

rs_filter_graph(RSFilter *filter)
{
    g_return_if_fail(RS_IS_FILTER(filter));
    GString *str = g_string_new("digraph G {\n");
 
    rs_filter_graph_helper(str, filter);
 
    g_string_append_printf(str, "}\n");
    g_file_set_contents("/tmp/rs-filter-graph", str->str, str->len, NULL);

    /* FIX [CWE-78]: Avoid shell interpolation by using execve() instead of system() */
    execlp("dot", "dot", "-Tpng", "/tmp/rs-filter-graph.png", "/tmp/rs-filter-graph", (char *)NULL);
    if (errno != 0)
        g_warning("Calling dot failed");

    /* FIX [CWE-78]: Avoid shell interpolation by using execve() instead of system() */
    execlp("gnome-open", "gnome-open", "/tmp/rs-filter-graph.png", (char *)NULL);
    if (errno != 0)
        g_warning("Calling gnome-open failed.");

    g_string_free(str, TRUE);
}