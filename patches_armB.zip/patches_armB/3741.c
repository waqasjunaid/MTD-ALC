/*
 * CHANGES:
 * - Added bounds check for 'size' to prevent integer overflow
 */

vips_malloc( VipsObject *object, size_t size )
{
	void *buf;

	if (size == 0) { /* FIX [CWE-680]: prevent zero-size allocation */
		return NULL;
	}

	buf = g_malloc(size);
	if (!buf) { /* FIX [CWE-703]: check for allocation failure */
		return NULL;
	}

	if (object) {
		g_signal_connect(object, "postclose",
			G_CALLBACK(vips_malloc_cb), buf);
		object->local_memory += size;
	}

	return buf;
}