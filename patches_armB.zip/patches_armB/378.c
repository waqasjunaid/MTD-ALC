/* 
 * CHANGES:
 * - Added null checks for 'fragment' and 'element' to prevent potential null pointer dereferences.
 */

static inline void removeElementPreservingChildren(PassRefPtr<DocumentFragment> fragment, HTMLElement* element)
{
    if (!fragment || !element) /* FIX [CWE-476]: Prevent null pointer dereference */
        return;

    ExceptionCode ignoredExceptionCode;
    RefPtr<Node> nextChild;
    for (RefPtr<Node> child = element->firstChild(); child; child = nextChild) {
        nextChild = child->nextSibling();
        if (!element->hasChildNodes()) /* FIX [CWE-476]: Prevent null pointer dereference */
            break;

        element->removeChild(child.get(), ignoredExceptionCode);
        ASSERT(!ignoredExceptionCode);
        fragment->insertBefore(child, element, ignoredExceptionCode);
        ASSERT(!ignoredExceptionCode);
    }
    if (fragment->hasChild(element)) /* FIX [CWE-476]: Prevent null pointer dereference */
        fragment->removeChild(element, ignoredExceptionCode);
    ASSERT(!ignoredExceptionCode);
}