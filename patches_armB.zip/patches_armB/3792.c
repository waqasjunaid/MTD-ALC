/* 
 * CHANGES MADE:
 * - Added input validation for unique_id
 */

media::AudioParameters GetDeviceParametersOnDeviceThread(
    media::AudioManager* audio_manager,
    const std::string& unique_id) {
  DCHECK(audio_manager->GetTaskRunner()->BelongsToCurrentThread());
  if (unique_id.empty()) { /* FIX [CWE-20]: Validate input to prevent empty string */ 
    LOG(ERROR) << "Invalid device ID";
    return media::AudioParameters(); // Return a default or error value
  }
  return media::AudioDeviceDescription::IsDefaultDevice(unique_id)
             ? audio_manager->GetDefaultOutputStreamParameters()
             : audio_manager->GetOutputStreamParameters(unique_id);
}