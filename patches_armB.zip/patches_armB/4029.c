/*
 * CHANGES:
 * - Added overflow check before shifting and adding values to compute the magic number.
 */

int mif_validate(jas_stream_t *in)
{
	uchar buf[MIF_MAGICLEN];
	uint_fast32_t magic;
	int i;
	int n;

	assert(JAS_STREAM_MAXPUTBACK >= MIF_MAGICLEN);

	/* Read the validation data (i.e., the data used for detecting
	  the format). */
	if ((n = jas_stream_read(in, buf, MIF_MAGICLEN)) < 0) {
		return -1;
	}

	/* Put the validation data back onto the stream, so that the
	  stream position will not be changed. */
	for (i = n - 1; i >= 0; --i) {
		if (jas_stream_ungetc(in, buf[i]) == EOF) {
			return -1;
		}
	}

	/* Was enough data read? */
	if (n < MIF_MAGICLEN) {
		return -1;
	}

	/* Compute the signature value. */
	uint_fast32_t temp = JAS_CAST(uint_fast32_t, buf[0]);
	if (temp > (UINT_FAST32_MAX >> 24)) { /* FIX [CWE-190]: prevent overflow */ 
		return -1; 
	}
	magic = (temp << 24);
	temp = JAS_CAST(uint_fast32_t, buf[1]);
	if ((magic > (UINT_FAST32_MAX - (temp << 16))) || (temp > (UINT_FAST32_MAX >> 16))) { /* FIX [CWE-190]: prevent overflow */ 
		return -1; 
	}
	magic |= (temp << 16);
	temp = JAS_CAST(uint_fast32_t, buf[2]);
	if ((magic > (UINT_FAST32_MAX - (temp << 8))) || (temp > (UINT_FAST32_MAX >> 8))) { /* FIX [CWE-190]: prevent overflow */ 
		return -1; 
	}
	magic |= (temp << 8);
	temp = JAS_CAST(uint_fast32_t, buf[3]);
	if ((magic > (UINT_FAST32_MAX - temp)) || (temp > UINT_FAST32_MAX)) { /* FIX [CWE-190]: prevent overflow */ 
		return -1; 
	}
	magic |= temp;

	/* Ensure that the signature is correct for this format. */
	if (magic != MIF_MAGIC) {
		return -1;
	}

	return 0;
}