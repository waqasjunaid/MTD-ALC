/* CHANGES MADE:
   - Added bounds check for existing_stream pointer
   - Added null check for plugin_stream and stream pointers
*/

WebPluginResourceClient* WebPluginDelegateImpl::CreateResourceClient(
    unsigned long resource_id, const GURL& url, bool notify_needed,
    intptr_t notify_data, intptr_t existing_stream) {
  if (existing_stream && reinterpret_cast<NPAPI::PluginStream*>(existing_stream)) { /* FIX [CWE-119]: bounds check for pointer */
    NPAPI::PluginStream* plugin_stream =
        reinterpret_cast<NPAPI::PluginStream*>(existing_stream);
    return plugin_stream ? plugin_stream->AsResourceClient() : nullptr; /* FIX [CWE-476]: null check */
  }
 
  std::string mime_type;
  NPAPI::PluginStreamUrl *stream = instance()->CreateStream(
      resource_id, url, mime_type, notify_needed,
      reinterpret_cast<void*>(notify_data));
  return stream ? stream : nullptr; /* FIX [CWE-476]: null check */
}