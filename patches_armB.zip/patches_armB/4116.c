/*
 * Changes:
 * - Added explicit bounds checks around pointer operations
 */

static void put_crypt_info(struct fscrypt_info *ci)
{
	if (!ci) /* FIX [CWE-690]: Check for NULL pointer */
		return;

	if (ci->ci_keyring_key) { /* FIX [CWE-690]: Validate pointer before use */
		key_put(ci->ci_keyring_key);
	}

	if (ci->ci_ctfm) { /* FIX [CWE-690]: Validate pointer before use */
		crypto_free_skcipher(ci->ci_ctfm);
	}

	kmem_cache_free(fscrypt_info_cachep, ci); /* No change needed here as it's already checked for NULL at the beginning of the function */
}