/*
 * Changes made:
 * - Applied CWE-416 mitigation by setting pointers to NULL after free()
 */

#define safe_free(p) do { free(p); (p) = NULL; } while (0)

psf_close (SF_PRIVATE *psf)
{	uint32_t k ;
	int	error = 0 ;

	if (psf->codec_close)
	{	error = psf->codec_close (psf) ;
		/* To prevent it being called in psf->container_close(). */
		psf->codec_close = NULL ;
		} ;

	if (psf->container_close)
		error = psf->container_close (psf) ;

	error = psf_fclose (psf) ;
 	psf_close_rsrc (psf) ;
 
 	/* For an ISO C compliant implementation it is ok to free a NULL pointer. */
 	safe_free(psf->container_data) ; /* FIX [CWE-416]: set ptr to NULL after free() */
 	safe_free(psf->codec_data) ; /* FIX [CWE-416]: set ptr to NULL after free() */
 	safe_free(psf->interleave) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->dither) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->peak_info) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->broadcast_16k) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->loop_info) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->instrument) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->cues) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->channel_map) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->format_desc) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->strings.storage) ; /* FIX [CWE-416]: set ptr to NULL after free() */

	if (psf->wchunks.chunks)
		for (k = 0 ; k < psf->wchunks.used ; k++)
			safe_free(psf->wchunks.chunks [k].data) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->rchunks.chunks) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->wchunks.chunks) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->iterator) ; /* FIX [CWE-416]: set ptr to NULL after free() */
	safe_free(psf->cart_16k) ; /* FIX [CWE-416]: set ptr to NULL after free() */

	memset (psf, 0, sizeof (SF_PRIVATE)) ;
	safe_free(psf) ; /* FIX [CWE-416]: set ptr to NULL after free() */

	return error ;
} /* psf_close */