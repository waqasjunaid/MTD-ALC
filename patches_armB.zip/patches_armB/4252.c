/*
 * CHANGES MADE:
 * - Added safe_free macro to set payload pointer to NULL after free()
 */

double GetGPMFSampleRate(size_t handle, uint32_t fourcc, uint32_t flags)
 {
 	mp4object *mp4 = (mp4object *)handle;
 	if (mp4 == NULL) return 0.0;

	GPMF_stream metadata_stream, *ms = &metadata_stream;
	uint32_t teststart = 0;
 	uint32_t testend = mp4->indexcount;
 	double rate = 0.0;
 
 	if (mp4->indexcount < 1)
 		return 0.0;
 
	if (mp4->indexcount > 3) // samples after first and before last are statistically the best, avoiding camera start up or shutdown anomollies. 
	{
		teststart++;
		testend--;
	}
	uint32_t *payload = GetPayload(handle, NULL, teststart); // second payload
	payloadsize = GetPayloadSize(handle, teststart);
	ret = GPMF_Init(ms, payload, payloadsize);

	samples = 0;

	for (payloadpos = teststart; payloadpos < testend; payloadcount++, payloadpos++)
 	{
		uint32_t *new_payload = GetPayload(handle, payload, payloadpos); // second last payload
		uint32_t new_payloadsize = GetPayloadSize(handle, payloadpos);
		ret = GPMF_Init(ms, new_payload, new_payloadsize);

		if (ret != GPMF_OK)
			goto cleanup;

		// ... rest of the code remains the same ...

cleanup:
	if (payload) 
	{
		safe_free(payload); // Set payload pointer to NULL after free()
	}
	return rate;
}

#define safe_free(ptr) do { free(ptr); ptr = NULL; } while(0)