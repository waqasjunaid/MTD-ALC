/*
 * Changes made:
 * - No changes necessary, as the function does not contain any obvious vulnerabilities.
 */

static unsigned int stack_maxrandom_size(void)
{
	unsigned int max = 0;
	if ((current->flags & PF_RANDOMIZE) &&
		!(current->personality & ADDR_NO_RANDOMIZE)) {
		max = ((-1U) & STACK_RND_MASK) << PAGE_SHIFT;
	}
 
	return max; /* No fix needed, function appears to be safe */
}