/* 
 * CHANGES:
 * - Added bounds checking for array index access in the 'serial->port' array.
 */

static int omninet_open(struct tty_struct *tty, struct usb_serial_port *port)
{
	struct usb_serial	*serial = port->serial;
	struct usb_serial_port	*wport;
	if (serial && serial->num_ports > 1) { /* FIX [CWE-129]: validate array index */ 
		wport = serial->port[1];
		tty_port_tty_set(&wport->port, tty);
	}
	return usb_serial_generic_open(tty, port);
}