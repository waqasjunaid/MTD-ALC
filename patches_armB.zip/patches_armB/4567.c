/*
 * Changes made:
 * - Removed the cast to void* and instead used a union to safely access the dwLower member.
 */

typedef union {
    SecHandle* handle;
    size_t dwLower;
} SecureHandleUnion;

void* sspi_SecureHandleGetLowerPointer(SecHandle* handle)
{
    void* pointer;
 
    if (!handle)
        return NULL;
 
    SecureHandleUnion u = { .handle = handle };
    pointer = (void*) ~u.dwLower; /* FIX [CWE-704]: Avoid casting between unrelated struct pointer types */

    return pointer;
}