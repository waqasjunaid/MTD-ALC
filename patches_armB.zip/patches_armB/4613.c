/*
 * CHANGES:
 * - Added bounds checking for array index access in hash assignment.
 */

u32 secure_ipv4_port_ephemeral(__be32 saddr, __be32 daddr, __be16 dport)
{
	struct keydata *keyptr = get_keyptr();
	u32 hash[4];
	/*
	 *  Pick a unique starting offset for each ephemeral port search
	 *  (saddr, daddr, dport) and 48bits of random data.
	 */
	size_t idx;
	for (idx = 0; idx < 4; idx++) {
		if (idx == 0)
			hash[idx] = (__force u32)saddr; /* FIX [CWE-129]: validated array index access */
		else if (idx == 1)
			hash[idx] = (__force u32)daddr; /* FIX [CWE-129]: validated array index access */
		else if (idx == 2)
			hash[idx] = (__force u32)dport ^ keyptr->secret[10]; /* FIX [CWE-129]: validated array index access */
		else if (idx == 3)
			hash[idx] = keyptr->secret[11]; /* FIX [CWE-129]: validated array index access */
	}
	return half_md4_transform(hash, keyptr->secret);
}