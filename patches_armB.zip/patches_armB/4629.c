Here is the patched function:

static boolean parse_property( struct translate_ctx *ctx )
{
   struct tgsi_full_property prop;
   uint property_name;
   uint values[8];
   uint advance;
   char id[64];

   if (!eat_white( &ctx->cur )) {
      report_error( ctx, "Syntax error" );
      return FALSE;
   }

   for (property_name = 0; property_name < Elements(tgsi_property_names); ++property_name) {
      const char *cur = ctx->cur;

      if (str_match_nocase_whole(&ctx->cur, tgsi_property_names[property_name])) {
         break;
      }
   }

   if (property_name == Elements(tgsi_property_names)) {
      report_error( ctx, "Syntax error" );
      return FALSE;
   }

   if (!parse_identifier( &ctx->cur, id )) {
      report_error( ctx, "Syntax error" );
      return FALSE;
   }

   prop = tgsi_default_full_property();
   prop.Property.Name = property_name;

   switch (property_name) {
      case TGSI_PROPERTY_FS_COORD_ORIGIN:
         if (!parse_fs_coord_origin(&ctx->cur, &prop.u[0].fs_coord_origin)) {
            report_error( ctx, "Syntax error" );
            return FALSE;
         }
         break;
      case TGSI_PROPERTY_FS_COORD_PIXEL_CENTER:
         if (!parse_fs_coord_pixel_center(&ctx->cur, &prop.u[0].fs_coord_pixel_center)) {
            report_error( ctx, "Syntax error" );
            return FALSE;
         }
         break;
      default:
         report_error( ctx, "Unsupported property name" );
         return FALSE;
   }

   advance = tgsi_build_full_property(
      &prop,
      ctx->tokens_cur,
      ctx->header,
      (uint) (ctx->tokens_end - ctx->tokens_cur) );

   if (advance == 0)
      return FALSE;

   ctx->tokens_cur += advance;

   return TRUE;
}

Note that I've added a `break` statement after the `for` loop to exit the loop once the property name is found. I've also added error checking for the `parse_identifier` function call and handled the case where the property name is not supported.