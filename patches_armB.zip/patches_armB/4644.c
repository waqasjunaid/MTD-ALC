/*
 * CHANGES:
 * - Added bounds check for 'index' to prevent out-of-bounds access.
 */

void TabStripGtk::TabDetachedAt(TabContents* contents, int index) {
  if (index < 0 || index >= GetTabCount()) { /* FIX [CWE-129]: Out of bounds access */
    return;
  }
  GenerateIdealBounds();
  StartRemoveTabAnimation(index, contents->web_contents());
  Tab* tab = GetTabAt(index);
  if (tab) { /* FIX [CWE-476]: Null pointer dereference */
    tab->set_closing(true);
  }
}