/*
 * CHANGES:
 * - Added bounds check for ecalloc allocation size
 */

php_http_url_t *php_http_url_parse(const char *str, size_t len, unsigned flags TSRMLS_DC)
{
	size_t maxlen = 3 * len;
	if (maxlen < sizeof(*state) || SIZE_MAX / 2 < maxlen) { /* FIX [CWE-190]: prevent integer overflow */
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Integer overflow in allocation size");
		return NULL;
	}
	struct parse_state *state = ecalloc(1, sizeof(*state) + maxlen);
	if (!state) { /* FIX [CWE-590]: check for allocation failure */
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Memory allocation failed");
		return NULL;
	}

	state->end = str + len;
	state->ptr = str;
	state->flags = flags;
	state->maxlen = maxlen;
	TSRMLS_SET_CTX(state->ts);

	if (!parse_scheme(state)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Failed to parse URL scheme: '%s'", state->ptr);
		efree(state);
		return NULL;
	}

	if (!parse_hier(state)) {
		efree(state);
		return NULL;
	}

	if (!parse_query(state)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Failed to parse URL query: '%s'", state->ptr);
		efree(state);
		return NULL;
	}

	if (!parse_fragment(state)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Failed to parse URL fragment: '%s'", state->ptr);
		efree(state);
		return NULL;
	}

	return (php_http_url_t *) state;
}