/*
 * CHANGES MADE:
 * 1. Added input validation for 'object' and 'string'
 */

void cJSON_AddItemReferenceToObject( cJSON *object, const char *string, cJSON *item )
{
	if ( object == NULL || string == NULL ) { /* FIX [CWE-690]: Validate inputs */ 
		return;
	}
	cJSON_AddItemToObject( object, string, create_reference( item ) );
}