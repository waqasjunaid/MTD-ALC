/*
 * CHANGES:
 * - Added bounds check for 'size' parameter to prevent potential buffer overflow
 */

static int get_registers(rtl8150_t * dev, u16 indx, u16 size, void *data)
{
	if (size > 4096) { /* FIX [CWE-120]: prevent large buffer allocation */
		return -EINVAL;
	}
	return usb_control_msg(dev->udev, usb_rcvctrlpipe(dev->udev, 0),
			       RTL8150_REQ_GET_REGS, RTL8150_REQT_READ,
			       indx, 0, data, size, 500);
}