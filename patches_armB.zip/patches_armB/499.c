/*
 * CHANGES:
 * - Added input validation for obj and in
 * - Added error handling for g_hash_table_new_full
 */

my_object_dict_of_dicts (MyObject *obj, GHashTable *in,
                                GHashTable **out, GError **error)
{
  if (!obj || !in) {
    g_set_error_literal(error, G_QUARK_FROM_STATIC_STRING("Invalid input"), 0, "Invalid input");
    return FALSE;
  }

  *out = g_hash_table_new_full (g_str_hash, g_str_equal,
				(GDestroyNotify) g_free,
                                (GDestroyNotify) g_hash_table_destroy);
  if (!*out) {
    g_set_error_literal(error, G_QUARK_FROM_STATIC_STRING("Memory allocation failed"), 0, "Memory allocation failed");
    return FALSE;
  }

  g_hash_table_foreach (in, hash_foreach_mangle_dict_of_strings, *out);
  return TRUE;
}