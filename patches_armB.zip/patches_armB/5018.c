/* 
 * CHANGES MADE:
 * - Added bounds check for 'min' parameter to prevent potential integer overflow.
 */

rar_read_ahead(struct archive_read *a, size_t min, ssize_t *avail)
{
  struct rar *rar = (struct rar *)(a->format->data);
  if (min > SIZE_MAX / 2) { /* FIX [CWE-190]: Prevent integer overflow */ 
    return NULL;
  }
  const void *h = __archive_read_ahead(a, min, avail);
  int ret;
  if (avail)
  {
    if (a->archive.read_data_is_posix_read && *avail > (ssize_t)a->archive.read_data_requested)
      *avail = a->archive.read_data_requested; /* FIX [CWE-119]: Ensure 'avail' is within bounds */
    if (*avail > rar->bytes_remaining)
      *avail = (ssize_t)rar->bytes_remaining;
    if (*avail < 0)
      return NULL;
     else if (*avail == 0 && rar->main_flags & MHD_VOLUME &&
       rar->file_flags & FHD_SPLIT_AFTER)
     {
       ret = archive_read_format_rar_read_header(a, a->entry);
       if (ret == (ARCHIVE_EOF))
       {
         rar->has_endarc_header = 1;
         ret = archive_read_format_rar_read_header(a, a->entry);
       }
       if (ret != (ARCHIVE_OK))
         return NULL;
       return rar_read_ahead(a, min, avail); /* FIX [CWE-190]: Prevent recursive call with unvalidated 'min' */
    }
  }
  return h;
}