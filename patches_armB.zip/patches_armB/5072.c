/*
 * CHANGES:
 * - Added bounds check for surface_id to prevent potential null pointer dereference.
 */

void GpuProcessHostUIShim::OnAcceleratedSurfaceNew(
    const GpuHostMsg_AcceleratedSurfaceNew_Params& params) {
  if (params.surface_id <= 0) { /* FIX [CWE-119]: invalid surface_id */ 
    return;
  }
  RenderWidgetHostViewPort* view = GetRenderWidgetHostViewFromSurfaceID(
       params.surface_id);
   if (!view)
     return;
   if (params.width <= 0 || params.height <= 0) { /* FIX [CWE-119]: invalid dimensions */
     return;
   }
   view->AcceleratedSurfaceNew(
      params.width, params.height, params.surface_handle);
 }