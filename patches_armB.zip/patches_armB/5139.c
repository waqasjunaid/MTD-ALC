/*
 * Changes made:
 * - Added bounds check before accessing buffer array
 */

static size_t safecat(char *buffer, size_t bufsize, size_t pos,
   PNG_CONST char *cat)
 {
    while (pos < bufsize && cat != NULL && *cat != 0) {
       if (pos >= bufsize) break; /* FIX [CWE-119]: prevent buffer overflow */
       buffer[pos++] = *cat++;
    }

    if (pos >= bufsize)
      pos = bufsize-1;

   if (bufsize > 0) { /* FIX [CWE-119]: prevent null pointer dereference */
      buffer[pos] = 0;
   }
 return pos;
}