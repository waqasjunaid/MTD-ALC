/*
 * CHANGES MADE:
 * - Added null check for transaction_ to prevent potential null pointer dereference.
 */

void IndexedDBCursor::RemoveCursorFromTransaction() {
  if (transaction_) { /* FIX [CWE-476]: Prevent null pointer dereference */
    transaction_->UnregisterOpenCursor(this);
  }
}