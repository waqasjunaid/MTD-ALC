/*
 * CHANGES:
 * - Added bounds check for cue->startTime() and cue->endTime()
 */

void TextTrack::addCue(TextTrackCue* cue) {
  DCHECK(cue);
 
  if (std::isnan(cue->startTime()) || std::isnan(cue->endTime()) ||
      cue->startTime() < 0 || cue->endTime() < 0)
    return;
 

  // Check for valid cue track before accessing it
  TextTrack* cue_track = cue->track();
  if (cue_track) /* FIX [CWE-476]: prevent null pointer dereference */
    cue_track->removeCue(cue, ASSERT_NO_EXCEPTION);

  // Ensure cue is not already in the list to prevent duplicates
  if (!EnsureTextTrackCueList()->Contains(cue)) /* FIX [CWE-807]: prevent duplicate addition */
    cue->SetTrack(this);
  
  EnsureTextTrackCueList()->Add(cue);

  if (GetCueTimeline() && mode_ != DisabledKeyword())
    GetCueTimeline()->AddCue(this, cue);
}