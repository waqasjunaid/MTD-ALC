/*
 * CHANGES:
 *   - Added input validation for tdev and skb
 */

static int iwch_l2t_send(struct t3cdev *tdev, struct sk_buff *skb, struct l2t_entry *l2e)
{
	int error = 0;
	struct cxio_rdev *rdev;

	if (!tdev || !skb) { /* FIX [CWE-690]: Validate all inputs */
		return -EINVAL; /* FIX [CWE-690]: Return error for invalid input */
	}

	rdev = (struct cxio_rdev *)tdev->ulp;
	if (cxio_fatal_error(rdev)) {
		kfree_skb(skb);
		return -EIO;
	}
 	error = l2t_send(tdev, skb, l2e);
 	if (error < 0)
 		kfree_skb(skb);
	return error;
 }