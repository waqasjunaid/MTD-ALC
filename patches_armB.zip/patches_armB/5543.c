/*
 * CHANGES:
 * - Added explicit bounds check for bufsize to prevent integer overflow
 */

static int mem_resize(jas_stream_memobj_t *m, int bufsize)
{
	unsigned char *buf;

	/* FIX [CWE-190]: Validate input to prevent integer overflow */
	if (bufsize < 0 || (size_t)bufsize > SIZE_MAX / sizeof(unsigned char)) {
		return -1;
	}

	JAS_DBGLOG(100, ("mem_resize(%p, %d)\n", m, bufsize));
	if (!(buf = jas_realloc2(m->buf_, bufsize, sizeof(unsigned char))) &&
	  bufsize) {
		JAS_DBGLOG(100, ("mem_resize realloc failed\n"));
		return -1;
	}
	JAS_DBGLOG(100, ("mem_resize realloc succeeded\n"));
	m->buf_ = buf;
	m->bufsize_ = bufsize;
	return 0;
}