/* 
 * CHANGES:
 * - Added explicit null checks for parent and directory_service
 */

GDataEntry* GDataEntry::FromDocumentEntry(
    GDataDirectory* parent,
    DocumentEntry* doc,
    GDataDirectoryService* directory_service) {
  DCHECK(doc);
  if (!parent || !directory_service) { /* FIX [CWE-476]: null pointer dereference */
    return NULL;
  }
  if (doc->is_folder())
    return GDataDirectory::FromDocumentEntry(parent, doc, directory_service);
  else if (doc->is_hosted_document() || doc->is_file())
    return GDataFile::FromDocumentEntry(parent, doc, directory_service);
  return NULL;
}