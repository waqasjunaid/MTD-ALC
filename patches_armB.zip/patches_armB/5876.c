/* 
 * Changes made:
 * - Added null check for url and srcURL to prevent potential crashes
 * - Added bounds check around pointer operation on originMap()
 */

void ThreadableBlobRegistry::registerBlobURL(SecurityOrigin* origin, const KURL& url, const KURL& srcURL)
{
    if (origin && !url.isNull() && BlobURL::getOrigin(url) == "null")
        originMap()->add(url.string(), origin); /* FIX [CWE-476]: prevent null pointer dereference */

    if (!srcURL.isNull()) { /* FIX [CWE-476]: prevent null pointer dereference */
        if (isMainThread())
            blobRegistry().registerBlobURL(url, srcURL);
        else {
             OwnPtr<BlobRegistryContext> context = adoptPtr(new BlobRegistryContext(url, srcURL));
             callOnMainThread(&registerBlobURLFromTask, context.leakPtr());
        }
    }
}