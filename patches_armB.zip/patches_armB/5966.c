/*
 * Changes made:
 * - Added input validation for 'name' parameter
 */

ext4_xattr_create_cache(char *name)
{
	if (name == NULL) { /* FIX [CWE-690]: null pointer dereference */
		return -EINVAL;
	}
	return mb_cache_create(name, HASH_BUCKET_BITS);
}