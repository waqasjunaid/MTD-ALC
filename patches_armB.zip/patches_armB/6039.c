/* 
 * CHANGES MADE:
 * - Added input validation for socket descriptor 's'
 */

static inline void set_socket_blocking(int s, int blocking)
{
    if (s < 0) { /* FIX [CWE-20]: Validate socket descriptor */ 
        APPL_TRACE_ERROR("Invalid socket descriptor");
        return;
    }

    int opts;
    opts = fcntl(s, F_GETFL);
    if (opts < 0) {
        APPL_TRACE_ERROR("set blocking (%s)", strerror(errno));
        return; /* FIX [CWE-252]: Check return value and handle error */ 
    }
    
    if(blocking)
        opts &= ~O_NONBLOCK;
    else 
        opts |= O_NONBLOCK;

    if (fcntl(s, F_SETFL, opts) < 0) {
        APPL_TRACE_ERROR("set blocking (%s)", strerror(errno));
        return; /* FIX [CWE-252]: Check return value and handle error */ 
    }
}