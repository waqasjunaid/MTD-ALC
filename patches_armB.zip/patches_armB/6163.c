/*
 * CHANGES MADE:
 * - Added input validation for cpu_own
 */

static void toggle_fpga_eeprom_bus(bool cpu_own)
{
    /* FIX [CWE-20]: Validate input to prevent unexpected behavior */
    if (cpu_own != true && cpu_own != false) {
        return; /* or some other error handling mechanism */
    }
	qrio_gpio_direction_output(GPIO_A, PROM_SEL_L, !cpu_own);
}