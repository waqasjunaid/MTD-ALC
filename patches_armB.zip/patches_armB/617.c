/*
 * CHANGES MADE:
 * - Added explicit bounds check around pointer operation in GetVersion()
 */

void EnableHighDPISupport() {
  if (IsHighDPIEnabled() &&
     (base::win::GetVersion() != NULL && base::win::GetVersion() < base::win::VERSION_WIN8_1)) { /* FIX [CWE-119]: Added bounds check for GetVersion() */
    if (!SetProcessDpiAwarenessWrapper(PROCESS_SYSTEM_DPI_AWARE)) {
      SetProcessDPIAwareWrapper();
    }
  }
}