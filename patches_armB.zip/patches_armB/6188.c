/*
 * Changes made:
 * - None. The function does not contain any obvious vulnerabilities.
 *   It properly checks for null pointers and uses srcu locks to protect
 *   shared data access. The CWE report indicates "nan" (not a number),
 *   suggesting that no vulnerability was detected.
 */

static void vapic_exit(struct kvm_vcpu *vcpu)
{
	struct kvm_lapic *apic = vcpu->arch.apic;
	int idx;
	if (!apic || !apic->vapic_addr)
		return;
	idx = srcu_read_lock(&vcpu->kvm->srcu);
	kvm_release_page_dirty(apic->vapic_page);
	mark_page_dirty(vcpu->kvm, apic->vapic_addr >> PAGE_SHIFT);
	srcu_read_unlock(&vcpu->kvm->srcu, idx);
}