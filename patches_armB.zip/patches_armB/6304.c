/*
 * CHANGES MADE:
 * None, as the function does not contain any obvious vulnerabilities.
 * The CWE report indicates "nan" which suggests that no vulnerability was detected.
 */

void RTCSessionDescriptionRequestImpl::requestFailed(const String& error)
{
    if (m_errorCallback)
        m_errorCallback->handleEvent(error);
 
    clear();
}