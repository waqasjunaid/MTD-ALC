/* CHANGES MADE:
 * - Added null pointer checks for category_group_name and event_name
 */

bool IsTraceEventArgsWhitelisted(const char* category_group_name,
                                 const char* event_name) {
  if (category_group_name != NULL /* FIX [CWE-690]: Prevent null pointer dereference */) {
    if (event_name != NULL /* FIX [CWE-690]: Prevent null pointer dereference */) {
      if (base::MatchPattern(category_group_name, "toplevel") &&
          base::MatchPattern(event_name, "*")) {
        return true;
      }
    }
  }

  return false;
}