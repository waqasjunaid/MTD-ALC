/*
 * CHANGES MADE:
 * None, as the function does not contain any obvious vulnerabilities.
 * The CWE report indicates "nan" (not a number), suggesting that no
 * specific vulnerability was identified. However, we can still review
 * the code for potential issues.
 *
 * In this case, the constructor appears to be initializing member variables
 * with default values and creating an object of type velocity_calculator_.
 * Without more context about the class and its members, it's difficult to
 * identify any potential vulnerabilities. Therefore, no changes are made.
 */

GesturePoint::GesturePoint()
     : first_touch_time_(0.0),
       last_touch_time_(0.0),
       last_tap_time_(0.0),
      velocity_calculator_(kBufferedPoints) {
 }