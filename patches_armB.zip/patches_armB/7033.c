/*
 * CHANGES:
 * - Added null check for plugin_ to prevent potential null pointer dereference.
 */

void WebPluginDelegateProxy::OnGetWindowScriptNPObject(
    int route_id, bool* success, intptr_t* npobject_ptr) {
  *success = false;
  NPObject* npobject = NULL;
  if (plugin_) { /* FIX [CWE-476]: prevent null pointer dereference */
    npobject = plugin_->GetWindowScriptNPObject();
  }

  if (!npobject)
    return;

  window_script_object_ = (new NPObjectStub(
      npobject, channel_host_.get(), route_id, 0, page_url_))->AsWeakPtr();
  *success = true;
  *npobject_ptr = reinterpret_cast<intptr_t>(npobject);
}