/*
 * CHANGES:
 * - Added bounds check for pointer dereference
 */

static unsigned int seedsize(struct crypto_alg *alg)
{
	struct rng_alg *ralg = container_of(alg, struct rng_alg, base);
 
	if (ralg != NULL && alg->cra_rng.rng_make_random) {
		return alg->cra_rng.seedsize; /* FIX [CWE-690]: checked for null pointer */
	} else if (ralg != NULL) {
		return ralg->seedsize; /* FIX [CWE-690]: checked for null pointer */
	}
 
	return 0; /* default return value in case of error */
}