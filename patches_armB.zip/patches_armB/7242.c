/* 
 * CHANGES MADE:
 * - Added bounds checking to prevent out-of-bounds access in the pages_ array.
 */

int PDFiumEngine::GetVisiblePageIndex(FPDF_PAGE page) {
  for (size_t idx = 0; idx < visible_pages_.size(); ++idx) { /* FIX [CWE-129]: iterate over indices instead of values */
    if (idx >= 0 && (size_t)idx < pages_.size()) { /* FIX [CWE-129]: bounds checking */
      if (pages_[idx]->GetPage() == page)
        return idx;
    }
  }
  return -1;
}