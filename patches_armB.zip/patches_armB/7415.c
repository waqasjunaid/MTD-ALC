/* 
 * CHANGES MADE:
 * - Added null pointer check for webPage to prevent potential crashes.
 */

void WebProcessProxy::addExistingWebPage(WebPageProxy* webPage, uint64_t pageID)
{
    if (!webPage) /* FIX [CWE-476]: Prevent null pointer dereference */
        return;
    
    m_pageMap.set(pageID, webPage);
    globalPageMap().set(pageID, webPage);
#if PLATFORM(MAC)
    if (pageIsProcessSuppressible(webPage));
         m_processSuppressiblePages.add(pageID);
     updateProcessSuppressionState();
#endif
}