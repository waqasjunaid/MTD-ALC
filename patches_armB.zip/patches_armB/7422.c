/*
 * CHANGES:
 * - Added bounds check to ensure 'it' is not equal to 'instance_map_.end()' before accessing its members.
 */

void BrowserPpapiHostImpl::DeleteInstance(PP_Instance instance) {
  auto it = instance_map_.find(instance);
  if (it != instance_map_.end()) { /* FIX [CWE-129]: bounds check */
    for (auto& observer : it->second->observer_list)
      observer.OnHostDestroyed();
 
    instance_map_.erase(it);
  }
}