/* 
 * CHANGES MADE:
 * - Added bounds check for find_text to prevent potential buffer overflow
 */

void Browser::FindInPage(bool find_next, bool forward_direction) {
  ShowFindBar();
  if (find_next) {
    string16 find_text;
#if defined(OS_MACOSX)
     find_text = GetFindPboardText();
#endif
     // Check if find_text is not empty to prevent potential buffer overflow
     if (!find_text.empty()) { /* FIX [CWE-120]: bounds check */
        GetSelectedTabContentsWrapper()->
           GetFindManager()->StartFinding(find_text,
                                          forward_direction,
                                          false);  // Not case sensitive.
     }
   }
 }