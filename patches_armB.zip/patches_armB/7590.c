/*
 * Changes made:
 * - Added null check to prevent potential double-free or use-after-free vulnerability
 */

CuePoint::~CuePoint()
{
    if (m_track_positions != nullptr) { /* FIX [CWE-416]: Prevent double-free/use-after-free */ 
        delete[] m_track_positions;
    }
}