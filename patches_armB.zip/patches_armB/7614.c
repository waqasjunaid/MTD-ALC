/* 
 * CHANGES:
 * 1. Added bounds check for poll() return value
 */

static int accept_server_socket(int sfd)
{
    struct sockaddr_un remote;
    struct pollfd pfd;
    int fd;
    socklen_t len = sizeof(struct sockaddr_un);

    BTIF_TRACE_EVENT("accept fd %d", sfd);

    /* make sure there is data to process */
    pfd.fd = sfd;
    pfd.events = POLLIN;

    if ((poll(&pfd, 1, 0) < 0) || (poll(&pfd, 1, 0) == 0)) {
        BTIF_TRACE_EVENT("accept poll error or timeout");
        return -1; /* FIX [CWE-390]: handle poll() errors and timeouts */
    }

    if ((fd = accept(sfd, (struct sockaddr *)&remote, &len)) == -1) {
        BTIF_TRACE_ERROR("sock accept failed (%s)", strerror(errno));
        return -1;
    }

    return fd;
}