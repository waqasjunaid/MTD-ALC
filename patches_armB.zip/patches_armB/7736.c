/*
 * CHANGES MADE:
 * - Added null check for compositor_client_ to prevent potential null pointer dereference.
 */

void SynchronousCompositorImpl::PostInvalidate() {
   DCHECK(CalledOnValidThread());
   DCHECK(compositor_client_);
   if (compositor_client_) { /* FIX [CWE-476]: Prevent null pointer dereference */
     compositor_client_->PostInvalidate();
   }
 }