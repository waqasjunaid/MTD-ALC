/* 
 * CHANGES:
 * - Added explicit bounds check for placeholder replacement
 */

std::string GetUploadData(const std::string& brand) {
   DCHECK(!brand.empty());
  std::string data(kPostXml);
  const std::string placeholder("__BRANDCODE_PLACEHOLDER__");
  size_t placeholder_pos = data.find(placeholder);
  DCHECK(placeholder_pos != std::string::npos);
  if (placeholder_pos + placeholder.size() <= data.size()) { /* FIX [CWE-119]: bounds check for replacement */
    data.replace(placeholder_pos, placeholder.size(), brand);
  }
  return data;
 }