/* 
 * CHANGES MADE:
 * - Added bounds check for 'which' parameter to prevent potential out-of-bounds access.
 */

cJSON *cJSON_DetachItemFromArray( cJSON *array, int which )
{
	if ( array == NULL || which < 0 ) /* FIX [CWE-129]: invalid input validation */
		return 0;
	cJSON *c = array->child;
	while ( c && which > 0 ) {
		c = c->next;
		--which;
	}
	if ( ! c )
		return 0;
	if ( c->prev )
		c->prev->next = c->next;
	if ( c->next ) c->next->prev = c->prev;
	if ( c == array->child )
		array->child = c->next;
	c->prev = c->next = 0;
	return c;
}