/*
 * Changes made:
 * - Added explicit null check for 'sender' to prevent potential null pointer dereference.
 */

void CastCastView::ButtonPressed(views::Button* sender,
                                  const ui::Event& event) {
  if (sender == nullptr) { /* FIX [CWE-476]: Prevent null pointer dereference */
    return;
  }
  DCHECK(sender == stop_button_);
  StopCast();
}