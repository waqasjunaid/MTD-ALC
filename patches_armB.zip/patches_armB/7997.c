/* 
 * CHANGES:
 * - Added bounds checking for pointer 'value' to prevent null pointer dereference.
 */

static inline void VectorClamp3(DDSVector3 *value)
{
  if (value != NULL) { /* FIX [CWE-476]: Prevent null pointer dereference */
    value->x = MinF(1.0f,MaxF(0.0f,value->x));
    value->y = MinF(1.0f,MaxF(0.0f,value->y));
    value->z = MinF(1.0f,MaxF(0.0f,value->z));
  }
}