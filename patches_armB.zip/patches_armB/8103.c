/* 
 * Changes made:
 * - Added explicit cast to avoid implicit cast between signed and unsigned
 */

BGD_DECLARE(void *) gdImageWebpPtrEx (gdImagePtr im, int *size, int quality)
{
	void *rv;
	gdIOCtx *out = gdNewDynamicCtx(2048, NULL);
 	if (out == NULL) {
 		return NULL;
 	}
	gdImageWebpCtx(im, out, (unsigned int)quality); /* FIX [CWE-704]: explicit cast to unsigned int */
	rv = gdDPExtractData(out, size);
 	out->gd_free(out);
 	return rv;
 }