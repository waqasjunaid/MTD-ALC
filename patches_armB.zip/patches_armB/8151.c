/* 
 * CHANGES:
 *   None. The function does not contain any obvious vulnerabilities.
 *   It performs a simple Manhattan distance calculation and checks if it's within a certain threshold.
 *   All inputs are validated implicitly by the abs() function, which will not overflow for integer values.
 */

bool GesturePoint::IsSecondClickInsideManhattanSquare(
     const TouchEvent& event) const {
  int manhattanDistance = abs(event.x() - last_tap_position_.x()) +
                          abs(event.y() - last_tap_position_.y());
  return manhattanDistance < kMaximumTouchMoveInPixelsForClick;
}