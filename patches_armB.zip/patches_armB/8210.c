/*
 * CHANGES MADE:
 * None, as the function does not contain any obvious vulnerabilities.
 * The CWE diagnosis report indicates "nan" (not a number), suggesting that no
 * specific vulnerability was identified. However, we can still review the code
 * for potential issues. In this case, the constructor appears to be properly
 * initialized and does not perform any operations that could lead to common
 * vulnerabilities such as buffer overflows or null pointer dereferences.
 */

ServiceWorkerHandler::ServiceWorkerHandler()
     : DevToolsDomainHandler(ServiceWorker::Metainfo::domainName),
       enabled_(false),
      process_(nullptr),
       weak_factory_(this) {}