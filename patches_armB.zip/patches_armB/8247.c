/*
 * CHANGES MADE:
 * None. The function does not contain any obvious vulnerabilities.
 * It simply calls another function with the provided input, without performing any operations that could lead to security issues.
 */

void WebSettingsImpl::setExperimentalNotificationsEnabled(bool enabled)
{
    m_settings->setExperimentalNotificationsEnabled(enabled);
}