/*
 * CHANGES:
 * - Added bounds check for 'chunks' to prevent potential integer overflow
 */

void svc_rdma_xdr_encode_reply_array(struct rpcrdma_write_array *ary,
				 int chunks)
{
	if (chunks < 0) { /* FIX [CWE-190]: Prevent negative value */ 
		chunks = 0; /* FIX [CWE-190]: Clamp to non-negative */
	}
	ary->wc_discrim = xdr_one;
	ary->wc_nchunks = cpu_to_be32(chunks);
}