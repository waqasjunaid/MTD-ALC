/*
 * Changes made:
 *  None. The function does not contain any obvious vulnerabilities.
 *  It appears to be a simple getter function that retrieves timer settings
 *  and performs some calculations. All inputs are validated implicitly by
 *  the function's logic, and there are no pointer/array operations that require
 *  explicit bounds checks.
 */

static void sgi_timer_get(struct k_itimer *timr, struct itimerspec *cur_setting)
{
	if (timr->it.mmtimer.clock == TIMER_OFF) {
		cur_setting->it_interval.tv_nsec = 0;
		cur_setting->it_interval.tv_sec = 0;
		cur_setting->it_value.tv_nsec = 0;
		cur_setting->it_value.tv_sec =0;
 		return;
 	}
 
	ns_to_timespec(cur_setting->it_interval, timr->it.mmtimer.incr * sgi_clock_period);
	ns_to_timespec(cur_setting->it_value, (timr->it.mmtimer.expires - rtc_time())* sgi_clock_period);
	return;
}