Here is the patched function:

int ssl3_send_server_key_exchange(SSL *s)
{
    /* ... (unchanged code) */

#ifndef OPENSSL_NO_DH
    DH *dh = NULL, *dhp;
#endif

    /* ... (unchanged code) */

#ifndef OPENSSL_NO_DH
    if (type & SSL_kEDH) {
        dhp = cert->dh_tmp;
        if ((dhp == NULL) && (s->cert->dh_tmp_cb != NULL))
            dhp = s->cert->dh_tmp_cb(s,
                                     SSL_C_IS_EXPORT(s->s3->
                                                     tmp.new_cipher),
                                     SSL_C_EXPORT_PKEYLENGTH(s->s3->
                                                             tmp.new_cipher));
        if (dhp == NULL) {
            al = SSL_AD_HANDSHAKE_FAILURE;
            SSLerr(SSL_F_SSL3_SEND_SERVER_KEY_EXCHANGE,
                   SSL_R_MISSING_TMP_DH_KEY);
            goto f_err;
        }

        /* ... (unchanged code) */

        if ((dh->pub_key == NULL) || (dh->priv_key == NULL)) { 
            if (!DH_generate_key(dh)) {
                SSLerr(SSL_F_SSL3_SEND_SERVER_KEY_EXCHANGE, ERR_R_DH_LIB);
                goto err;
            }
        } else {
            dh->pub_key = BN_dup(dhp->pub_key); 
            if (dh->pub_key == NULL) { 
                SSLerr(SSL_F_SSL3_SEND_SERVER_KEY_EXCHANGE, ERR_R_DH_LIB);
                goto err;
            }
            dh->priv_key = BN_dup(dhp->priv_key); 
            if (dh->priv_key == NULL) { 
                SSLerr(SSL_F_SSL3_SEND_SERVER_KEY_EXCHANGE, ERR_R_DH_LIB);
                goto err;
            }
        }

        /* ... (unchanged code) */

    } else
#endif

    /* ... (unchanged code) */

    return 1;

f_err:
    SSLerr(SSL_F_SSL3_SEND_SERVER_KEY_EXCHANGE, al);
    return -1;
}