&error_)) {
     return false;
   }
 
  RenderViewHost* render_view_host = web_contents->GetRenderViewHost();
  if (!render_view_host) { 
    error_ = keys::kInternalVisibleTabCaptureError;
    return false;
  }