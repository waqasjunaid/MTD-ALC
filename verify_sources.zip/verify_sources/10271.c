map = __bpf_map_get(f);
	if (IS_ERR(map))
		return map;
 
	if (!map) { 
		fdput(f); 
		return ERR_PTR(-EINVAL);
	}