* Changes made:
 * - Added NULL pointer checks for q and hb to prevent potential crashes.
 */

queue_unlock(struct futex_q *q, struct futex_hash_bucket *hb)
{
	if (q != NULL && hb != NULL) { 
		spin_unlock(&hb->lock);
		drop_futex_key_refs(&q->key); 
	}
}