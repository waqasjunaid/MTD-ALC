/* 
 * CHANGES MADE:
 * - Added NULL check for cJSON_New_Item() return value to prevent potential NULL pointer dereference.
 */

cJSON *cJSON_CreateObject( void )
{
	cJSON *item = cJSON_New_Item(); 
	if ( item != NULL ) 
		item->type = cJSON_Object;
	return item;
}