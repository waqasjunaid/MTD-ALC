/*
 * CHANGES MADE:
 * - Added bounds check to prevent out-of-bounds access in the array.
 */

static void array_cleanup(char* arr[], int arr_size) {
    int i = 0;
    if (arr == NULL || arr_size <= 0) {  
        return;
    }
    for (i = 0; i < arr_size; i++) {
        if (i * 2 >= arr_size) {  
            break;
        }
        if (arr[i * 2]) {
            efree(arr[i * 2]);
        }
    }
    efree(arr);
}