/*
 * Changes made:
 * - Added a null check for the 'window' parameter to prevent potential crashes.
 */

void PartialMagnificationController::OnWindowDestroying(aura::Window* window) {
   if (window == nullptr) {  
     return;
   }
 
   CloseMagnifierWindow();
 
   aura::Window* new_root_window = GetCurrentRootWindow();
   if (new_root_window != window)
    SwitchTargetRootWindow(new_root_window);
 }