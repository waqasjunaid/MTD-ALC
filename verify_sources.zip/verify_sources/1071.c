if (ohci->name != NULL) { 
        trace_usb_ohci_start(ohci->name);
    }