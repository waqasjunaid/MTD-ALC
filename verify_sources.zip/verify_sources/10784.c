/* 
 * CHANGES MADE:
 * - Added bounds check for pointer operations on 'script_state' and 'options'
 */

ImageBitmapFactories::ImageBitmapLoader::ImageBitmapLoader(
     ImageBitmapFactories& factory,
     base::Optional<IntRect> crop_rect,
     ScriptState* script_state, 
     const ImageBitmapOptions* options) 
    : loader_(
           FileReaderLoader::Create(FileReaderLoader::kReadAsArrayBuffer, this)),
       factory_(&factory),
       resolver_(script_state ? ScriptPromiseResolver::Create(script_state) : nullptr), 
       crop_rect_(crop_rect),
       options_(options ? options : &ImageBitmapOptions()) {  }