VLOG(1) << object_path_.value() << ": Unregistering pairing agent";
  DBusThreadManager* dbus_thread_manager = DBusThreadManager::Get(); 
  if (dbus_thread_manager) {
    dbus_thread_manager->GetBluetoothAgentManagerClient()->
        UnregisterAgent(
            dbus::ObjectPath(kAgentPath),
            base::Bind(&base::DoNothing),
            base::Bind(&BluetoothDeviceChromeOS::OnUnregisterAgentError,
                       weak_ptr_factory_.GetWeakPtr()));
  }