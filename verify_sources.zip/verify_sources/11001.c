/*
 * Changes made:
 * - Added a null pointer check for the 'library' parameter.
 */

void CrosLibrary::TestApi::SetBrightnessLibrary(
    BrightnessLibrary* library, bool own) {
  if (library != nullptr) { 
    library_->brightness_lib_.SetImpl(library, own);
  }
}