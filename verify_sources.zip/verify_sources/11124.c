* CHANGES MADE:
 * - Added a NULL check for the result of png_get_error_ptr() to prevent potential NULL pointer dereference.
 */

get_control(png_const_structrp png_ptr)
{

    /* This just returns the (file*).  The chunk and idat control structures
     * don't always exist.
     */
   struct control *control = png_voidcast(struct control*,
       png_get_error_ptr(png_ptr)); 
   if (control != NULL) { 
      return &control->file;
   } else {
      return NULL; 
   }
}