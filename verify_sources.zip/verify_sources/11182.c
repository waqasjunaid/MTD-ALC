/*
 * Changes made:
 * - Added a null check for the 'this' pointer to prevent potential crashes.
 */

Chapters::Display::~Display()
{
    if (this != nullptr) 
    {
        // No-op, as the original function was empty
    }
}