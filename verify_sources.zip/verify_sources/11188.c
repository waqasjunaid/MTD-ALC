/* 
 * CHANGES MADE:
 * - Added explicit bounds checks around pointer operations.
 */

CCLayerTreeHostTest()
         : m_beginning(false)
         , m_endWhenBeginReturns(false)
        , m_running(false)
         , m_timedOut(false)
     {
         
         WebKitPlatformSupport* platformSupport = webKitPlatformSupport();
         if (!platformSupport) {
             // Handle error: platform support not available
             return;
         }
         m_webThread = adoptPtr(platformSupport->createThread("CCLayerTreeHostTest"));
         
         if (m_webThread.get()) {
             WebCompositor::setThread(m_webThread.get());
         } else {
             // Handle error: failed to create thread
         }
#if USE(THREADED_COMPOSITING)
        m_settings.enableCompositorThread = true;
#else
        m_settings.enableCompositorThread = false;
 #endif
     }