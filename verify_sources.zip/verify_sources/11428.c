/* 
 * CHANGES MADE:
 * - Added a null check for the instance pointer before returning it.
 */

ProcessIdToFilterMap* GetProcessIdToFilterMap() {
  static base::NoDestructor<ProcessIdToFilterMap> instance;
  return (instance.get() != nullptr) ? instance.get() :  nullptr;
}