if (!canonical_encoding.empty()) { 
    web_prefs.default_encoding = canonical_encoding;
  }
  DCHECK(!web_prefs.default_encoding.empty());

  if (is_dom_ui) {
    web_prefs.loads_images_automatically = true;
    web_prefs.javascript_enabled = true;
  }