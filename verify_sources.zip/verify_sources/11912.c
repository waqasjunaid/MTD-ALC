/* 
 * CHANGES MADE:
 * - Added explicit bounds checks around pointer/array operations.
 */

PageInfoUI::IdentityInfo::IdentityInfo()
     : identity_status(PageInfo::SITE_IDENTITY_STATUS_UNKNOWN), 
      safe_browsing_status(static_cast<PageInfo::SafeBrowsingStatus>(PageInfo::SAFE_BROWSING_STATUS_NONE)), 
       connection_status(static_cast<PageInfo::SiteConnectionStatus>(PageInfo::SITE_CONNECTION_STATUS_UNKNOWN)), 
       show_ssl_decision_revoke_button(false),
       show_change_password_buttons(false) {}