Here is the patched function with the requested changes:

int fuzzerTest(int nbTests) {
    int result = 0;
    U64 crcOrig, crcDest;
    size_t totalTestSize=0, cSize=0, totalCSize=0, totalGenSize=0;
    U32 testNb = 1;

    ZSTD_CCtx* refCtx = ZSTD_createCCtx();
    if (refCtx == NULL) {
        DISPLAY("Error: cannot create compression context\n");
        return 1;
    }

    ZSTD_CCtx* ctx = ZSTD_createCCtx();
    if (ctx == NULL) {
        DISPLAY("Error: cannot create compression context\n");
        goto _output_error;
    }

    ZSTD_DCtx* dctx = ZSTD_createDCtx();
    if (dctx == NULL) {
        DISPLAY("Error: cannot create decompression context\n");
        goto _output_error;
    }

    void* cNoiseBuffer[5];
    size_t cBufferSize = 1024 * 1024; /* 1 MB */
    for (int i = 0; i < 5; i++) {
        cNoiseBuffer[i] = malloc(cBufferSize);
        if (cNoiseBuffer[i] == NULL) {
            DISPLAY("Error: cannot allocate memory\n");
            goto _output_error;
        }
    }

    size_t dstBufferSize = 1024 * 1024; /* 1 MB */
    void* dstBuffer = malloc(dstBufferSize);
    if (dstBuffer == NULL) {
        DISPLAY("Error: cannot allocate memory\n");
        goto _output_error;
    }

    size_t mirrorBufferSize = 1024 * 1024; /* 1 MB */
    void* mirrorBuffer = malloc(mirrorBufferSize);
    if (mirrorBuffer == NULL) {
        DISPLAY("Error: cannot allocate memory\n");
        goto _output_error;
    }

    for (; testNb <= nbTests; testNb++) {
        size_t maxSampleLog = 19;
        size_t maxTestSize = 1 << maxSampleLog;

        size_t srcBufferSize = 1024 * 1024; /* 1 MB */
        void* srcBuffer = malloc(srcBufferSize);
        if (srcBuffer == NULL) {
            DISPLAY("Error: cannot allocate memory\n");
            goto _output_error;
        }

        size_t srcSize = FUZZ_randomLength(&l, maxSampleLog);
        FUZZ_fillBlock(srcBuffer, srcSize);

        void* cBuffer = cNoiseBuffer[testNb % 5];
        size_t compressResult = ZSTD_compressCCtx(refCtx, cBuffer, cBufferSize, srcBuffer, srcSize, 1);
        if (ZSTD_isError(compressResult)) {
            DISPLAY("Error: compression failed\n");
            goto _output_error;
        }

        void* dBuffer = dstBuffer;
        size_t decompressResult = ZSTD_decompressDCtx(dctx, dBuffer, dstBufferSize, cBuffer, compressResult);
        if (ZSTD_isError(decompressResult)) {
            DISPLAY("Error: decompression failed\n");
            goto _output_error;
        }

        crcOrig = XXH64(srcBuffer, srcSize, 0);
        crcDest = XXH64(dBuffer, decompressResult, 0);

        free(srcBuffer);

        if (crcOrig != crcDest) {
            DISPLAY("Error: data corrupted\n");
            goto _output_error;
        }
    }

_cleanup:
    ZSTD_freeCCtx(refCtx);
    ZSTD_freeCCtx(ctx);
    ZSTD_freeDCtx(dctx);
    for (int i = 0; i < 5; i++) {
        free(cNoiseBuffer[i]);
    }
    free(dstBuffer);
    free(mirrorBuffer);
    return result;

_output_error:
    result = 1;
    goto _cleanup;
}