/*
 * Changes made:
 * - Added a null check for data_object to prevent potential crashes.
 */

bool ClipboardUtil::HasFilenames(IDataObject* data_object) {
  if (data_object == nullptr) {  
    return false;
  }
  DCHECK(data_object);
  return HasData(data_object, Clipboard::GetCFHDropFormatType());
}