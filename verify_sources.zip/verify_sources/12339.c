/*
 * CHANGES MADE:
 * - Added a null check for context_.network_message_loop() to prevent potential crashes.
 */

void RemoveClientSession() {
    if (context_.network_message_loop()) { 
        context_.network_message_loop()->PostTask(
            FROM_HERE, base::Bind(
                &ClientSession::OnConnectionClosed, client_, connection_));
    }
}