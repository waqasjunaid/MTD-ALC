* Changes made:
 * - Added explicit bounds check for pointer/array operations
 */

parse_field(netdissect_options *ndo, const char **pptr, int *len)
 {
     const char *s;

    if (*len <= 0 || !pptr || !*pptr) 
	return NULL;
    if (*pptr > (const char *) ndo->ndo_snapend) 
	return NULL;
     s = *pptr;
    while (*pptr <= (const char *) ndo->ndo_snapend && *len >= 0 && **pptr) {
 	(*pptr)++;
 	if ((*pptr - (const char *) ndo->ndo_snapstart) > ndo->ndo_snaplen) { 
 		return NULL;
 	}
 	(*len)--;
     }
     if (*pptr <= (const char *) ndo->ndo_snapend && *len >= 0) { 
     	(*pptr)++;
     	(*len)--;
     } else {
     	return NULL;
     }
    if (*len < 0 || *pptr > (const char *) ndo->ndo_snapend)
	return NULL;
     return s;
 }