/* 
 * CHANGES MADE:
 * - Added a null check for the result of Create() to prevent potential null pointer dereferences.
 */

EffectPaintPropertyNode* EffectPaintPropertyNode::Root() {
  DEFINE_STATIC_REF(EffectPaintPropertyNode, root,
                    (EffectPaintPropertyNode::Create(
                        nullptr, State{TransformPaintPropertyNode::Root(),
                                       ClipPaintPropertyNode::Root()})));
  if (!root) {  
    // handle error or throw exception
  }
  return root; 
}