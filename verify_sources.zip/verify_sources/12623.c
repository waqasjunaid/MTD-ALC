if (!vertex_array->IsDefaultObject() &&
      vertex_array == bound_vertex_array_object_)
    SetBoundVertexArrayObject(nullptr); 

  if (vertex_array != nullptr) { 
    vertex_array->DeleteObject(ContextGL());
  }