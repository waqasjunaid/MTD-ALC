if (!view)
        return;
    IntRect viewRect = view->visibleContentRect();
    FrameView* overlayView = overlayPage() ? overlayPage()->mainFrame()->view() : nullptr; 

    if (!overlayView) {
        // Handle the case where overlayView is null
        return;
    }