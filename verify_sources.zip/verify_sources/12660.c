* - Added input validation for obj and table
 * - Added error handling for g_hash_table_foreach
 */

my_object_str_hash_len (MyObject *obj, GHashTable *table, guint *len, GError **error)
{
  if (!obj || !table) { 
    g_set_error_literal(error, MY_ERROR_DOMAIN, MY_ERROR_CODE, "Invalid input");
    return FALSE;
  }
  
  *len = 0;
  if (!g_hash_table_foreach (table, hash_foreach, len)) { 
    g_set_error_literal(error, MY_ERROR_DOMAIN, MY_ERROR_CODE, "Failed to iterate over hash table");
    return FALSE;
  }
  
  return TRUE;
}