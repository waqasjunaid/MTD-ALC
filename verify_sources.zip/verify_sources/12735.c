double upload_rate = form_was_autofilled ? GetPositiveUploadRate() :
                                              GetNegativeUploadRate();
  
  // FIX [CWE-20]: Validate input to prevent unexpected behavior
  if (upload_rate < 0.0 || upload_rate > 1.0) {
    VLOG(1) << "AutofillDownloadManager: Invalid upload rate.";
    return false;
  }