* - Added bounds checks for input parameters to prevent potential integer overflows.
 */

void StoreAccumulatedContentLength(int received_content_length,
                                   int original_content_length,
                                   bool data_reduction_proxy_was_used) {
  if (received_content_length < 0 || original_content_length < 0) {  
    return;
  }
  BrowserThread::PostTask(BrowserThread::UI, FROM_HERE,
      base::Bind(&UpdateContentLengthPrefs,
                 received_content_length, original_content_length,
                data_reduction_proxy_was_used));
}