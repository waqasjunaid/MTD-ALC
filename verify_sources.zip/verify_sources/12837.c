/* 
 * Changes made:
 * - Added bounds checking to prevent integer overflow
 */

static uint32_t readU32(const uint8_t* data, size_t offset) {
    if (offset > SIZE_MAX - 4) {  
        // handle_overflow(); /* TODO: implement error handling */
        return 0; /* temporary fix, replace with proper error handling */
    }
    uint32_t result = data[offset] << 24 | data[offset + 1] << 16 | data[offset + 2] << 8 | data[offset + 3];
    if (result < 0) {  
        // handle_overflow(); /* TODO: implement error handling */
        return 0; /* temporary fix, replace with proper error handling */
    }
    return result;
}