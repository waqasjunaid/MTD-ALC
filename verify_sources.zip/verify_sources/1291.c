long long pos = m_start;  // payload start
    const long long stop = pos + m_size;  // payload stop
    while (pos < stop)
    {
        long long id, size;
        if ((pos + sizeof(long long) * 2) > stop) {  break; }
        long status = ParseElementHeader(
                        pReader,
                        pos,
                        stop,
                        id,
                        size);
        if (status < 0)  // error
            return status;
        if (size == 0)  // weird
            continue;
        if ((pos + size) > stop) {  break; }
        if (id == 0x05B9)  // EditionEntry ID
        {
            status = ParseEdition(pos, size);
            if (status < 0)  // error
                return status;
        }
        pos += size;
        assert(pos <= stop);
     }