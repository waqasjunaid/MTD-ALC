if (response_code != net::HTTP_OK) {
     LOG(WARNING) << "Received error when allocating relay session: "
                 << response_code;
     TryCreateRelaySession();
     return;
   }