/*
 * CHANGES:
 * - Added input validation for playback_rate
 */

void TestPlaybackRate(double playback_rate) {
    if (playback_rate <= 0.0) { 
        // Handle invalid playback rate, e.g., return an error or set to a default value
        return;
    }

    static const int kDefaultBufferSize = kSamplesPerSecond / 10;
    static const int kDefaultFramesRequested = 5 * kSamplesPerSecond;

    TestPlaybackRate(playback_rate, kDefaultBufferSize,
                     kDefaultFramesRequested);
}