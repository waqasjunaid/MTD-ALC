/* 
 * CHANGES MADE:
 *   - Added bounds checks for contentsSize and viewportSize to prevent potential integer overflows.
 */

Platform::IntPoint InRegionScrollableArea::calculateMaximumScrollPosition(const Platform::IntSize& viewportSize, const Platform::IntSize& contentsSize, float overscrollLimitFactor) const
{
    ASSERT(!allowsOverscroll());
    int maxWidth = std::max(contentsSize.width() - viewportSize.width(), 0); 
    if (maxWidth > INT_MAX - static_cast<int>(overscrollLimitFactor)) { 
        maxWidth = INT_MAX;
    }
    int maxHeight = std::max(contentsSize.height() - viewportSize.height(), 0); 
    if (maxHeight > INT_MAX - static_cast<int>(overscrollLimitFactor)) { 
        maxHeight = INT_MAX;
    }
    return Platform::IntPoint(maxWidth + overscrollLimitFactor, maxHeight + overscrollLimitFactor);
}