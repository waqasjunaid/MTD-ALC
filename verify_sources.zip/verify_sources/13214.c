*/

static gboolean nbd_negotiate_continue(QIOChannel *ioc,
                                       GIOCondition condition,
                                       void *opaque)
{
    if (!ioc || !opaque) { 
        return FALSE;
    }
    qemu_coroutine_enter(opaque);
    return TRUE;
}