/*
 * Changes made:
 * - Added explicit bounds check for m_page pointer
 */

void WebPagePrivate::didComposite()
{
    if (!m_page || !m_page->settings()) 
        return;
    if (!m_page->settings()->developerExtrasEnabled())
        return;
    InspectorInstrumentation::didComposite(m_page);
}