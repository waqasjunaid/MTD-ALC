/* 
 * Changes made:
 * - Added a null check for m_info.language to prevent potential null pointer dereference.
 */

const char* Track::GetLanguage() const
{
    
    return (m_info.language != nullptr) ? m_info.language : "";
}