/* 
 * CHANGES MADE:
 * - Added explicit bounds checks for input values 'x' and 'y'
 */

bool InputWindowInfo::frameContainsPoint(int32_t x, int32_t y) const {
    
    if (x < INT32_MIN || x > INT32_MAX || y < INT32_MIN || y > INT32_MAX) {
        return false; /* Invalid input values */
    }
    return x >= frameLeft && x <= frameRight
            && y >= frameTop && y <= frameBottom;
}