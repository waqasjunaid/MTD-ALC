static int ghash_final(struct shash_desc *desc, u8 *dst)
{
	struct ghash_desc_ctx *dctx = shash_desc_ctx(desc);
 	struct ghash_ctx *ctx = crypto_shash_ctx(desc->tfm);
 	u8 *buf = dctx->buffer;
 
 	ghash_flush(ctx, dctx);
 	size_t len = GHASH_BLOCK_SIZE; 
 	memcpy(dst, buf, (len < sizeof(buf)) ? len : sizeof(buf)); 
 
	return 0;
}