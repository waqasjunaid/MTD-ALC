* Changes made:
 * - Added bounds check for pointer operation on line 5
 */

static int getStrrtokenPos(char* str, int savedPos)
 {
 	int result =-1;
 	int i;
 	if (str == NULL || savedPos < 0) { 
 		return -1;
 	}
 	for(i=savedPos-1; i>=0 && i < strlen(str); i--) { 
 		if(isIDSeparator(*(str+i)) ){
 			/* delimiter found; check for singleton */
			if(i>=2 && isIDSeparator(*(str+i-2)) ){
				/* a singleton; so send the position of token before the singleton */
				result = i-2;
			} else {
				result = i;
			}
			break;
		}
	}
	if(result < 1){
		/* Just in case invalid locale e.g. '-x-xyz' or '-sl_Latn' */
		result =-1;
	}
	return result;
}