kInitialMedianInMs),
       outstanding_recomputation_timer_(
          base::MakeUnique<base::Timer>(false /* retain_user_task */,
                                         false /* is_repeating */)),
       tick_clock_(new (std::nothrow) base::DefaultTickClock()), 
       weak_ptr_factory_(this) {
  if (!tick_clock_) { 
    // Handle error or throw exception
  }
}