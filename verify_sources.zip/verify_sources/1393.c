/* 
 * Changes made:
 * - Added bounds checks for payload and element sizes
 */

Chapters::Chapters(
    Segment* pSegment,
    long long payload_start,
    long long payload_size,
    long long element_start,
    long long element_size) :
    m_pSegment(pSegment),
    m_start(payload_start),
    m_size((payload_size > 0 && payload_size <= INT64_MAX) ? payload_size : 0), 
    m_element_start(element_start),
    m_element_size((element_size > 0 && element_size <= INT64_MAX) ? element_size : 0), 
    m_editions(NULL),
    m_editions_size(0),
    m_editions_count(0)
{
}