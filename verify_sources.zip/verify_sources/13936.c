union {
		void *ptr;
		unsigned long addr;
	} u;

	if (!atomic_pool) {
		WARN(1, "coherent pool not initialised!\n");
		return NULL;
	}