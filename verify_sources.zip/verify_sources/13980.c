* Changes made:
 * - Added bounds checks for pointer operations
 */

hash_foreach_mangle_dict_of_strings (gpointer key, gpointer val, gpointer user_data)
{
  GHashTable *out = (GHashTable*) user_data;
  if (out == NULL) {  
    return; 
  }
  
  GHashTable *in_dict = (GHashTable *) val;
  if (in_dict == NULL) {  
    return; 
  }
  
  HashAndString *data = g_new0 (HashAndString, 1);
  if (data == NULL) {  
    return; 
  }
  
  data->string = (gchar*) key;
  if (key == NULL) {  
    g_free(data); 
    return; 
  }
  
  data->hash = g_hash_table_new_full (g_str_hash, g_str_equal,
                                            g_free, g_free);
  if (data->hash == NULL) {  
    g_free(data); 
    return; 
  }
  
  g_hash_table_foreach (in_dict, hash_foreach_prepend_string, data);
  g_hash_table_insert(out, g_strdup ((gchar*) key), data->hash);
}