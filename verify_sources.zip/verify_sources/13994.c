* Changes made:
 * - Added bounds checking for array index 'i' to prevent out-of-bounds access.
 */

static void unix_detach_fds(struct scm_cookie *scm, struct sk_buff *skb)
{
	int i;

	scm->fp = UNIXCB(skb).fp;
	UNIXCB(skb).fp = NULL;
 
	for (i = scm->fp->count-1; i >= 0; i--) {
		if ((size_t)i < scm->fp->count) { 
			unix_notinflight(scm->fp->fp[i]);
		}
	}
}