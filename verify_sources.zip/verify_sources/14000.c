/* 
 * Changes made:
 * - Added bounds check for pointer operation on 'address' before calling pageFromObject
 */

void HeapAllocator::backingFree(void* address) {
  if (!address)
    return;

  ThreadState* state = ThreadState::current();
  if (state->sweepForbidden())
    return;
  ASSERT(!state->isInGC());

  if (address < (void*)0x10000000 || address > (void*)0xffffffffffffffff) { 
    return;
  }

  BasePage* page = pageFromObject(address);
  if (page->isLargeObjectPage() || page->arena()->getThreadState() != state)
     return;
 
   HeapObjectHeader* header = HeapObjectHeader::fromPayload(address);
  ASSERT(header->checkHeader());
   NormalPageArena* arena = static_cast<NormalPage*>(page)->arenaForNormalPage();
   state->promptlyFreed(header->gcInfoIndex());
   arena->promptlyFreeObject(header);
}