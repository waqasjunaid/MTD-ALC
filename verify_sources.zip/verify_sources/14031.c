/*
 * Changes made:
 * - Added bounds check for division by zero
 */

void MediaControlsProgressView::HandleSeeking(
    const gfx::Point& location_in_bar) {
  double progress_bar_width = progress_bar_->width();
  if (progress_bar_width == 0.0) { 
    return;
  }
  double seek_to_progress =
      static_cast<double>(location_in_bar.x()) / progress_bar_width; 
  seek_callback_.Run(seek_to_progress);
}