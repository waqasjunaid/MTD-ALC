void Initialize(ChannelLayout channel_layout, int bits_per_channel) {
     if (bits_per_channel <= 0 || channel_layout < ChannelLayout::MONO ||
         channel_layout > ChannelLayout::MAX) { 
         // Handle error or throw exception
         return;
     }
 
     AudioParameters params(
         media::AudioParameters::AUDIO_PCM_LINEAR, channel_layout,
        kSamplesPerSecond, bits_per_channel, kRawDataSize);
 
     algorithm_.Initialize(1, params, base::Bind(
         &AudioRendererAlgorithmTest::EnqueueData, base::Unretained(this)));
    EnqueueData();
  }