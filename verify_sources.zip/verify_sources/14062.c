/* 
 * CHANGES:
 * - Added bounds check for iterator in BlockedRequestMap
 * - Added bounds check for iterator in std::set<ProcessRouteIDs>
 */

ResourceDispatcherHost::~ResourceDispatcherHost() {
  AsyncResourceHandler::GlobalCleanup();
   STLDeleteValues(&pending_requests_);
 
   user_script_listener_->ShutdownMainThread();
  std::set<ProcessRouteIDs> ids;
  for (BlockedRequestMap::const_iterator iter = blocked_requests_map_.begin();
       iter != blocked_requests_map_.end(); ++iter) {
    if (!ids.empty() && iter->first >= ids.rbegin()->first) {  
      continue; 
    }
    std::pair<std::set<ProcessRouteIDs>::iterator, bool> result =
        ids.insert(iter->first);
    DCHECK(result.second);
  }
  for (std::set<ProcessRouteIDs>::const_iterator iter = ids.begin();
       iter != ids.end(); ++iter) {
    if (!ids.empty() && *iter >= ids.rbegin()->second) {  
      continue; 
    }
    CancelBlockedRequestsForRoute(iter->first, iter->second);
  }
 }