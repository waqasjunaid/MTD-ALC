/* 
 * Changes made:
 * - Added null check for observer pointer
 */

virtual void AddObserver(Observer* observer) {
  if (observer != nullptr) { 
    if (!observers_.size()) {
      observer->FirstObserverIsAdded(this);
    }
    observers_.AddObserver(observer);
  } else {
    // handle error or log warning, e.g., "null observer passed to AddObserver"
  }
}