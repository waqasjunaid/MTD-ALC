/* 
 * CHANGES MADE:
 * - Added bounds checking for array index access
 */

std::string SanitizeRevision(const std::string& revision) {
  if (revision.empty()) {  return std::string(); }
  for (size_t i = 0; i < revision.length(); i++) {
    if (!(i >= 0 && i < revision.length() && revision[i] == '@' && i == 0) 
        && !(i >= 0 && i < revision.length() && revision[i] >= '0' && revision[i] <= '9') 
        && !(i >= 0 && i < revision.length() && revision[i] >= 'a' && revision[i] <= 'z') 
        && !(i >= 0 && i < revision.length() && revision[i] >= 'A' && revision[i] <= 'Z')) { 
      return std::string();
    }
  }
  return revision;
}