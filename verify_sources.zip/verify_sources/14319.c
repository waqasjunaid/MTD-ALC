/* 
 * CHANGES MADE:
 * - Added a null check for render_frame_ to prevent potential crashes.
 */

void DistillerNativeJavaScript::EnsureServiceConnected() {
  if (!distiller_js_service_) {
    if (render_frame_ && render_frame_->GetServiceRegistry()) { 
      render_frame_->GetServiceRegistry()->ConnectToRemoteService(
          mojo::GetProxy(&distiller_js_service_));
    }
  }
}