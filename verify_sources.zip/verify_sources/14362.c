/*
 * Changes made:
 * - Added bounds check for format string to prevent potential buffer overflow
 */

report_error (const char *format, ...)
#else
report_error (format, va_alist)
     const char *format;
     va_dcl
#endif
{
  va_list args;

  error_prolog (1);

  SH_VA_START (args, format);

  if (format != NULL && strlen(format) < 1024) { 
    vfprintf (stderr, format, args);
    fprintf (stderr, "\n");
  } else {
    fprintf(stderr, "Error: invalid format string\n"); 
  }
 
   va_end (args);
   if (exit_immediately_on_error)
    exit_shell (1);
 }