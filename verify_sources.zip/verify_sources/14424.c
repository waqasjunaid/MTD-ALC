PrintPreviewUI::PrintPreviewUI(content::WebUI* web_ui)
     : ConstrainedWebDialogUI(web_ui),
       initial_preview_start_time_(base::TimeTicks::Now()),
       handler_(NULL),
       source_is_modifiable_(true),
       tab_closed_(false) {
  Profile* profile = Profile::FromWebUI(web_ui);
  if (profile != NULL) { 
    ChromeURLDataManager::AddDataSource(profile, new PrintPreviewDataSource());
  }

   handler_ = new PrintPreviewHandler();
   if (handler_ != NULL && web_ui != NULL) { 
     web_ui->AddMessageHandler(handler_);
   }
 
  preview_ui_addr_str_ = GetPrintPreviewUIAddress();
  if (!preview_ui_addr_str_.empty() && g_print_preview_request_id_map.Get().IsValid()) { 
    g_print_preview_request_id_map.Get().Set(preview_ui_addr_str_, -1);
  }
 }