* Changes made:
 * - Added input validation for 'size' parameter to prevent potential integer overflow.
 */

void* ipc_alloc(int size)
{
	void* out;
	if (size <= 0) {  
		return NULL; 
	}
	if(size > PAGE_SIZE)
 		out = vmalloc(size);
 	else
		out = kmalloc(size, GFP_KERNEL);
	return out;
}