/*
 * Changes made:
 * - Added a check to ensure the iterator is not equal to end() before dereferencing it
 */

void UserSelectionScreen::OnBeforeUserRemoved(const AccountId& account_id) {
  for (user_manager::UserList::iterator it = users_.begin(); it != users_.end();
       ++it) {
    if (it != users_.end() && (*it)->GetAccountId() == account_id) { 
      users_.erase(it);
      break;
    }
  }
}