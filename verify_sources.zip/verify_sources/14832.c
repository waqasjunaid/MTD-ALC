if (!port_id) { 
    // Handle null port_id error
    return;
  }