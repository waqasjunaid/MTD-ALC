!m->ReadInt(iter, &frames_per_buffer) ||
      !m->ReadInt(iter, &channels))
    return false;

  // Check for valid integer values to prevent overflows
  if (format < 0 || format > INT_MAX ) {
    return false;
  }