/* 
 * CHANGES:
 * - Added explicit bounds checks around pointer operations to prevent potential NULL pointer dereferences.
 */

bool MediaElementAudioSourceHandler::WouldTaintOrigin() {
  if (MediaElement() && MediaElement()->GetWebMediaPlayer()) { 
    if (MediaElement()->GetWebMediaPlayer()->DidPassCORSAccessCheck()) {
      return false;
    }
  }
  if (MediaElement() && !MediaElement()->HasSingleSecurityOrigin()) { 
    return true;
  }
  if (Context() && MediaElement() && MediaElement()->currentSrc()) { 
    return Context()->WouldTaintOrigin(MediaElement()->currentSrc());
  }
  return false; 
}