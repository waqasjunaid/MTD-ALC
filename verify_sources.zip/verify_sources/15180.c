/* 
 * CHANGES MADE:
 * - Added a null check for m_pSeekHead to prevent potential null pointer dereferences.
 */

const SeekHead* Segment::GetSeekHead() const
{
    if (m_pSeekHead == nullptr) {  
        return nullptr; 
    }
    return m_pSeekHead;
}