/*
 * Changes made:
 * - Added bounds checking for array index access in the `text` string.
 */

void TypingCommand::insertText(Document& document,
                               const String& text,
                               Options options,
                               TextCompositionType composition,
                               const bool isIncrementalInsertion) {
  LocalFrame* frame = document.frame();
  DCHECK(frame);

  if (!text.isEmpty()) {
    size_t idx = 0; 
    if (idx >= 0 && (size_t)idx < text.length()) { 
      document.frame()->spellChecker().updateMarkersForWordsAffectedByEditing(
          isSpaceOrNewline(text[idx])); 
    }
  }

  insertText(document, text,
             frame->selection().computeVisibleSelectionInDOMTreeDeprecated(),
             options, composition, isIncrementalInsertion);
}