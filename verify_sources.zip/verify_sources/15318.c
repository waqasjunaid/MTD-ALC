* Changes made:
 * - Added a null check for encT to prevent potential NULL pointer dereference.
 */

static void prefetch_enc(void)
{
  if (encT != NULL) { 
    prefetch_table((const void *)encT, sizeof(encT)); 
  }
}