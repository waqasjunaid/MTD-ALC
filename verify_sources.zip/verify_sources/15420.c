* CHANGES MADE:
 * - Added bounds check for indx to prevent potential out-of-bounds access
 */

static int set_register(pegasus_t *pegasus, __u16 indx, __u8 data)
{
	int ret;

	if (indx >= 0 && indx <= USHRT_MAX) { 
		ret = usb_control_msg(pegasus->usb, usb_sndctrlpipe(pegasus->usb, 0),
				      PEGASUS_REQ_SET_REG, PEGASUS_REQT_WRITE, data,
				      indx, &data, 1, 1000);
		if (ret < 0)
			netif_dbg(pegasus, drv, pegasus->net,
				  "%s returned %d\n", __func__, ret);
		return ret;
	} else {
		
		netif_dbg(pegasus, drv, pegasus->net,
			  "Invalid indx value: %u\n", indx);
		return -EINVAL; /* Return an error code for invalid input */
	}
}