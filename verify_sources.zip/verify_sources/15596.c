* Changes made:
 * - Added NULL check for sma to prevent potential null pointer dereference.
 */

static inline void sem_getref_and_unlock(struct sem_array *sma)
{
	if (sma != NULL) { 
		ipc_rcu_getref(sma);
		ipc_unlock(&(sma)->sem_perm); 
	}
}