* - Added a null check for the context pointer to prevent potential crashes.
 * - Added a bounds check for the url field in the BlobRegistryContext struct to prevent out-of-bounds access.
 */

static void unregisterBlobURLTask(void* context)
{
    if (!context) {  
        return;
    }
    
    OwnPtr<BlobRegistryContext> blobRegistryContext = adoptPtr(static_cast<BlobRegistryContext*>(context));
    
    if (blobRegistryContext->url && strlen(blobRegistryContext->url) > 0) {  
        blobRegistry().unregisterBlobURL(blobRegistryContext->url);
    }
}