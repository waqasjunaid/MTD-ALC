* Changes made:
 * - Added NULL check for malloc return value to prevent CWE-476
 */

SQLWCHAR* _multi_string_alloc_and_expand( LPCSTR in )
{
    SQLWCHAR *chr = NULL; 
    int len = 0;
 
     if ( !in )
     {
        return in;
     }
     
     while ( in[ len ] != 0 || in[ len + 1 ] != 0 )
    {
        len ++;
    }

    chr = malloc(sizeof( SQLWCHAR ) * ( len + 2 )); 
    if (!chr) { 
        return NULL; 
    }

    len = 0;
    while ( in[ len ] != 0 || in[ len + 1 ] != 0 )
    {
        chr[ len ] = in[ len ];
        len ++;
    }
    chr[ len ++ ] = 0;
    chr[ len ++ ] = 0;

    return chr;
}