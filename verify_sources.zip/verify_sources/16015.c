/*
 * CHANGES:
 * - Added bounds check for strlen(fmt) to prevent out-of-bounds access
 */

static void die(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    size_t len = strlen(fmt); 
    if (len > 0 && fmt[len - 1] != '\n') 
        printf("\n");
    exit(EXIT_FAILURE);
}