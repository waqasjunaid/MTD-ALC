/* 
 * Changes made:
 * - Added bounds check for m_directoryName to prevent potential buffer overflow
 * - Added validation for completeURL before using it in m_replaceLinks->get()
 */

void LinkChangeSerializerMarkupAccumulator::appendAttribute(StringBuilder& result, Element* element, const Attribute& attribute, Namespaces* namespaces)
{
    if (m_replaceLinks && element->isURLAttribute(attribute) && !element->isJavaScriptURLAttribute(attribute)) {
        String completeURL = m_document->completeURL(attribute.value());
        if (!completeURL.isEmpty() && m_replaceLinks->contains(completeURL)) { 
            result.append(' ');
            result.append(attribute.name().toString());
            result.appendLiteral("=\"");
            if (!m_directoryName.isEmpty()) {
                size_t directoryNameLength = m_directoryName.length(); 
                if (directoryNameLength > 0) {
                    result.appendLiteral("./");
                    result.append(m_directoryName.substring(0, directoryNameLength)); 
                    result.append('/');
                }
            }
            String replacement = m_replaceLinks->get(completeURL); 
            if (!replacement.isEmpty()) {
                result.append(replacement);
            }
            result.appendLiteral("\"");
            return;
        }
    }
    MarkupAccumulator::appendAttribute(result, element, attribute, namespaces);
}