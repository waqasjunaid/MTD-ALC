/* 
 * CHANGES MADE:
 * - Added checks for NULL pointers before calling vpx_free to prevent potential crashes.
 */

static void TearDownTestCase() {
    if (source_data_ != NULL) { 
        vpx_free(source_data_);
        source_data_ = NULL;
    }
    if (reference_data_ != NULL) { 
        vpx_free(reference_data_);
        reference_data_ = NULL;
    }
}