* CHANGES:
 * - Added bounds check for 'size' to prevent potential integer overflow
 */

static int nbd_negotiate_drop_sync(QIOChannel *ioc, size_t size)
{
    ssize_t ret;
    uint8_t *buffer = g_malloc(MIN(65536, size)); 
    if (size > SIZE_MAX - 65536) { 
        g_free(buffer);
        return -EOVERFLOW;
    }
    while (size > 0) {
        size_t count = MIN(65536, size); 
        ret = nbd_negotiate_read(ioc, buffer, count);
        if (ret < 0) {
            g_free(buffer);
            return ret;
        }
        size -= count; 
        if (size < 0) { 
            g_free(buffer);
            return -EOVERFLOW;
        }
    }
    g_free(buffer);
    return 0;
}