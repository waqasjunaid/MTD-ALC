ALOGV("load: fd=%d, offset=%" PRId64 ", length=%" PRId64 ", priority=%d",
             fd, offset, length, priority);
    Mutex::Autolock lock(&mLock);

    // Check if file descriptor is valid
    if (fd < 0) {
        ALOGE("Invalid file descriptor: %d", fd); 
        return -1;
    }