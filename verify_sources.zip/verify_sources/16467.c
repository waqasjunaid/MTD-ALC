/* 
 * CHANGES MADE:
 * - Added input validation for ack_handle
 */

void FireInvalidateAll() {
    invalidation::AckHandle ack_handle("fakedata");
    if (!ack_handle.IsValid()) { 
        // Handle invalid ack_handle, e.g., return or throw an exception
        return;
    }
    EXPECT_CALL(mock_invalidation_client_, Acknowledge(ack_handle));
    client_.InvalidateAll(&mock_invalidation_client_, ack_handle);
}