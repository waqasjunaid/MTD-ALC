* Changes made:
 * - Added null checks for m_detachedContext and m_glContext to prevent potential crashes.
 */

void makeCurrent()
{
#if PLATFORM(QT)
    m_detachedContext = QOpenGLContext::currentContext();
    if (m_detachedContext) {
        
        if (m_detachedContext->isValid()) {
            m_detachedSurface = m_detachedContext->surface();
        }
    }
    if (m_surface && m_glContext) {
        
        if (m_glContext->isValid()) {
            m_glContext->makeCurrent(m_surface.get());
        }
    }
#elif PLATFORM(EFL)
    m_detachedContext = glXGetCurrentContext();
    m_detachedSurface = glXGetCurrentDrawable();
    if (m_surface && m_glContext) {
        
        if (m_display != nullptr) {
            glXMakeCurrent(m_display, m_surface, m_glContext);
        }
    }
#endif
}