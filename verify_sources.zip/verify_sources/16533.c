if (I965HybridDrvVideoPath) {
        void* handle2 = dlopen(I965HybridDrvVideoPath, RTLD_NOW|RTLD_GLOBAL|RTLD_NODELETE); 
        if (!handle2) {
          // Handle error
        }
      }