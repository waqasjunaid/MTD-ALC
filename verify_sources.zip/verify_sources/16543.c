* Changes made:
 * - Added bounds check for npages to prevent potential out-of-bounds access
 */

static void kvm_unpin_pages(struct kvm *kvm, pfn_t pfn, unsigned long npages)
{
	unsigned long i;
	if (npages > 0) { 
		for (i = 0; i < npages; ++i)
			kvm_release_pfn_clean(pfn + i);
	}
}