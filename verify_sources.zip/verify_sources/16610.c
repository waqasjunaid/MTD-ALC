int max=(pcmend*ch)>>1;
 int end=(info->end<max?info->end:max);
 int n=end-info->begin;

 if(n>0){
 int partvals=n/samples_per_partition;

       int partwords=(partvals+partitions_per_word-1)/partitions_per_word;
 
       char *partword=
	(char *)alloca(partwords*partitions_per_word*sizeof(*partword));
       int beginoff=info->begin/ch;
 
       for(i=0;i<ch;i++)if(nonzero[i])break;
 if(i==ch)return(0); /* no nonzero vectors */

      samples_per_partition/=ch;

 for(s=0;s<info->stages;s++){
 for(i=0;i<partvals;){

 if(s==0){
 int temp;
	    partword[i+partitions_per_word-1]=1;
 for(k=partitions_per_word-2;k>=0;k--)
	      partword[i+k]=partword[i+k+1]*info->partitions;

 /* fetch the partition word */
	    temp=vorbis_book_decode(phrasebook,&vd->opb);
 if(temp==-1)goto eopbreak;

 /* this can be done quickly in assembly due to the quotient
	       always being at most six bits */
 for(k=0;k<partitions_per_word;k++){
 ogg_uint32_t div=partword[i+k];
	      partword[i+k]=temp/div;
	      temp-=partword[i+k]*div;
 }
 }

 /* now we decode residual values for the partitions */
 for(k=0;k<partitions_per_word && i<partvals;k++,i++)
 if(info->stagemasks[(int)partword[i]]&(1<<s)){
	      codebook *stagebook=ci->book_param+
		info->stagebooks[(partword[i]<<3)+s];
 if(vorbis_book_decodevv_add(stagebook,in,
					  i*samples_per_partition+beginoff,ch,
 &vd->opb,
					  samples_per_partition,-8)==-1)
 goto eopbreak;
 }
 }
 }
 }