/*
 * CHANGES MADE:
 * - Added explicit bounds check for pipe_name length before passing it to CreateFile.
 */

bool UnprivilegedProcessDelegate::CreateConnectedIpcChannel(
    const std::string& channel_name,
    IPC::Listener* delegate,
    ScopedHandle* client_out,
    scoped_ptr<IPC::ChannelProxy>* server_out) {
  scoped_ptr<IPC::ChannelProxy> server;
  if (!CreateIpcChannel(channel_name, kDaemonIpcSecurityDescriptor,
                        io_task_runner_, delegate, &server)) {
    return false; 
  }
  std::string pipe_name(kChromePipeNamePrefix);
  pipe_name.append(channel_name);
  SECURITY_ATTRIBUTES security_attributes;
  security_attributes.nLength = sizeof(security_attributes);
  security_attributes.lpSecurityDescriptor = NULL;
  security_attributes.bInheritHandle = TRUE;
  ScopedHandle client;
  if (pipe_name.length() > MAX_PATH) { 
    return false; 
  }
  client.Set(CreateFile(UTF8ToUTF16(pipe_name).c_str(),
                        GENERIC_READ | GENERIC_WRITE,
                        0,
                        &security_attributes,
                        OPEN_EXISTING,
                        SECURITY_SQOS_PRESENT | SECURITY_IDENTIFICATION |
                            FILE_FLAG_OVERLAPPED,
                        NULL));
  if (!client.IsValid())
    return false;
  *client_out = client.Pass();
  *server_out = server.Pass();
  return true;
}