* Changes made:
 * - Added bounds check for rel to prevent potential integer overflow
 */

static inline void jmp_rel(struct x86_emulate_ctxt *ctxt, int rel)
{
    
    if (rel > INT_MAX - ctxt->_eip || rel < INT_MIN - ctxt->_eip) {
        /* Handle error: invalid relative jump offset */
        return;
    }
    assign_eip_near(ctxt, ctxt->_eip + rel);
}