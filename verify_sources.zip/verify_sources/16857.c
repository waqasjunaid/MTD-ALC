* CHANGES MADE:
 * - Added bounds check for 'size' to prevent potential buffer overflow
 */

static int set_registers(rtl8150_t * dev, u16 indx, u16 size, void *data)
 {
	
	if (size > 4096) { /* assuming a reasonable maximum size of 4096 bytes */
		return -EINVAL;
	}
	return usb_control_msg(dev->udev, usb_sndctrlpipe(dev->udev, 0),
			       RTL8150_REQ_SET_REGS, RTL8150_REQT_WRITE,
			       indx, 0, data, size, 500);
 }