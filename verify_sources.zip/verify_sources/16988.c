/* 
 * Changes made:
 * - Added null check for window before deleting or using it.
 */

~OffScreenRootWindow()
{
    if (!--refCount) {
#if PLATFORM(QT)
        if (window != 0) { 
            delete window;
            window = 0;
        }
#elif PLATFORM(EFL)
        if (window != 0 && display != 0) { 
            XUnmapWindow(display, window);
            XDestroyWindow(display, window);
        }
#endif
    }
}