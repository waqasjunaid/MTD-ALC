/* 
 * CHANGES MADE:
 * - Added bounds check for cJSON_New_Item() return value
 * - Added null check for cJSON_strdup() return value
 */

cJSON *cJSON_CreateString( const char *string )
{
	cJSON *item = cJSON_New_Item();
	if ( item ) { 
		item->type = cJSON_String;
		item->valuestring = cJSON_strdup( string );
		if (!item->valuestring) { 
			cJSON_Delete(item);
			return NULL;
		}
	}
	return item;
}