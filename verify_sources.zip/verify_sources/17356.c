*/

int svc_rdma_xdr_encode_error(struct svcxprt_rdma *xprt,
			      struct rpcrdma_msg *rmsgp,
			      enum rpcrdma_errcode err, __be32 *va)
{
	__be32 *startp = va;
	size_t max_len = 6; /* maximum number of elements that can be written */
	if (err == ERR_VERS) {
		max_len += 2; /* account for extra elements when err == ERR_VERS */
	}
	while (max_len > 0 && va != NULL) { 
		*va++ = rmsgp->rm_xid;
		if (--max_len == 0) break;
		*va++ = rmsgp->rm_vers;
		if (--max_len == 0) break;
		*va++ = xprt->sc_fc_credits;
		if (--max_len == 0) break;
		*va++ = rdma_error;
		if (--max_len == 0) break;
		*va++ = cpu_to_be32(err);
		if (err == ERR_VERS) {
			*va++ = rpcrdma_version; 
			if (--max_len > 0) *va++ = rpcrdma_version; 
		}
	}
	return (int)((unsigned long)va - (unsigned long)startp);
}