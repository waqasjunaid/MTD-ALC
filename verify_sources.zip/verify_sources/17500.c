params->page_size = gfx::Size(page_width_in_pixels, page_height_in_pixels);

  // FIX [CWE-190]: Prevent integer overflow by checking the result of ConvertUnitDouble.
  int margin_top_in_pixels = static_cast<int>(ConvertUnitDouble(
      margin_top_in_points, printing::kPointsPerInch, dpi));
  if (margin_top_in_pixels < 0) {
    margin_top_in_pixels = 0; 
  }