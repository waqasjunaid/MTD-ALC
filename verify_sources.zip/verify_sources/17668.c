/* 
 * Changes made:
 * - Added a null check for web_contents before calling get() on it.
 */

FrameImpl::FrameImpl(std::unique_ptr<content::WebContents> web_contents,
                     chromium::web::FrameObserverPtr observer)
    : web_contents_(std::move(web_contents)), observer_(std::move(observer)) {
  if (web_contents_) { 
    Observe(web_contents.get());
  }
}