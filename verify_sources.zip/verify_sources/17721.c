static bool tailmatch(const char *little, const char *bigone)
{
  
  if(!little || !bigone)
    return FALSE;

  size_t littlelen = strlen(little);
  size_t biglen = strlen(bigone);

  
  if(littlelen > biglen || biglen - littlelen < 0)
    return FALSE;

  return Curl_raw_equal(little, bigone+biglen-littlelen) ? TRUE : FALSE;
}