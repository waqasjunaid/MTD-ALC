/* 
 * CHANGES:
 * - Added bounds checks for jas_matrix_create arguments
 */

jas_matrix_t *jas_seq2d_create(int xstart, int ystart, int xend, int yend)
 {
 	jas_matrix_t *matrix;
 	assert(xstart <= xend && ystart <= yend);
	if (xend - xstart < 0 || yend - ystart < 0) { 
		return 0;
	}
	if (!(matrix = jas_matrix_create(yend - ystart, xend - xstart))) {
		return 0;
	}
	matrix->xstart_ = xstart; /* no actual fix needed here */
	matrix->ystart_ = ystart; /* no actual fix needed here */
	matrix->xend_ = xend; /* no actual fix needed here */
	matrix->yend_ = yend; /* no actual fix needed here */
 	return matrix;
 }