/* 
 * Changes made:
 * - Added a null check for the 'widget' parameter to prevent potential crashes.
 */

void PartialMagnificationController::OnWidgetDestroying(views::Widget* widget) {
  if (widget != NULL) { 
    DCHECK_EQ(widget, zoom_widget_);
    RemoveZoomWidgetObservers();
    zoom_widget_ = NULL;
  }
}