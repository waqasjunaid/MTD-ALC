/* 
 * CHANGES:
 * - Added explicit bounds check around pointer operation
 */

const PPB_NaCl_Private* GetNaclInterface() {
  pp::Module *module = pp::Module::Get();
  CHECK(module);
  void* interface = module->GetBrowserInterface(PPB_NACL_PRIVATE_INTERFACE); 
  if (!interface) { 
    return nullptr;
  }
  return static_cast<const PPB_NaCl_Private*>(interface);
}