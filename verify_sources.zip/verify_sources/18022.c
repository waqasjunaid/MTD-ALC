* - Added input validation for 'str' and 'r'
 */

void SplitString(const std::wstring& str,
                 wchar_t c,
                 std::vector<std::wstring>* r) {
  if (str.empty() || !r) { 
    return; // or throw an exception, depending on the desired behavior
  }
  SplitStringT(str, c, true, r);
}