* Changes made:
 * - Added explicit bounds check for multiplication overflow
 */

checked_xcalloc (size_t num, size_t size)
 {
    
    if (SIZE_MAX / num < size) {
        alloc_limit_assert ("checked_xcalloc", 0);
    } else {
        alloc_limit_assert ("checked_xcalloc", (num * size));
    }
     return xcalloc (num, size);
 }