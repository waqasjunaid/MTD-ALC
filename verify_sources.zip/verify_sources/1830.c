* - Replaced sprintf with snprintf to prevent buffer overflow (CWE-120)
 */

static ssize_t driver_override_show(struct device *dev,
 				    struct device_attribute *attr, char *buf)
 {
 	struct platform_device *pdev = to_platform_device(dev);
 
	return snprintf(buf, PAGE_SIZE, "%s\n", pdev->driver_override); 
 }