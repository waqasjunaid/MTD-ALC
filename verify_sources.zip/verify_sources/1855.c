* - Added explicit bounds checks for offset and profile->length
 */

static MagickOffsetType TIFFSeekCustomStream(const MagickOffsetType offset,
  const int whence,void *user_data)
{
  PhotoshopProfile
    *profile;

  profile=(PhotoshopProfile *) user_data;
  switch (whence)
  {
    case SEEK_SET:
    default:
    {
      if (offset < 0) 
        return(-1);
      profile->offset=offset;
      break;
     }
     case SEEK_CUR:
     {
       if ((profile->offset+offset) < 0 || 
           (profile->offset+offset) > MagickOffsetMaximum)
         return(-1);
       profile->offset+=offset;
      break;
    }
    case SEEK_END:
    {
      if (((MagickOffsetType) profile->length+offset) < 0 || 
          ((MagickOffsetType) profile->length+offset) > MagickOffsetMaximum)
        return(-1);
      profile->offset=profile->length+offset;
      break;
    }
  }

  if (profile->offset < 0 || profile->offset > MagickOffsetMaximum) 
    return(-1);

  return(profile->offset);
}