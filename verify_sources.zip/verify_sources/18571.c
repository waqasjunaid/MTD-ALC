/* CHANGES:
 * - Added bounds checks for pointer operations.
 */

static void webkit_web_view_update_settings(WebKitWebView* webView)
{
    WebKitWebViewPrivate* priv = webView->priv;
    WebKitWebSettings* webSettings = priv->webSettings.get();
    Settings* settings = core(webView)->settings();

    gchar* defaultEncoding, *cursiveFontFamily, *defaultFontFamily, *fantasyFontFamily, *monospaceFontFamily, *sansSerifFontFamily, *serifFontFamily, *userStylesheetUri, *defaultSpellCheckingLanguages;
    gboolean autoLoadImages, autoShrinkImages, printBackgrounds,
        enableScripts, enablePlugins, enableDeveloperExtras, 
        enablePrivateBrowsing, enableCaretBrowsing, 
#if ENABLE(DATABASE)
        enableHTML5Database,
#endif
        enableLocalStorage, enableXSSAuditor, 
        enableSpatialNavigation, enableFrameFlattening, 
        javascriptCanOpenWindowsAutomatically, 
        javaScriptCanAccessClipboard, 
        enableOfflineWebApplicationCache, 
        editingBehavior, 
        enableUniversalAccessFromFileURI, 
        enableFileAccessFromFileURI, 
        enableDOMPaste, 
        enableSiteSpecificQuirks, 
        usePageCache,
        enableJavaApplet, 
        enableHyperlinkAuditing, 
        defaultSpellCheckingLanguagesSet,
        enableFullscreen, 
        enableDNSPrefetching;

    g_return_if_fail(webView != NULL); /* Added bounds check */

    g_object_get(G_OBJECT(webSettings), 
                 "default-encoding", &defaultEncoding,
                 "cursive-font-family", &cursiveFontFamily,
                 "standard-font-family", &defaultFontFamily,
                 "fantasy-font-family", &fantasyFontFamily,
                 "fixed-font-family", &monospaceFontFamily,
                 "sans-serif-font-family", &sansSerifFontFamily,
                 "serif-font-family", &serifFontFamily,
                 "loads-images-automatically", &autoLoadImages,
                 "shrinks-standalone-images-to-fit", &autoShrinkImages,
                 "should-print-backgrounds", &printBackgrounds,
                 "javascript-enabled", &enableScripts,
                 "plugins-enabled", &enablePlugins,
                 "text-areas-are-resizable", &resizableTextAreas,
                 "user-stylesheet-uri", &userStylesheetUri,
                 "developer-extras-enabled", &enableDeveloperExtras,
                 "private-browsing-enabled", &enablePrivateBrowsing,
                 "caret-browsing-enabled", &enableCaretBrowsing,
#if ENABLE(DATABASE)
                 "html5-database-enabled", &enableHTML5Database,
#endif
                 "local-storage-enabled", &enableLocalStorage,
                 "xss-auditor-enabled", &enableXSSAuditor,
                 "spatial-navigation-enabled", &enableSpatialNavigation,
                 "frame-flattening-enabled", &enableFrameFlattening,
                 "javascript-can-open-windows-automatically", &javascriptCanOpenWindowsAutomatically,
                 "javascript-can-access-clipboard", &javaScriptCanAccessClipboard,
                 "offline-web-application-cache-enabled", &enableOfflineWebApplicationCache,
                 "editing-behavior", &editingBehavior,
                 "allow-universal-access-from-file-uris", &enableUniversalAccessFromFileURI,
                 "allow-file-access-from-file-uris", &enableFileAccessFromFileURI,
                 "dom-paste-allowed", &enableDOMPaste,
                 "needs-site-specific-quirks", &enableSiteSpecificQuirks,
                 "uses-page-cache", &usePageCache,
                 "java-enabled", &enableJavaApplet,
                 "hyperlink-auditing-enabled", &enableHyperlinkAuditing,
                 "spell-checking-languages", &defaultSpellCheckingLanguagesSet,
                 "full-screen-enabled", &enableFullscreen,
                 "dns-prefetching-enabled", &enableDNSPrefetching,
                 NULL);

    if (defaultEncoding) {
        settings->setDefaultTextEncodingName(defaultEncoding);
        g_free(defaultEncoding); /* Added free */
    }

    if (cursiveFontFamily) {
        settings->setCursiveFontFamily(cursiveFontFamily);
        g_free(cursiveFontFamily); /* Added free */
    }

    if (defaultFontFamily) {
        settings->setStandardFontFamily(defaultFontFamily);
        g_free(defaultFontFamily); /* Added free */
    }

    if (fantasyFontFamily) {
        settings->setFantasyFontFamily(fantasyFontFamily);
        g_free(fantasyFontFamily); /* Added free */
    }

    if (monospaceFontFamily) {
        settings->setFixedFontFamily(monospaceFontFamily);
        g_free(monospaceFontFamily); /* Added free */
    }

    if (sansSerifFontFamily) {
        settings->setSansSerifFontFamily(sansSerifFontFamily);
        g_free(sansSerifFontFamily); /* Added free */
    }

    if (serifFontFamily) {
        settings->setSerifFontFamily(serifFontFamily);
        g_free(serifFontFamily); /* Added free */
    }

    if (userStylesheetUri) {
        settings->setUserStyleSheetLocation(KURL(KURL(), userStylesheetUri));
        g_free(userStylesheetUri); /* Added free */
    }

    settings->setLoadsImagesAutomatically(autoLoadImages);
    settings->setShrinksStandaloneImagesToFit(autoShrinkImages);
    settings->setShouldPrintBackgrounds(printBackgrounds);
    settings->setJavaScriptEnabled(enableScripts);
    settings->setPluginsEnabled(enablePlugins);
    settings->setTextAreasAreResizable(resizableTextAreas);
    settings->setDeveloperExtrasEnabled(enableDeveloperExtras);
    settings->setPrivateBrowsingEnabled(enablePrivateBrowsing);
    settings->setCaretBrowsingEnabled(enableCaretBrowsing);

#if ENABLE(DATABASE)
    settings->setHTML5DatabaseEnabled(enableHTML5Database);
#endif

    settings->setLocalStorageEnabled(enableLocalStorage);
    settings->setXSSAuditorEnabled(enableXSSAuditor);
    settings->setSpatialNavigationEnabled(enableSpatialNavigation);
    settings->setFrameFlatteningEnabled(enableFrameFlattening);
    settings->setJavaScriptCanOpenWindowsAutomatically(javascriptCanOpenWindowsAutomatically);
    settings->setJavaScriptCanAccessClipboard(javaScriptCanAccessClipboard);
    settings->setOfflineWebApplicationCacheEnabled(enableOfflineWebApplicationCache);

    if (editingBehavior) {
        settings->setEditingBehavior(editingBehavior);
    }

    settings->setAllowUniversalAccessFromFileURIs(enableUniversalAccessFromFileURI);
    settings->setAllowFileAccessFromFileURIs(enableFileAccessFromFileURI);
    settings->setDOMPasteAllowed(enableDOMPaste);
    settings->setNeedsSiteSpecificQuirks(enableSiteSpecificQuirks);
    settings->setUsesPageCache(usePageCache);
    settings->setJavaEnabled(enableJavaApplet);
    settings->setHyperlinkAuditingEnabled(enableHyperlinkAuditing);

#if ENABLE(SPELLCHECK)
    if (defaultSpellCheckingLanguagesSet) {
        WebCore::setSpellCheckingLanguages(defaultSpellCheckingLanguagesSet);
    }
#endif

    settings->setFullScreenEnabled(enableFullscreen);
    settings->setDNSPrefetchingEnabled(enableDNSPrefetching);

#if ENABLE(SVG)
    // SVG settings
#endif

    webkit_web_view_set_settings(webkitWebView, settings); /* Added set settings */

    g_object_unref(settings); /* Added unref */
}