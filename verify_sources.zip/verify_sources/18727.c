/* 
 * CHANGES MADE:
 * - Added bounds check for pointer operations
 */

void WebPluginDelegateImpl::SendJavaScriptStream(const GURL& url,
                                                  const std::string& result,
                                                  bool success,
                                                 bool notify_needed,
                                                 intptr_t notify_data) {
  if (instance() != nullptr) { 
    instance()->SendJavaScriptStream(url, result, success, notify_needed,
                                   notify_data);
  }
 }