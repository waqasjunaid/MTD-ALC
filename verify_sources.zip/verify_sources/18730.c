/*
 * Changes made:
 * - Added bounds checking for array index access
 */

const CuePoint* Cues::GetLast() const {
  if (m_cue_points == NULL)
     return NULL;
 
  if (m_count <= 0)
    return NULL;

   const long index = m_count - 1;
 
   CuePoint* const* const pp = m_cue_points;
  assert(pp);
 
   
   if (index < 0 || (size_t)index >= m_count) {
     return NULL; // or handle error
   }
 
   CuePoint* const pCP = pp[index];
  assert(pCP);
  assert(pCP->GetTimeCode() >= 0);
 
   return pCP;
 }