/*
 * CHANGES MADE:
 * - Added null pointer check for command_line
 */

virtual void SetUpCommandLine(CommandLine* command_line) {
    if (command_line != nullptr) { 
        GpuFeatureTest::SetUpCommandLine(command_line);
        command_line->AppendSwitch(switches::kEnableThreadedCompositing);
    }
}