/* 
 * CHANGES MADE:
 * - Added bounds check for frame_ pointer before using it.
 */

void FrameSelection::MoveRangeSelectionExtent(const IntPoint& contents_point) {
  if (ComputeVisibleSelectionInDOMTree().IsNone())
    return;

  if (!frame_) {  
    // Handle null frame_ case, e.g., log an error or throw an exception
    return;
  }

  SetSelection(
      SelectionInDOMTree::Builder(
          GetGranularityStrategy()->UpdateExtent(contents_point, frame_))
         .SetIsHandleVisible(true)
         .Build(),
      SetSelectionData::Builder()
         .SetShouldCloseTyping(true)
         .SetShouldClearTypingStyle(true)
         .SetDoNotClearStrategy(true)
         .SetSetSelectionBy(SetSelectionBy::kUser)
         .Build());
}