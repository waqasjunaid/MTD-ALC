/*
 * CHANGES:
 * - Added bounds check for remoteDescription.type() to prevent potential buffer overflow.
 */

void MockWebRTCPeerConnectionHandler::setRemoteDescription(const WebRTCVoidRequest& request, const WebRTCSessionDescriptionDescriptor& remoteDescription)
{
    if (!remoteDescription.isNull() && 
        remoteDescription.type().length() > 0 && 
        remoteDescription.type()[0] == 'a' && 
        strcmp(remoteDescription.type(), "answer") == 0) {
        m_remoteDescription = remoteDescription;
        postTask(new RTCVoidRequestTask(this, request, true));
    } else
        postTask(new RTCVoidRequestTask(this, request, false));
}