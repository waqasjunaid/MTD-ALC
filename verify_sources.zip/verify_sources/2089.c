if (*rsize > 17) { 
 			rdesc[12] = rdesc[17] = 0x03;
 		}