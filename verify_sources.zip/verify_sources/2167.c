/* 
 * Changes made:
 * - Added explicit null check for frame_host_ before setting it to nullptr
 * - Added explicit bounds check around pointer operation for agent_ptr_
 */

void RenderFrameDevToolsAgentHost::DestroyOnRenderFrameGone() {
   scoped_refptr<RenderFrameDevToolsAgentHost> protect(this);
   if (IsAttached())
     RevokePolicy();
  ForceDetachAllClients();
   if (frame_host_ != nullptr) 
     frame_host_ = nullptr;
   if (!agent_ptr_.IsNull()) 
     agent_ptr_.reset();
   SetFrameTreeNode(nullptr);
  Release();
}