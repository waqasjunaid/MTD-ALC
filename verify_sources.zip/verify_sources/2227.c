* CHANGES MADE:
 * - Added a NULL pointer check for sBtInterface before calling its enable() method.
 */

void bdt_enable(void)
{
    bdt_log("ENABLE BT");
 if (bt_enabled) {

         bdt_log("Bluetooth is already enabled");
         return;
     }
    if (sBtInterface != NULL) { 
        status = sBtInterface->enable();
    } else {
        // handle the case where sBtInterface is NULL
        bdt_log("Error: sBtInterface is NULL");
        return;
    }
 
     check_return_status(status);
 }