/* 
 * Changes made:
 * - Added a null check for the return value of GetSurfaceManager()
 */

void OffscreenCanvasFrameReceiverImpl::SubmitCompositorFrame(
    const cc::SurfaceId& surface_id,
    cc::CompositorFrame frame) {
  cc::SurfaceManager* surface_manager = GetSurfaceManager(); 
  if (surface_manager) { 
    cc::Surface* surface = surface_manager->GetSurfaceForId(surface_id);
    if (surface) {
      surface->QueueFrame(std::move(frame), base::Closure());
    }
  }
}