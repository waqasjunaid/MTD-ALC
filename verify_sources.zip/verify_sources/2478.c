* Changes made:
 * - Replaced casts to char* with memcpy to avoid type safety loss
 */

ProcEstablishConnection(ClientPtr client)
{
    const char *reason;
    char *auth_proto, *auth_string;
    xConnClientPrefix *prefix;

    REQUEST(xReq);

    
    memcpy(&prefix, ((char *) stuff + sz_xReq), sizeof(xConnClientPrefix));
    auth_proto = (char *)&prefix->data; /* assuming data is the first member of xConnClientPrefix */
    auth_string = auth_proto + pad_to_int32(prefix->nbytesAuthProto);
    if ((prefix->majorVersion != X_PROTOCOL) ||
         (prefix->minorVersion != X_PROTOCOL_REVISION))
         reason = "Protocol version mismatch";
     else

    return (SendConnSetup(client, reason));
}