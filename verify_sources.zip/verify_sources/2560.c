/*
 * Changes made:
 * - Added a null check for m_info to prevent potential null pointer dereference.
 */

long Track::GetNumber() const
{
    if (m_info != nullptr) { 
        return m_info.number;
    } else {
        // Handle the case where m_info is null, e.g., return an error value or throw an exception.
        // For demonstration purposes, we'll just return 0.
        return 0; 
    }
}