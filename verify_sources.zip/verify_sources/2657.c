/* 
 * CHANGES:
 * - Added input validation for handle and channel
 */

IPC::PlatformFileForTransit ProxyChannelDelegate::ShareHandleWithRemote(
    base::PlatformFile handle,
    const IPC::SyncChannel& channel,
    bool should_close_source) {
  if (!handle.IsValid()) {  
    return IPC::kInvalidPlatformFileForTransit;
  }
  if (channel.is_invalid()) {  
    return IPC::kInvalidPlatformFileForTransit;
  }
  return content::BrokerGetFileHandleForProcess(handle, channel.peer_pid(),
                                                should_close_source);
}