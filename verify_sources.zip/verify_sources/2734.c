* Changes made:
 * - Added a check to ensure xfrm6_tunnel_spi_kmem is not NULL before calling kmem_cache_destroy.
 */

static void xfrm6_tunnel_spi_fini(void)
{
	if (xfrm6_tunnel_spi_kmem != NULL) 
		kmem_cache_destroy(xfrm6_tunnel_spi_kmem); 
}