/* 
 * Changes made:
 * - Added input validation for cached_resource
 */

String InspectorPageAgent::CachedResourceTypeJson(
    
    const Resource& cached_resource) {
  if (!cached_resource.IsValid()) { 
    return String(); // or throw an exception, depending on the desired behavior
  }
  return ResourceTypeJson(CachedResourceType(cached_resource));
}