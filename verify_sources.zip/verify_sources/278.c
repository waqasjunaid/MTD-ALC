* CHANGES MADE:
 * - Added input validation for the 'stringset' parameter
 */

static int hns_xgmac_get_sset_count(int stringset)
{
	
	if (stringset < 0 || stringset >= ETH_SS_MAX) {
		return 0; /* or handle error, depending on the desired behavior */
	}

	if (stringset == ETH_SS_STATS)
 		
 		return ARRAY_SIZE(g_xgmac_stats_string);
 
 	return 0;
}