* CHANGES MADE:
 * - Added input validation for context pointer
 */

static void addDataToStreamTask(void* context)
{
    if (!context) {  
        // handle error or return early
        return;
    }
    
    OwnPtr<BlobRegistryContext> blobRegistryContext = adoptPtr(static_cast<BlobRegistryContext*>(context));
    if (!blobRegistryContext || !blobRegistryContext->url) {  
        // handle error or return early
        return;
    }
    
    blobRegistry().addDataToStream(blobRegistryContext->url, blobRegistryContext->streamData);
}