/* 
 * CHANGES MADE:
 * - Added bounds check for input->width() to prevent potential integer overflow
 */

static sk_sp<SkImage> unPremulSkImageToPremul(SkImage* input) {
  if (!input || input->width() <= 0 || input->height() <= 0) { 
    return nullptr;
  }
  
  SkImageInfo info = SkImageInfo::Make(input->width(), input->height(),
                                       kN32_SkColorType, kPremul_SkAlphaType);
  RefPtr<Uint8Array> dstPixels = copySkImageData(input, info);
  if (!dstPixels)
     return nullptr;
   size_t widthBytes = static_cast<size_t>(input->width()) * info.bytesPerPixel(); 
   if (widthBytes < static_cast<size_t>(input->width())) { 
     return nullptr;
   }
   return newSkImageFromRaster(
       info, std::move(dstPixels),
      widthBytes);
 }