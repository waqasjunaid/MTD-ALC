Profile* profile = Profile::FromBrowserContext(web_contents->GetBrowserContext());
  TabSpecificContentSettings* tab_specific_content_settings =
      TabSpecificContentSettings::FromWebContents(web_contents);
  InfoBarService* info_bar_service = InfoBarService::FromWebContents(web_contents);

  if (profile && tab_specific_content_settings && info_bar_service) {
    presenter_.reset(new WebsiteSettings(
         this,
         profile, 
         tab_specific_content_settings, 
         info_bar_service, 
         nav_entry->GetURL(),
         nav_entry->GetSSL(),
         content::CertStore::GetInstance()));
  }