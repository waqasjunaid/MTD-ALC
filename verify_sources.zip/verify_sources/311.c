/* 
 * CHANGES MADE:
 * - Added a bounds check to ensure m_prev is within a valid range.
 */

long long BlockGroup::GetPrevTimeCode() const
{
    
    if (m_prev < 0 || m_prev > LLONG_MAX) {
        /* Handle invalid or out-of-range values, e.g., throw an exception or return a default value */
        // For demonstration purposes, we'll just return 0
        return 0;
    }
    return m_prev;
}