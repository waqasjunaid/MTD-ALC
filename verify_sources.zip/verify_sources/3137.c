segmentation_.update_data = reader_.ReadBool();
      if (segmentation_.update_data) {
        if (reader_.IsValidPointer()) { 
          ReadSegmentationData();
        }
      }