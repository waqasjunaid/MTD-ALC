offset = (int32_t) loffset; 

        if (needle_len == 0) { 
		intl_error_set( NULL, U_ILLEGAL_ARGUMENT_ERROR, "grapheme_strpos: Empty delimiter", 1 TSRMLS_CC );
		RETURN_FALSE;
	}