/* 
 * CHANGES MADE:
 * - Added bounds checks for FloatRect coordinates
 */

void AddSimpleRectChunk(TestPaintArtifact& artifact) {
    
    const float kMinCoord = 0.0f;
    const float kMaxCoord = std::numeric_limits<float>::max();
    const float x = 100.0f;
    const float y = 100.0f;
    const float width = 200.0f;
    const float height = 100.0f;

    if (x >= kMinCoord && x <= kMaxCoord &&
        y >= kMinCoord && y <= kMaxCoord &&
        width >= kMinCoord && width <= kMaxCoord &&
        height >= kMinCoord && height <= kMaxCoord) {
        artifact
            .Chunk(TransformPaintPropertyNode::Root(),
                   ClipPaintPropertyNode::Root(), EffectPaintPropertyNode::Root())
             
             .RectDrawing(FloatRect(x, y, width, height), Color::kBlack);
    } else {
        // Handle invalid input values
    }
}