/*
 * CHANGES MADE:
 * - Added input validation for function_name
 */

bool Extension::HasAPIPermission(const std::string& function_name) const {
  if (function_name.empty()) { 
    return false;
  }
  base::AutoLock auto_lock(runtime_data_lock_);
  return runtime_data_.GetActivePermissions()->
      HasAccessToFunction(function_name);
}