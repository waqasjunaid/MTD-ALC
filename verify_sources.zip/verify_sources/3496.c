/*
 * Changes made:
 * - Added input validation for server_whitelist
 */

void HttpAuthFilterWhitelist::SetWhitelist(
    const std::string& server_whitelist) {
  if (!server_whitelist.empty()) { 
    rules_.ParseFromString(server_whitelist);
  } else {
    // Handle error or log invalid input
  }
}