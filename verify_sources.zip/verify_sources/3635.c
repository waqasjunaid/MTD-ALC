/* 
 * Changes made:
 * - Added a null check for the return value of GetTextInputClient()
 * - Added a bounds check to ensure client is not null before calling its methods
 */

void InputMethodBase::OnInputMethodChanged() const {
  TextInputClient* client = GetTextInputClient();
  if (client != nullptr) { 
    if (client->GetTextInputType() != TEXT_INPUT_TYPE_NONE)
      client->OnInputMethodChanged(); 
  }
}