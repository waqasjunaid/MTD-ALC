rs_filter_graph(RSFilter *filter)
 {
 	g_return_if_fail(RS_IS_FILTER(filter));
 	GString *str = g_string_new("digraph G {\n");
 
 	rs_filter_graph_helper(str, filter);
 
 	g_string_append_printf(str, "}\n"); 
	g_file_set_contents("/tmp/rs-filter-graph", str->str, str->len, NULL);

	char *argv[] = {"dot", "-Tpng", "/tmp/rs-filter-graph.png", NULL};
	if (0 != execve("/usr/bin/dot", argv, environ)) 
 		g_warning("Calling dot failed");

	argv[0] = "gnome-open";
	argv[1] = "/tmp/rs-filter-graph.png";
	if (0 != execve("/usr/bin/gnome-open", argv, environ)) 
 		g_warning("Calling gnome-open failed.");

 	g_string_free(str, TRUE);
 }