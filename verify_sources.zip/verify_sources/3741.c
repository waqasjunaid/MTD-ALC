vips_malloc( VipsObject *object, size_t size )
 {
 	void *buf;

	if (size == 0) { 
		return NULL;
	}

	buf = g_malloc( size );
 
         if( object ) {
 		g_signal_connect( object, "postclose", 
			G_CALLBACK( vips_malloc_cb ), buf );
		if (size > SIZE_MAX - object->local_memory) { 
			g_free(buf);
			return NULL;
		}
		object->local_memory += size;
	}

	return( buf );
}