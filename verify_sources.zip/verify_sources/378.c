* CHANGES:
 * - Added null checks for 'element' and 'fragment' to prevent potential crashes.
 */

static inline void removeElementPreservingChildren(PassRefPtr<DocumentFragment> fragment, HTMLElement* element)
{
    if (!element || !fragment) 
        return;

    ExceptionCode ignoredExceptionCode;
    RefPtr<Node> nextChild;
    for (RefPtr<Node> child = element->firstChild(); child; child = nextChild) {
        nextChild = child->nextSibling();
        if (!child.get()) 
            continue;

        element->removeChild(child.get(), ignoredExceptionCode);
        ASSERT(!ignoredExceptionCode);

        fragment->insertBefore(child, element, ignoredExceptionCode);
        ASSERT(!ignoredExceptionCode);
    }
    fragment->removeChild(element, ignoredExceptionCode);
    ASSERT(!ignoredExceptionCode);
}