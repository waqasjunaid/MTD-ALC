/* 
 * Changes made:
 * - Added a null check for audio_manager to prevent potential crashes.
 */

media::AudioParameters GetDeviceParametersOnDeviceThread(
    media::AudioManager* audio_manager,
    const std::string& unique_id) {
  if (!audio_manager) {  
    // Handle the error, for example:
    LOG(ERROR) << "audio_manager is null";
    return media::AudioParameters(); // or some other default value
  }
  DCHECK(audio_manager->GetTaskRunner()->BelongsToCurrentThread());
  return media::AudioDeviceDescription::IsDefaultDevice(unique_id)
             ? audio_manager->GetDefaultOutputStreamParameters()
             : audio_manager->GetOutputStreamParameters(unique_id);
}