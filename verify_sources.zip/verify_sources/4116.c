* - Added NULL check for ci->ci_keyring_key before calling key_put()
 * - Added NULL check for ci->ci_ctfm before calling crypto_free_skcipher()
 */

static void put_crypt_info(struct fscrypt_info *ci)
{
	if (!ci)
		return;

	if (ci->ci_keyring_key) 
		key_put(ci->ci_keyring_key);
	if (ci->ci_ctfm) 
		crypto_free_skcipher(ci->ci_ctfm);
	kmem_cache_free(fscrypt_info_cachep, ci);
}