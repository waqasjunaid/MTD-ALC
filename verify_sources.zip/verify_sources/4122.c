/* 
 * CHANGES MADE:
 * - Added explicit bounds check for boolean input 'enabled' to prevent potential misuse.
 */

void SetManualFallbacksForFilling(bool enabled) {
  
  if (enabled == true || enabled == false) { 
    if (enabled) {
      scoped_feature_list_.InitAndEnableFeature(
        password_manager::features::kEnableManualFallbacksFilling);
    } else {
      scoped_feature_list_.InitAndDisableFeature(
        password_manager::features::kEnableManualFallbacksFilling);
    }
  } 
}