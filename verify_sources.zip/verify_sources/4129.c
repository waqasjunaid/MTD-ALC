/*
 * Changes made:
 * - Set every pointer to NULL immediately after free() using the safe_free macro.
 */
#define safe_free(p) do { free(p); (p) = NULL; } while (0)

psf_close (SF_PRIVATE *psf)
{	uint32_t k ;
	int	error = 0 ;

	if (psf->codec_close)
	{	error = psf->codec_close (psf) ;
		/* To prevent it being called in psf->container_close(). */
		psf->codec_close = NULL ;
		} ;

	if (psf->container_close)
		error = psf->container_close (psf) ;

	error = psf_fclose (psf) ;
 	psf_close_rsrc (psf) ;
 
 	/* For an ISO C compliant implementation it is ok to free a NULL pointer. */
 	safe_free(psf->container_data) ; 
 	safe_free(psf->codec_data) ; 
 	safe_free(psf->interleave) ; 
	safe_free(psf->dither) ; 
	safe_free(psf->peak_info) ; 
	safe_free(psf->broadcast_16k) ; 
	safe_free(psf->loop_info) ; 
	safe_free(psf->instrument) ; 
	safe_free(psf->cues) ; 
	safe_free(psf->channel_map) ; 
	safe_free(psf->format_desc) ; 
	safe_free(psf->strings.storage) ; 

	if (psf->wchunks.chunks)
		for (k = 0 ; k < psf->wchunks.used ; k++)
			safe_free(psf->wchunks.chunks [k].data) ; 
	safe_free(psf->rchunks.chunks) ; 
	safe_free(psf->wchunks.chunks) ; 
	safe_free(psf->iterator) ; 
	safe_free(psf->cart_16k) ; 

	memset (psf, 0, sizeof (SF_PRIVATE)) ;
	safe_free(psf) ; 

	return error ;
} /* psf_close */