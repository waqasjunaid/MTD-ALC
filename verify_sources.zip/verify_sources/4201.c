/* 
 * CHANGES MADE:
 * - Added a bounds check to ensure m_next is within a valid range.
 */

long long BlockGroup::GetNextTimeCode() const
{
    if (m_next < 0) { 
        return 0; /* or some other default/safe value */
    }
    return m_next;
}