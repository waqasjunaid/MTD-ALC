/* 
 * CHANGES MADE:
 * - Added bounds check for root_windows to prevent potential out-of-bounds access.
 */

aura::Window* PartialMagnificationController::GetCurrentRootWindow() {
  aura::Window::Windows root_windows = Shell::GetAllRootWindows();
  if (root_windows.empty())  
    return NULL;
  
  for (aura::Window::Windows::const_iterator iter = root_windows.begin();
       iter != root_windows.end(); ++iter) {
    aura::Window* root_window = *iter;
    if (root_window && 
        root_window->GetHost() && 
        root_window->ContainsPointInRoot(
            root_window->GetHost()->dispatcher()->GetLastMouseLocationInRoot()))
      return root_window;
  }
  return NULL;
}