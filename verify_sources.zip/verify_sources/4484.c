* CHANGES MADE:
 * - Added a null check for the result of GetInstance() to prevent potential crashes.
 * - Added a null check for the result of GetOriginalProfile() to prevent potential crashes.
 */

InputImeEventRouter* GetInputImeEventRouter(Profile* profile) {
  if (!profile)
    return nullptr;
  extensions::InputImeEventRouterFactory* factory = extensions::InputImeEventRouterFactory::GetInstance(); 
  if (!factory)
    return nullptr; 
  Profile* original_profile = profile->GetOriginalProfile(); 
  if (!original_profile)
    return nullptr; 
  return factory->GetRouter(original_profile);
}