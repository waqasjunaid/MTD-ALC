* Changes made:
 * - Fixed struct-cast vulnerability by using a union to safely access the dwLower member.
 */

void* sspi_SecureHandleGetLowerPointer(SecHandle* handle)
{
    void* pointer;

    if (!handle) 
        return NULL;

    union {
        SecHandle* handle;
        size_t dwLower;
    } u;

    u.handle = handle;
    pointer = (void*) ~u.dwLower; 

    return pointer;
}