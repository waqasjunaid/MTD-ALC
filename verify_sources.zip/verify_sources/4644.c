/*
 * Changes made:
 * - Added bounds check for index before accessing tab at that index
 */

void TabStripGtk::TabDetachedAt(TabContents* contents, int index) {
   GenerateIdealBounds();
  if (index >= 0 && index < GetNumberOfTabs()) { 
    StartRemoveTabAnimation(index, contents->web_contents());
    GetTabAt(index)->set_closing(true);
  }
}