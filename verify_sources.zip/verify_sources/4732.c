struct parse_state *state = ecalloc(1, sizeof(*state) + maxlen);
    if (!state) {  
        php_error_docref(NULL TSRMLS_CC, E_WARNING, "Memory allocation failed");
        return NULL;
    }