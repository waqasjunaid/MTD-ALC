* Changes made:
 * - Added input validation for 'object' and 'item'
 */

void cJSON_AddItemReferenceToObject( cJSON *object, const char *string, cJSON *item )
{
	if (object == NULL || item == NULL) {  
		return;
	}
	cJSON_AddItemToObject( object, string, create_reference( item ) );
}