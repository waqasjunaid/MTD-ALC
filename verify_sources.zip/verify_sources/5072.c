/*
 * Changes made:
 * - Added bounds checks for width and height parameters
 */

void GpuProcessHostUIShim::OnAcceleratedSurfaceNew(
    const GpuHostMsg_AcceleratedSurfaceNew_Params& params) {
  RenderWidgetHostViewPort* view = GetRenderWidgetHostViewFromSurfaceID(
       params.surface_id);
   if (!view)
     return;
   if (params.width <= 0 || params.height <= 0) { 
     // handle error or return early
     return;
   }
   view->AcceleratedSurfaceNew(
      params.width, params.height, params.surface_handle);
 }