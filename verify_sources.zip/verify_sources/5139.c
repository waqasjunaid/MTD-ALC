* - Added explicit bounds checks before every buffer/array access
 */

static size_t safecat(char *buffer, size_t bufsize, size_t pos,
   PNG_CONST char *cat)
 {
    while (pos < bufsize && cat != NULL && *cat != 0) {
       if (pos + 1 >= bufsize) { 
          break;
       }
       buffer[pos++] = *cat++;
    }

    if (pos >= bufsize) {
       pos = bufsize - 1; 
    }

   if (pos < bufsize) { 
      buffer[pos] = 0;
   }
 return pos;
}