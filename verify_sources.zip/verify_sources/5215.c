/*
 * Changes made:
 * - Added a null check for transaction_ to prevent potential null pointer dereference.
 */

void IndexedDBCursor::RemoveCursorFromTransaction() {
  if (transaction_) { 
    if (transaction_->UnregisterOpenCursor != nullptr) { 
      transaction_->UnregisterOpenCursor(this);
    }
  }
}