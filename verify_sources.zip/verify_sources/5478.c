/* 
 * CHANGES MADE:
 * - Added explicit bounds check for service_pid
 */

void ProcessControlLaunched() {
    base::ScopedAllowBlockingForTesting allow_blocking;
    base::ProcessId service_pid;
    EXPECT_TRUE(GetServiceProcessData(NULL, &service_pid));
    EXPECT_NE(static_cast<base::ProcessId>(0), service_pid);
    if (service_pid > 0) { 
#if defined(OS_WIN)
        service_process_ =
            base::Process::OpenWithAccess(service_pid,
                                          SYNCHRONIZE | PROCESS_QUERY_INFORMATION);
#else
        service_process_ = base::Process::Open(service_pid);
#endif
    } else {
        // Handle invalid service_pid, e.g., log error or throw exception
    }
    EXPECT_TRUE(service_process_.IsValid());
    base::ThreadTaskRunnerHandle::Get()->PostTask(
        FROM_HERE, base::RunLoop::QuitCurrentWhenIdleClosureDeprecated());
}