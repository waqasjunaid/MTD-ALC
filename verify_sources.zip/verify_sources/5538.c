/*
 * CHANGES:
 * - Added explicit null check for cue->track()
 */

void TextTrack::addCue(TextTrackCue* cue) {
  DCHECK(cue);

  if (std::isnan(cue->startTime()) || std::isnan(cue->endTime()) ||
      cue->startTime() < 0 || cue->endTime() < 0)
    return;

  if (TextTrack* cue_track = cue->track()) { 
    if (cue_track != nullptr) { 
      cue_track->removeCue(cue, ASSERT_NO_EXCEPTION);
    }
  }

  cue->SetTrack(this);
  EnsureTextTrackCueList()->Add(cue);

  if (GetCueTimeline() && mode_ != DisabledKeyword())
    GetCueTimeline()->AddCue(this, cue);
}