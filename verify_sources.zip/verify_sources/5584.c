

bool ChildProcessSecurityPolicyImpl::CanSetAsOriginHeader(int child_id,
                                                           const GURL& url) {
   if (!url.is_valid())
    return false;  
 
  if (url == kAboutSrcDocURL)
    return false;
 
  if (CanCommitURL(child_id, url))
     return true;
 
  {
    base::AutoLock lock(lock_);
    std::string scheme = url.scheme(); 
    if (!scheme.empty() && base::ContainsKey(schemes_okay_to_appear_as_origin_headers_, scheme)) {
      return true;
    }
  }
  return false;
}