/*
 * CHANGES:
 * - Added input validation for GURL object
 */

base::string16 GetApplicationNameForProtocol(const GURL& url) {
  if (url.is_empty()) { 
    return base::string16(); // or throw an exception, depending on the desired behavior
  }

  base::string16 application_name;
  if (base::win::GetVersion() >= base::win::VERSION_WIN8) {
    application_name = GetAppForProtocolUsingAssocQuery(url);
    if (!application_name.empty())
      return application_name;
  }

  return GetAppForProtocolUsingRegistry(url);
}