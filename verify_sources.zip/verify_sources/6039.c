* - Added error handling for fcntl() return values
 * - Added bounds check for opts value
 */

static inline void set_socket_blocking(int s, int blocking)
{
    int opts;
    if ((opts = fcntl(s, F_GETFL)) < 0) { 
        APPL_TRACE_ERROR("set blocking (%s)", strerror(errno));
        return; 
    }
    if (opts & O_NONBLOCK && !blocking) { 
        opts &= ~O_NONBLOCK;
    } else if (!(opts & O_NONBLOCK) && blocking) {
        opts |= O_NONBLOCK; 
    }
    if (fcntl(s, F_SETFL, opts) < 0) { 
        APPL_TRACE_ERROR("set blocking (%s)", strerror(errno));
    }
}