/*
 * Changes made to fix potential vulnerabilities:
 * - Added bounds check for duration value
 */

bool GesturePoint::IsInSecondClickTimeWindow() const {
   double duration =  last_touch_time_ - last_tap_time_;
   if (duration < 0) {  
     return false;
   }
  return duration <= kMaximumSecondsBetweenDoubleClick; 
 }