* CHANGES MADE:
 * - Added input validation for the 'cpu_own' parameter.
 */

static void toggle_fpga_eeprom_bus(bool cpu_own)
{
    
    if (cpu_own != 0 && cpu_own != 1) {
        return; /* or handle error, e.g., log and exit */
    }
	qrio_gpio_direction_output(GPIO_A, PROM_SEL_L, !cpu_own);
 }