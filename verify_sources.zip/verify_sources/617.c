/* 
 * Changes made:
 * - Added explicit bounds check around pointer operation in SetProcessDpiAwarenessWrapper
 */

void EnableHighDPISupport() {
  if (IsHighDPIEnabled() &&
     (base::win::GetVersion() < base::win::VERSION_WIN8_1)) {
    PROCESS_DPI_AWARENESS awareness = PROCESS_SYSTEM_DPI_AWARE;
    
    if (!SetProcessDpiAwarenessWrapper(awareness)) {
      SetProcessDPIAwareWrapper();
    }
  }
}