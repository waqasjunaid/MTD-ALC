/*
 * Changes made:
 * - Added a null check for m_errorCallback before calling handleEvent to prevent potential null pointer dereference.
 */

void RTCSessionDescriptionRequestImpl::requestFailed(const String& error)
{
    if (m_errorCallback != nullptr) 
        m_errorCallback->handleEvent(error);
 
    clear();
}