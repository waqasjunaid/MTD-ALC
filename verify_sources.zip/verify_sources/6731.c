* Changes made:
 * - Added a null check for m_proxy to prevent potential null pointer dereference.
 */

virtual void scheduleBeginFrameAndCommit()
{
    if (m_proxy != nullptr) { 
        CCMainThread::postTask(m_proxy->createBeginFrameAndCommitTaskOnCCThread());
    }
}