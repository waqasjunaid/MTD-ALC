* - Added a null check for ibus_prop to prevent potential crashes.
 */

static void UpdatePropertyCallback(IBusPanelService* panel,
                                     IBusProperty* ibus_prop, 
                                     gpointer user_data) {
    g_return_if_fail(user_data);
    InputMethodStatusConnection* self
        = static_cast<InputMethodStatusConnection*>(user_data);
    if (ibus_prop != NULL) { 
        self->UpdateProperty(ibus_prop); 
    }
}