* Changes made:
 * - Added null checks for category_group_name and event_name to prevent potential null pointer dereferences.
 */

bool IsTraceEventArgsWhitelisted(const char* category_group_name,
                                 const char* event_name) {
  if (category_group_name != NULL && 
      event_name != NULL && 
      base::MatchPattern(category_group_name, "toplevel") &&
      base::MatchPattern(event_name, "*")) {
    return true;
  }
 
  return false;
}