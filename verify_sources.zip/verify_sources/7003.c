/* 
 * CHANGES MADE:
 * - No actual vulnerability was identified in the given function.
 *   The diagnosis report does not indicate any specific security issue.
 *   Therefore, no changes are made to the original code.
 */

GesturePoint::GesturePoint()
     : first_touch_time_(0.0),
       last_touch_time_(0.0),
       last_tap_time_(0.0),
      velocity_calculator_(kBufferedPoints) {
 }