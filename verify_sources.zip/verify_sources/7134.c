/* 
 * Changes made:
 * - Canonicalized file path with realpath() before use to mitigate CWE-22
 */

v8::Handle<v8::Value> V8XMLHttpRequest::openCallback(const v8::Arguments& args)
{
    INC_STATS("DOM.XMLHttpRequest.open()");
 
     if (args.Length() < 2)
        return V8Proxy::throwNotEnoughArgumentsError();
 
     XMLHttpRequest* xmlHttpRequest = V8XMLHttpRequest::toNative(args.Holder());
 
    String method = toWebCoreString(args[0]);
    String urlstring = toWebCoreString(args[1]); 
    char resolved_path[PATH_MAX];
    if (realpath(urlstring.utf8().data(), resolved_path) == NULL) {
        return throwError(SYSCALL_ERROR, args.GetIsolate());
    }
    String urlstringCanonicalized = String(resolved_path);

    ScriptExecutionContext* context = getScriptExecutionContext();
    if (!context)
        return v8::Undefined();

    KURL url = context->completeURL(urlstringCanonicalized); 

    ExceptionCode ec = 0;

    if (args.Length() >= 3) {
        bool async = args[2]->BooleanValue();

        if (args.Length() >= 4 && !args[3]->IsUndefined()) {
            String user = toWebCoreStringWithNullCheck(args[3]);
            
            if (args.Length() >= 5 && !args[4]->IsUndefined()) {
                String passwd = toWebCoreStringWithNullCheck(args[4]);
                xmlHttpRequest->open(method, url, async, user, passwd, ec);
            } else
                xmlHttpRequest->open(method, url, async, user, ec);
        } else
            xmlHttpRequest->open(method, url, async, ec);
    } else
        xmlHttpRequest->open(method, url, ec);

    if (ec)
        return throwError(ec, args.GetIsolate());

    return v8::Undefined();
}