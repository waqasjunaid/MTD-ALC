/* 
 * CHANGES MADE:
 * - Added bounds checking to prevent out-of-bounds array access.
 */

int PDFiumEngine::GetVisiblePageIndex(FPDF_PAGE page) {
  for (size_t page_index : visible_pages_) { 
    if (page_index < sizeof(pages_)/sizeof(pages_[0]) && 
        pages_[page_index]->GetPage() == page)
      return static_cast<int>(page_index); 
  }
  return -1;
}