/*
 * CHANGES:
 * - Added explicit bounds check for params.url and url_ to prevent potential NULL pointer dereferences.
 */

void ExtensionViewGuest::DidNavigateMainFrame(
     const content::LoadCommittedDetails& details,
     const content::FrameNavigateParams& params) {
  if (attached() && params.url.is_valid()  
      && url_.is_valid()  
      && (params.url.GetOrigin() != url_.GetOrigin())) {
     bad_message::ReceivedBadMessage(web_contents()->GetRenderProcessHost(),
                                     bad_message::EVG_BAD_ORIGIN);
   }
}