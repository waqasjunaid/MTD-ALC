/*
 * Changes made:
 * - Added a null check for webPage to prevent potential crashes.
 */

void WebProcessProxy::addExistingWebPage(WebPageProxy* webPage, uint64_t pageID)
{
    if (!webPage) 
        return;
    m_pageMap.set(pageID, webPage);
    globalPageMap().set(pageID, webPage);
#if PLATFORM(MAC)
    if (pageIsProcessSuppressible(webPage))
         m_processSuppressiblePages.add(pageID);
     updateProcessSuppressionState();
#endif
}