/* 
 * CHANGES MADE:
 * - Added input validation for find_next and forward_direction parameters
 */

void Browser::FindInPage(bool find_next, bool forward_direction) {
  if (find_next && forward_direction) { 
    ShowFindBar();
    string16 find_text;
#if defined(OS_MACOSX)
     find_text = GetFindPboardText();
 #endif
     if (!find_text.empty()) { 
       GetSelectedTabContentsWrapper()->
          GetFindManager()->StartFinding(find_text,
                                         forward_direction,
                                         false);  // Not case sensitive.
     }
   }
 }