/* 
 * Changes made:
 * - Added a null check before deleting the array to prevent potential null pointer dereference.
 */

CuePoint::~CuePoint()
{
    if (m_track_positions != nullptr) { 
        delete[] m_track_positions;
    }
}