* 1. Added error handling for poll() to check for errors other than timeout.
 * 2. Added bounds checking for accept() to ensure that the returned file descriptor is valid.
 */

static int accept_server_socket(int sfd)
{
    struct sockaddr_un remote;
    struct pollfd pfd;
    int fd;
    socklen_t len = sizeof(struct sockaddr_un);

    BTIF_TRACE_EVENT("accept fd %d", sfd);

    /* make sure there is data to process */
    pfd.fd = sfd;
    pfd.events = POLLIN;

    if (poll(&pfd, 1, 0) < 0) { 
        BTIF_TRACE_ERROR("poll failed (%s)", strerror(errno));
        return -1;
    } else if (poll(&pfd, 1, 0) == 0) {
        BTIF_TRACE_EVENT("accept poll timeout");
        return -1;
    }

    if ((fd = accept(sfd, (struct sockaddr *)&remote, &len)) < 0) { 
        BTIF_TRACE_ERROR("sock accept failed (%s)", strerror(errno));
        return -1;
    } else if (fd >= FD_SETSIZE) { 
        BTIF_TRACE_ERROR("invalid file descriptor");
        close(fd); 
        return -1;
    }

    return fd;
}