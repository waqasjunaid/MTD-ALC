* CHANGES:
 * - Added a check to ensure that the blob object is not null before accessing its members.
 */

StateBase* writeBlob(v8::Handle<v8::Value> value, StateBase* next)
{
    Blob* blob = V8Blob::toNative(value.As<v8::Object>());
    if (!blob) 
        return 0;
    if (blob && !blob->hasBeenClosed()) 
        ;
    else
        return handleError(DataCloneError, "A Blob object has been closed, and could therefore not be cloned.", next);
    int blobIndex = -1;
    if (blob) 
        m_blobDataHandles.add(blob->uuid(), blob->blobDataHandle());
    if (appendBlobInfo(blob ? blob->uuid() : 0, blob ? blob->type() : "", blob ? blob->size() : 0, &blobIndex)) 
        m_writer.writeBlobIndex(blobIndex);
    else
        if (blob) 
            m_writer.writeBlob(blob->uuid(), blob->type(), blob->size());
    return 0;
}