/*
 * Changes made:
 * - Added a null check for the 'connection' parameter to prevent potential crashes.
 */

void ScreenRecorder::DoAddConnection(
    scoped_refptr<ConnectionToClient> connection) {
  if (connection == nullptr) {  
    return; 
  }
  DCHECK(network_loop_->BelongsToCurrentThread());
  connections_.push_back(connection);
}