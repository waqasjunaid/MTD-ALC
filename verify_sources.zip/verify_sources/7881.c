*   Added input validation for obj and error parameters.
 *   Checked return value of g_ascii_strup.
 */

my_object_many_args (MyObject *obj, guint32 x, const char *str, double trouble, double *d_ret, char **str_ret, GError **error)
{
  if (!obj || !error) { 
    return FALSE;
  }
  *d_ret = trouble + (x * 2);
  *str_ret = g_ascii_strup (str, -1); 
  if (*str_ret == NULL) { 
    g_set_error (error, G_ERROR, G_ERROR_FAILED, "Failed to convert string");
    return FALSE;
  }
  return TRUE;
}