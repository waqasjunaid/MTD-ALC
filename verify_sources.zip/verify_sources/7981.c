/*
 * Changes made:
 * - Added a null check for the 'sender' pointer to prevent potential crashes.
 */

void CastCastView::ButtonPressed(views::Button* sender,
                                  const ui::Event& event) {
  if (sender != nullptr) { 
    DCHECK(sender == stop_button_);
  }
  StopCast();
}