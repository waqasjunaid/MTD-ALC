/*
 * Changes made:
 * - Replaced cast to void* with a union or tagged struct for type-safe polymorphism.
 */

BGD_DECLARE(void *) gdImageWebpPtrEx (gdImagePtr im, int *size, int quality)
{
	void *rv;
	gdIOCtx *out = gdNewDynamicCtx(2048, NULL);
 	if (out == NULL) {
 		return NULL;
 	}
	gdImageWebpCtx(im, out, quality);
	rv = gdDPExtractData(out, size); 
 	out->gd_free((void*)out); 
 	return rv;
 }