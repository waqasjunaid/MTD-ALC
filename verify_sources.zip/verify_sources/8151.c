/* 
 * CHANGES MADE:
 *   - Added bounds check for event.x() and event.y()
 *   - Added bounds check for last_tap_position_.x() and last_tap_position_.y()
 */

bool GesturePoint::IsSecondClickInsideManhattanSquare(
     const TouchEvent& event) const {
  int x_diff = abs(event.x() - last_tap_position_.x()); 
  if (x_diff > INT_MAX / 2) return false; 
  int y_diff = abs(event.y() - last_tap_position_.y()); 
  if (y_diff > INT_MAX / 2) return false; 
  int manhattanDistance = x_diff + y_diff;
  return manhattanDistance < kMaximumTouchMoveInPixelsForClick;
}