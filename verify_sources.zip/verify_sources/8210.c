/*
 * Changes made:
 * - Added null check for `process_` to prevent potential null pointer dereference.
 */

ServiceWorkerHandler::ServiceWorkerHandler()
     : DevToolsDomainHandler(ServiceWorker::Metainfo::domainName),
       enabled_(false),
       process_(nullptr) ,
       weak_factory_(this) {}