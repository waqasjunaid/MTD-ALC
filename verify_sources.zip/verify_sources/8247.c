/*
 * Changes made:
 * - Added input validation for the 'enabled' parameter
 */

void WebSettingsImpl::setExperimentalNotificationsEnabled(bool enabled)
{
    if (m_settings != nullptr) { 
        m_settings->setExperimentalNotificationsEnabled(enabled);
    }
}