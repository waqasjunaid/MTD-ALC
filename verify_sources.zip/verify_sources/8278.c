* Changes made:
 *  - Added bounds checking for array index access to prevent potential buffer overflow.
 */

int ssl3_send_alert(SSL *s, int level, int desc)
{
    /* Map tls/ssl alert value to correct one */
    desc = s->method->ssl3_enc->alert_value(desc);
    if (s->version == SSL3_VERSION && desc == SSL_AD_PROTOCOL_VERSION)
        desc = SSL_AD_HANDSHAKE_FAILURE; /* SSL 3.0 does not have
                                          * protocol_version alerts */
                                           * protocol_version alerts */
     if (desc < 0)
         return -1;
    /* If a fatal one, remove from cache */
    if ((level == 2) && (s->session != NULL))
        SSL_CTX_remove_session(s->session_ctx, s->session);
 
     s->s3->alert_dispatch = 1;
     
     if (level >= 0 && (size_t)level < sizeof(s->s3->send_alert)) {
         s->s3->send_alert[0] = level; 
     }
    return -1;
}