* - Added validation for 'chunks' input value
 */

void svc_rdma_xdr_encode_reply_array(struct rpcrdma_write_array *ary,
				 int chunks)
{
	if (ary == NULL) { 
		return;
	}
	if (chunks < 0 || chunks > INT_MAX) { 
		return;
	}
	ary->wc_discrim = xdr_one; /* no change needed */
	ary->wc_nchunks = cpu_to_be32(chunks); /* no change needed */
}