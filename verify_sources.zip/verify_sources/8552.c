Here is the patched function:

int wvlan_uil_put_info(struct net_device *dev, struct urq_info *urq)
{
    int ltvAllocated = 0;
    LTVP pLtv;
    struct wvlan_dev *lp = (struct wvlan_dev *) dev->ml_priv;
    int result = 0;

    DBG_ENTER(DbgInfo);

    if (!capable(CAP_NET_ADMIN)) {
        DBG_ERROR(DbgInfo, "EPERM\n");
        urq->result = UIL_FAILURE;
        return -EPERM;
    }

    pLtv = (LTVP) urq->pLtv;
    if ((pLtv == NULL) && (urq->ltvSize > 0)) {
        pLtv = kmalloc(urq->ltvSize, GFP_KERNEL);
        ltvAllocated = 1;
        if (!pLtv) {
            DBG_ERROR(DbgInfo, "ENOMEM\n");
            urq->result = UIL_FAILURE;
            return -ENOMEM;
        }
    }

    if (pLtv != NULL) {
        memcpy(pLtv, urq->pLtv, urq->ltvSize);

        switch (pLtv->rid) {
        case CFG_MB_INFO:
        case CFG_IFB:
            break;
        default:
            /* Endian convert the RID */
            pLtv->rid = cpu_to_le16(pLtv->rid);
            break;
        }

        switch (pLtv->typ) {
        case LTYP_INT8U:
        case LTYP_INT8S:
        case LTYP_INT16U:
        case LTYP_INT16S:
        case LTYP_INT32U:
        case LTYP_INT32S:
            /* Endian convert the value */
            switch (pLtv->typ) {
            case LTYP_INT8U:
            case LTYP_INT8S:
                break;
            case LTYP_INT16U:
            case LTYP_INT16S:
                pLtv->value.int16 = cpu_to_le16(pLtv->value.int16);
                break;
            case LTYP_INT32U:
            case LTYP_INT32S:
                pLtv->value.int32 = cpu_to_le32(pLtv->value.int32);
                break;
            }
            break;
        default:
            break;
        }

        switch (pLtv->rid) {
        case CFG_ENCRYPT_STRING:
            /* Endian convert the Tx Key Information */
            pLtv->value.int16 = cpu_to_le16(pLtv->value.int16);
            break;
        case CFG_ADD_TKIP_DEFAULT_KEY:
        case CFG_REMOVE_TKIP_DEFAULT_KEY:
            /* Endian convert the Tx Key Information */
            pLtv->value.int16 = cpu_to_le16(pLtv->value.int16);
            break;
        default:
            break;
        }

        wl_act_int_off(lp);
        urq->result = hcf_put_info(&(lp->hcfCtx), (LTVP) pLtv);
        wl_act_int_on(lp);

        if (ltvAllocated)
            kfree(pLtv);
    } else {
        urq->result = UIL_FAILURE;
    }

    DBG_LEAVE(DbgInfo);
    return result;
} /* wvlan_uil_put_info */